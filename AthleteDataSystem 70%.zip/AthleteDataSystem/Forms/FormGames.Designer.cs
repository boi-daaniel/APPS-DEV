﻿namespace AthleteDataSystem.Forms
{
    partial class FormGames
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewGames = new System.Windows.Forms.DataGridView();
            this.panelBBHome = new System.Windows.Forms.Panel();
            this.panelDash = new System.Windows.Forms.Panel();
            this.btnSearch = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelSearch = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGames)).BeginInit();
            this.panelBBHome.SuspendLayout();
            this.panelDash.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewGames
            // 
            this.dataGridViewGames.AllowUserToAddRows = false;
            this.dataGridViewGames.AllowUserToDeleteRows = false;
            this.dataGridViewGames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGames.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewGames.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewGames.Name = "dataGridViewGames";
            this.dataGridViewGames.ReadOnly = true;
            this.dataGridViewGames.Size = new System.Drawing.Size(800, 350);
            this.dataGridViewGames.TabIndex = 0;
            // 
            // panelBBHome
            // 
            this.panelBBHome.BackColor = System.Drawing.Color.DimGray;
            this.panelBBHome.Controls.Add(this.dataGridViewGames);
            this.panelBBHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBBHome.Location = new System.Drawing.Point(0, 100);
            this.panelBBHome.Name = "panelBBHome";
            this.panelBBHome.Size = new System.Drawing.Size(800, 350);
            this.panelBBHome.TabIndex = 7;
            // 
            // panelDash
            // 
            this.panelDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelDash.Controls.Add(this.btnSearch);
            this.panelDash.Controls.Add(this.labelSearch);
            this.panelDash.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDash.Location = new System.Drawing.Point(0, 0);
            this.panelDash.Name = "panelDash";
            this.panelDash.Size = new System.Drawing.Size(800, 100);
            this.panelDash.TabIndex = 6;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.Window;
            this.btnSearch.BorderColor = System.Drawing.Color.Black;
            this.btnSearch.BorderFocusColor = System.Drawing.Color.HotPink;
            this.btnSearch.BorderRadius = 15;
            this.btnSearch.BorderSize = 2;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.DimGray;
            this.btnSearch.Location = new System.Drawing.Point(588, 35);
            this.btnSearch.Multiline = false;
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.btnSearch.PasswordChar = false;
            this.btnSearch.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.btnSearch.PlaceholderText = "";
            this.btnSearch.Size = new System.Drawing.Size(200, 31);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Texts = "";
            this.btnSearch.UnderlinedStyle = false;
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.ForeColor = System.Drawing.Color.White;
            this.labelSearch.Location = new System.Drawing.Point(646, 9);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(80, 24);
            this.labelSearch.TabIndex = 2;
            this.labelSearch.Text = "Search";
            // 
            // FormGames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelBBHome);
            this.Controls.Add(this.panelDash);
            this.Name = "FormGames";
            this.Text = "Games";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGames)).EndInit();
            this.panelBBHome.ResumeLayout(false);
            this.panelDash.ResumeLayout(false);
            this.panelDash.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewGames;
        private System.Windows.Forms.Panel panelBBHome;
        private System.Windows.Forms.Panel panelDash;
        private CustomControls.CurveTextbox btnSearch;
        private System.Windows.Forms.Label labelSearch;
    }
}