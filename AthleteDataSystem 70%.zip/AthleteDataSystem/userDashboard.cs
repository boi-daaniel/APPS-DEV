﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem
{
    public partial class userDashboard : Form
    {
        //Fields
        private Form activeForm;
        private string username;

        //Constructor
        public userDashboard(string username)
        {
            InitializeComponent();
            btnCloseChildForm.Visible = false; // Hide back button
            this.username = username;
            labelTitle.Text = "Welcome " + username + "!";
        }

        // Switching Forms
        private void SwitchForm(Form switchForm, object btnSender)
        {
            if (activeForm != null)
            activeForm.Close();
            activeForm = switchForm;
            switchForm.TopLevel = false;
            switchForm.FormBorderStyle = FormBorderStyle.None;
            switchForm.Dock = DockStyle.Fill;
            this.panelDesktopPane.Controls.Add(switchForm);
            this.panelDesktopPane.Tag = switchForm;
            switchForm.BringToFront();
            switchForm.Show();
            lblTitle.Text = switchForm.Text;
            btnCloseChildForm.Visible = true;
        }

        //Buttons
        private void btnGames_Click(object sender, EventArgs e)
        {
            SwitchForm(new Forms.FormGames(), sender); 
        }
        private void btnProfile_Click(object sender, EventArgs e)
        {
            SwitchForm(new Forms.FormProfile(), sender); 
        }
        private void btnBasketball_Click(object sender, EventArgs e) 
        {
            SwitchForm(new Forms.FormBasketball(), sender); 
        }
        private void btnVolleyball_Click(object sender, EventArgs e)
        {
            SwitchForm(new Forms.FormVolleyball(), sender); 
        }
        private void btnFeatured1_Click(object sender, EventArgs e)
        {
            SwitchForm(new Forms.FormFeatured1(), sender);
        }

        private void btnFeatured2_Click(object sender, EventArgs e)
        {
            SwitchForm(new Forms.FormFeatured2(), sender);
        }
        private void btnCloseChildForm_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
                activeForm.Close();
            Reset();
        }
        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the userDashboard form
            Login loginForm = new Login();
            loginForm.Show(); // Show the Login form 
        }

        //Reset Form Method
        private void Reset()
        {
            lblTitle.Text = "HOME";
            panelTitleBar.BackColor = Color.FromArgb(64, 64, 64);
            panelLogo.BackColor = Color.FromArgb(64, 64, 64);
            btnCloseChildForm.Visible = false;
        }
        
        //Close form
        private void userDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application
        }

    }
}
