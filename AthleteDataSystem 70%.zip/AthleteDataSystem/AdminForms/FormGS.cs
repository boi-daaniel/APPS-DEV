﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormGS : Form
    {
        //Constructor
        public FormGS()
        {
            InitializeComponent();
            LoadGamesSchedules();
        }

        //Load Table
        private void LoadGamesSchedules()
        {
            try
            {
                string query = "SELECT * FROM games";
                DBHelper.DBHelper.fill(query, dataGridViewGames);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        //Methods
        private void ClearFields()
        {
            txtGames.Texts = "";
            txtTeamMatchup.Texts = "";
            txtDate.Value = DateTime.Now;
        }
        //New Button
        private void newBtn_Click(object sender, EventArgs e)
        {
            ClearFields();
        }
        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO games (TeamMatchup, Games, GameDateTime) " + "VALUES (" + "'" + txtTeamMatchup.Texts + "', " + "'" + txtGames.Texts + "', " + "'" + txtDate.Value.ToString("yyyy-MM-dd HH:mm:ss") + "'" + ")";
                DBHelper.DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added successfully.", "Save Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadGamesSchedules(); // Refresh the data in the DataGridView
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //Update Button
        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridViewGames.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridViewGames.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridViewGames.DataSource).Rows[selectedRowIndex];

                if (selectedRow["MatchID"] != DBNull.Value)
                {
                    string sql = "UPDATE games SET " + "TeamMatchup = '" + txtTeamMatchup.Texts + "', " +
                         "Games = '" + txtGames.Texts + "', " +
                         "GameDateTime = '" + txtDate.Value.ToString("yyyy-MM-dd HH:mm:ss") + "' " +
                         "WHERE MatchID = " + selectedRow["MatchID"];
                    DBHelper.DBHelper.ModifyRecord(sql);
                    MessageBox.Show("Data has been updated successfully.", "Update Match", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadGamesSchedules(); // Refresh the data in the DataGridView
                }
                else
                {
                    MessageBox.Show("MatchID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }
        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridViewGames.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridViewGames.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridViewGames.DataSource).Rows[selectedRowIndex];


                        if (selectedRow["MatchID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM games WHERE MatchID = " + selectedRow["MatchID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.");
                            LoadGamesSchedules(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("MatchID cannot be null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Delete Match", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dataGridViewGames_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridViewGames.Rows.Count)
            {
                txtTeamMatchup.Texts = dataGridViewGames[1, e.RowIndex].Value?.ToString();
                txtGames.Texts = dataGridViewGames[2, e.RowIndex].Value?.ToString();
                txtDate.Value = Convert.ToDateTime(dataGridViewGames[3, e.RowIndex].Value);
            }
        }
        
    }
}
