﻿namespace AthleteDataSystem
{
    partial class adminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelDash = new System.Windows.Forms.Panel();
            this.btnVolletball = new System.Windows.Forms.Button();
            this.btnBasketball = new System.Windows.Forms.Button();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.labelGreetings = new System.Windows.Forms.Label();
            this.logoutBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.panelDBTable = new System.Windows.Forms.Panel();
            this.panelDash.SuspendLayout();
            this.panelTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelDash
            // 
            this.panelDash.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panelDash.Controls.Add(this.btnVolletball);
            this.panelDash.Controls.Add(this.btnBasketball);
            this.panelDash.Controls.Add(this.panelTitle);
            this.panelDash.Controls.Add(this.logoutBtn);
            this.panelDash.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelDash.Location = new System.Drawing.Point(0, 0);
            this.panelDash.Name = "panelDash";
            this.panelDash.Size = new System.Drawing.Size(200, 611);
            this.panelDash.TabIndex = 55;
            // 
            // btnVolletball
            // 
            this.btnVolletball.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnVolletball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolletball.Font = new System.Drawing.Font("Lucida Fax", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolletball.ForeColor = System.Drawing.Color.White;
            this.btnVolletball.Image = global::AthleteDataSystem.Properties.Resources.volleyball_icon;
            this.btnVolletball.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolletball.Location = new System.Drawing.Point(0, 160);
            this.btnVolletball.Name = "btnVolletball";
            this.btnVolletball.Size = new System.Drawing.Size(200, 60);
            this.btnVolletball.TabIndex = 51;
            this.btnVolletball.Text = "Volleyball";
            this.btnVolletball.UseVisualStyleBackColor = true;
            this.btnVolletball.Click += new System.EventHandler(this.btnVolletball_Click);
            // 
            // btnBasketball
            // 
            this.btnBasketball.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBasketball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBasketball.Font = new System.Drawing.Font("Lucida Fax", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBasketball.ForeColor = System.Drawing.Color.White;
            this.btnBasketball.Image = global::AthleteDataSystem.Properties.Resources.basketball_icon;
            this.btnBasketball.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBasketball.Location = new System.Drawing.Point(0, 100);
            this.btnBasketball.Name = "btnBasketball";
            this.btnBasketball.Size = new System.Drawing.Size(200, 60);
            this.btnBasketball.TabIndex = 50;
            this.btnBasketball.Text = "Basketball";
            this.btnBasketball.UseVisualStyleBackColor = true;
            this.btnBasketball.Click += new System.EventHandler(this.btnBasketball_Click);
            // 
            // panelTitle
            // 
            this.panelTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTitle.Controls.Add(this.labelGreetings);
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(0, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(200, 100);
            this.panelTitle.TabIndex = 49;
            // 
            // labelGreetings
            // 
            this.labelGreetings.AutoSize = true;
            this.labelGreetings.Font = new System.Drawing.Font("Lucida Fax", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGreetings.Location = new System.Drawing.Point(11, 36);
            this.labelGreetings.Name = "labelGreetings";
            this.labelGreetings.Size = new System.Drawing.Size(171, 22);
            this.labelGreetings.TabIndex = 0;
            this.labelGreetings.Text = "Welcome Admin!";
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.White;
            this.logoutBtn.BackgroundColor = System.Drawing.Color.White;
            this.logoutBtn.BorderColor = System.Drawing.Color.Black;
            this.logoutBtn.BorderRadius = 20;
            this.logoutBtn.BorderSize = 2;
            this.logoutBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logoutBtn.FlatAppearance.BorderSize = 0;
            this.logoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutBtn.Font = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutBtn.ForeColor = System.Drawing.Color.Black;
            this.logoutBtn.Location = new System.Drawing.Point(0, 571);
            this.logoutBtn.Margin = new System.Windows.Forms.Padding(2);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(200, 40);
            this.logoutBtn.TabIndex = 48;
            this.logoutBtn.Text = "Log out";
            this.logoutBtn.TextColor = System.Drawing.Color.Black;
            this.logoutBtn.UseVisualStyleBackColor = false;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click_1);
            // 
            // panelDBTable
            // 
            this.panelDBTable.BackColor = System.Drawing.Color.White;
            this.panelDBTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDBTable.ForeColor = System.Drawing.Color.White;
            this.panelDBTable.Location = new System.Drawing.Point(200, 0);
            this.panelDBTable.Name = "panelDBTable";
            this.panelDBTable.Size = new System.Drawing.Size(804, 611);
            this.panelDBTable.TabIndex = 56;
            // 
            // adminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1004, 611);
            this.Controls.Add(this.panelDBTable);
            this.Controls.Add(this.panelDash);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "adminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "adminDashboard";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.adminDashboard_FormClosed);
            this.panelDash.ResumeLayout(false);
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private CustomTools.CurvedButton logoutBtn;
        private System.Windows.Forms.Panel panelDash;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.Label labelGreetings;
        private System.Windows.Forms.Panel panelDBTable;
        private System.Windows.Forms.Button btnVolletball;
        private System.Windows.Forms.Button btnBasketball;
    }
}