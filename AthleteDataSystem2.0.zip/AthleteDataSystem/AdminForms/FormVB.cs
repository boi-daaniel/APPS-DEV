﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormVB : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        public FormVB()
        {
            InitializeComponent();
            LoadVolleyballPlayers();
        }
        //Load Table
        private void LoadVolleyballPlayers()
        {
            try
            {
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ADS.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM volleyballPlayers", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "ADS");
                dataGridView1.DataSource = dataSet.Tables["ADS"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {

        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("INSERT INTO volleyballPlayers (Name, Team, Sets Played, Average Sets, Points, Block, Ace, Dig, Receive) VALUES (@Name, @Team, @Sets Played, @Average Sets, @Points, @Block, @Ace, @Dig, @Receive)", connection);
                command.Parameters.AddWithValue("@Name", txtName.Texts);
                command.Parameters.AddWithValue("@Team", txtTeam.Texts);
                command.Parameters.AddWithValue("@Sets Played", int.Parse(txtSetsPlayed.Texts));
                command.Parameters.AddWithValue("@Average Sets", double.Parse(txtAverageSet.Texts));
                command.Parameters.AddWithValue("@Points", double.Parse(txtPointsPerGame.Texts));
                command.Parameters.AddWithValue("@Block", double.Parse(txtBlockPerGame.Texts));
                command.Parameters.AddWithValue("@Ace", double.Parse(txtAce.Texts));
                command.Parameters.AddWithValue("@Dig", double.Parse(txtDig.Texts));                
                command.Parameters.AddWithValue("@Receive", double.Parse(txtReceive.Texts));                
                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                LoadVolleyballPlayers(); // Refresh the data in the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {

        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        dataSet.Tables["volleyballPlayers"].Rows[selectedRowIndex].Delete();

                        connection.Open();
                        OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                        dataAdapter.DeleteCommand = cmdBuilder.GetDeleteCommand();
                        dataAdapter.Update(dataSet, "volleyballPlayers");

                        MessageBox.Show("Record deleted successfully.");
                        LoadVolleyballPlayers(); // Refresh the data in the DataGridView
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
        }
    }
}
