﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormBB : Form
    {
        //Fields
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private int selectedRowIndex;

        //Constructor
        public FormBB()
        {
            InitializeComponent();
            LoadBasketballPlayers();
        }

        //Load Table
        private void LoadBasketballPlayers()
        {
            try
            {
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ADS.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM basketballPlayers", connection);
                dataSet = new DataSet();  // Initialize dataSet here

                connection.Open();
                dataAdapter.Fill(dataSet, "ADS");
                dataGridView1.DataSource = dataSet.Tables["ADS"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        //New Button
        private void newBtn_Click(object sender, EventArgs e)
        {
            txtName.Texts = "";
            txtTeam.Texts = "";
            txtGamesPlayed.Texts = "";
            txtAverageMinutes.Texts = "";
            txtPointsPerGame.Texts = "";
            txtAssistPerGame.Texts = "";
            txtFieldGoalMades.Texts = "";
            txtFieldGoalAttempted.Texts = "";
        }
        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("INSERT INTO basketballPlayers (PlayerName, Team, GamesPlayed, AverageMinutes, PointsPerGame, AssistPerGame, FieldGoalsMade, FieldGoalsAttempted) VALUES (@PlayerName, @Team, @GamesPlayed, @AverageMinutes, @PointsPerGame, @AssistPerGame, @FieldGoalMades, @FieldGoalAttempted)", connection);
                command.Parameters.AddWithValue("@PlayerName", txtName.Texts);
                command.Parameters.AddWithValue("@Team", txtTeam.Texts);
                command.Parameters.AddWithValue("@GamesPlayed", int.Parse(txtGamesPlayed.Texts));
                command.Parameters.AddWithValue("@AverageMinutes", double.Parse(txtAverageMinutes.Texts));
                command.Parameters.AddWithValue("@PointsPerGame", double.Parse(txtPointsPerGame.Texts));
                command.Parameters.AddWithValue("@AssistPerGame", double.Parse(txtAssistPerGame.Texts));
                command.Parameters.AddWithValue("@FieldGoalMades", double.Parse(txtFieldGoalMades.Texts));
                command.Parameters.AddWithValue("@FieldGoalAttempted", double.Parse(txtFieldGoalAttempted.Texts));
                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                LoadBasketballPlayers(); // Refresh the data in the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        //Update Button
        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                try
                {
                    int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
                    int selectedColumnIndex = dataGridView1.SelectedCells[0].ColumnIndex;
                    string columnName = dataGridView1.Columns[selectedColumnIndex].Name;
                    DataRow selectedRow = dataSet.Tables["ADS"].Rows[selectedRowIndex];

                    switch (columnName)
                    {
                        case "PlayerName":
                            selectedRow["PlayerName"] = txtName.Texts;
                            break;
                        case "Team":
                            selectedRow["Team"] = txtTeam.Texts;
                            break;
                        case "GamesPlayed":
                            selectedRow["GamesPlayed"] = int.Parse(txtGamesPlayed.Texts);
                            break;
                        case "AverageMinutes":
                            selectedRow["AverageMinutes"] = double.Parse(txtAverageMinutes.Texts);
                            break;
                        case "PointsPerGame":
                            selectedRow["PointsPerGame"] = double.Parse(txtPointsPerGame.Texts);
                            break;
                        case "AssistPerGame":
                            selectedRow["AssistPerGame"] = double.Parse(txtAssistPerGame.Texts);
                            break;
                        case "FieldGoalsMade":
                            selectedRow["FieldGoalsMade"] = double.Parse(txtFieldGoalMades.Texts);
                            break;
                        case "FieldGoalsAttempted":
                            selectedRow["FieldGoalsAttempted"] = double.Parse(txtFieldGoalAttempted.Texts);
                            break;
                        default:
                            MessageBox.Show("Cannot Update Row. Select Column Only");
                            return;
                    }

                    connection.Open();
                    OleDbCommand command = new OleDbCommand("UPDATE basketballPlayers SET [" + columnName + "] = @Value WHERE PlayerID = @ID", connection);
                    command.Parameters.AddWithValue("@Value", selectedRow[columnName]);
                    command.Parameters.AddWithValue("@ID", selectedRow["PlayerID"]);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Data updated successfully.");
                    LoadBasketballPlayers(); // Refresh the data in the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a cell to update.");
            }
        }
        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = dataSet.Tables["ADS"].Rows[selectedRowIndex];

                        if (selectedRow["PlayerID"] != DBNull.Value)
                        {
                            connection.Open();
                            OleDbCommand command = new OleDbCommand("DELETE FROM basketballPlayers WHERE PlayerID = @PlayerID", connection);
                            command.Parameters.AddWithValue("@PlayerID", selectedRow["PlayerID"]);
                            command.ExecuteNonQuery();
                            MessageBox.Show("Record deleted successfully.");
                            LoadBasketballPlayers(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("PlayerID cannot be null.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        // Cellclick
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtName.Texts = dataGridView1[1, e.RowIndex].Value.ToString();
                txtTeam.Texts = dataGridView1[2, e.RowIndex].Value.ToString();
                txtGamesPlayed.Texts = dataGridView1[3, e.RowIndex].Value.ToString();
                txtAverageMinutes.Texts = dataGridView1[4, e.RowIndex].Value.ToString();
                txtPointsPerGame.Texts = dataGridView1[5, e.RowIndex].Value.ToString();
                txtAssistPerGame.Texts = dataGridView1[6, e.RowIndex].Value.ToString();
                txtFieldGoalMades.Texts = dataGridView1[7, e.RowIndex].Value.ToString();
                txtFieldGoalAttempted.Texts = dataGridView1[8, e.RowIndex].Value.ToString();
            }
            catch (Exception) { }
        }
    }
}
