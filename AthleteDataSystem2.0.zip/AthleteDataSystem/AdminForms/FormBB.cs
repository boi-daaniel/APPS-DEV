﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormBB : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        public FormBB()
        {
            InitializeComponent();
            LoadBasketballPlayers();
        }

        //Load Table
        private void LoadBasketballPlayers()
        {
            try
            {
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ADS.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM basketballPlayers", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "ADS");
                dataGridView1.DataSource = dataSet.Tables["ADS"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {

        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("INSERT INTO basketballPlayers (Name, Team, GamesPlayed, AverageMinutes, PointsPerGame, AssistPerGame, FieldGoalsMade, FieldGoalsAttempted) VALUES (@Name, @Team, @GamesPlayed, @AverageMinutes, @PointsPerGame, @AssistPerGame, @FieldGoalMades, @FieldGoalAttempted)", connection);
                command.Parameters.AddWithValue("@Name", txtName.Texts);
                command.Parameters.AddWithValue("@Team", txtTeam.Texts);
                command.Parameters.AddWithValue("@GamesPlayed", int.Parse(txtGamesPlayed.Texts));
                command.Parameters.AddWithValue("@AverageMinutes", double.Parse(txtAverageMinutes.Texts));
                command.Parameters.AddWithValue("@PointsPerGame", double.Parse(txtPointsPerGame.Texts));
                command.Parameters.AddWithValue("@AssistPerGame", double.Parse(txtAssistPerGame.Texts));
                command.Parameters.AddWithValue("@FieldGoalMades", double.Parse(txtFieldGoalMades.Texts));
                command.Parameters.AddWithValue("@FieldGoalAttempted", double.Parse(txtFieldGoalAttempted.Texts));
                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                LoadBasketballPlayers(); // Refresh the data in the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                    DataRow selectedRow = dataSet.Tables["basketballPlayers"].Rows[selectedRowIndex];

                    /*selectedRow["Name"] = txtName.Texts;
                    selectedRow["Team"] = txtTeam.Texts;*/
                    if (!string.IsNullOrEmpty(txtGamesPlayed.Texts))
                    {
                        selectedRow["GamesPlayed"] = int.Parse(txtGamesPlayed.Texts);
                    }

                    if (!string.IsNullOrEmpty(txtAverageMinutes.Texts))
                    {
                        selectedRow["AverageMinutes"] = double.Parse(txtAverageMinutes.Texts);
                    }

                    if (!string.IsNullOrEmpty(txtPointsPerGame.Texts))
                    {
                        selectedRow["PointsPerGame"] = double.Parse(txtPointsPerGame.Texts);
                    }

                    if (!string.IsNullOrEmpty(txtAssistPerGame.Texts))
                    {
                        selectedRow["AssistPerGame"] = double.Parse(txtAssistPerGame.Texts);
                    }

                    if (!string.IsNullOrEmpty(txtFieldGoalMades.Texts))
                    {
                        selectedRow["FieldGoalsMade"] = double.Parse(txtFieldGoalMades.Texts);
                    }

                    if (!string.IsNullOrEmpty(txtFieldGoalAttempted.Texts))
                    {
                        selectedRow["FieldGoalsAttempted"] = double.Parse(txtFieldGoalAttempted.Texts);
                    }

                    connection.Open();
                    OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                    dataAdapter.UpdateCommand = cmdBuilder.GetUpdateCommand();
                    dataAdapter.Update(dataSet, "Players");

                    MessageBox.Show("Data updated successfully.");
                    LoadBasketballPlayers(); // Refresh the data in the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        dataSet.Tables["basketballPlayers"].Rows[selectedRowIndex].Delete();

                        connection.Open();
                        OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                        dataAdapter.DeleteCommand = cmdBuilder.GetDeleteCommand();
                        dataAdapter.Update(dataSet, "basketballPlayers");

                        MessageBox.Show("Record deleted successfully.");
                        LoadBasketballPlayers(); // Refresh the data in the DataGridView
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
        }


    }
}
