﻿namespace AthleteDataSystem.Forms
{
    partial class FormHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelHome = new System.Windows.Forms.Label();
            this.panelDB = new System.Windows.Forms.Panel();
            this.panelHome = new System.Windows.Forms.Panel();
            this.panelDB.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelHome
            // 
            this.labelHome.AutoSize = true;
            this.labelHome.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHome.ForeColor = System.Drawing.Color.White;
            this.labelHome.Location = new System.Drawing.Point(350, 37);
            this.labelHome.Name = "labelHome";
            this.labelHome.Size = new System.Drawing.Size(73, 24);
            this.labelHome.TabIndex = 0;
            this.labelHome.Text = "HOME";
            // 
            // panelDB
            // 
            this.panelDB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelDB.Controls.Add(this.labelHome);
            this.panelDB.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDB.Location = new System.Drawing.Point(0, 0);
            this.panelDB.Name = "panelDB";
            this.panelDB.Size = new System.Drawing.Size(800, 100);
            this.panelDB.TabIndex = 1;
            // 
            // panelHome
            // 
            this.panelHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHome.Location = new System.Drawing.Point(0, 100);
            this.panelHome.Name = "panelHome";
            this.panelHome.Size = new System.Drawing.Size(800, 350);
            this.panelHome.TabIndex = 2;
            // 
            // FormHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelHome);
            this.Controls.Add(this.panelDB);
            this.Name = "FormHome";
            this.Text = "Home";
            this.panelDB.ResumeLayout(false);
            this.panelDB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelHome;
        private System.Windows.Forms.Panel panelDB;
        private System.Windows.Forms.Panel panelHome;
    }
}