﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormBasketball : Form
    {
        //Fields
        private OleDbConnection Connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        //Constructor
        public FormBasketball()
        {
            InitializeComponent();
            LoadBasketballTable();
        }

        //Load Table
        private void LoadBasketballTable()
        {
            try
            {
                string conns = "Provider=MICROSOFT.ACE.OLEDB.12.0; Data Source=ADS.accdb;";
                Connection = new OleDbConnection(conns);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM basketballPlayers ", Connection);
                dataSet = new DataSet();

                Connection.Open();
                dataAdapter.Fill(dataSet, "ADS");
                dataGridViewBBPlayers.DataSource = dataSet.Tables["ADS"];
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Error" + ex.Message);
            }
            finally
            {
                if(Connection != null && Connection.State == ConnectionState.Open)
                {
                    Connection.Close();
                }
            }
        }
    }
}
