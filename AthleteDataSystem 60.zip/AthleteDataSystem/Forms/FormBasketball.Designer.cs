﻿namespace AthleteDataSystem.Forms
{
    partial class FormBasketball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelDash = new System.Windows.Forms.Panel();
            this.curveTextbox1 = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.label2 = new System.Windows.Forms.Label();
            this.panelBBHome = new System.Windows.Forms.Panel();
            this.dataGridViewBBPlayers = new System.Windows.Forms.DataGridView();
            this.panelDash.SuspendLayout();
            this.panelBBHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBBPlayers)).BeginInit();
            this.SuspendLayout();
            // 
            // panelDash
            // 
            this.panelDash.BackColor = System.Drawing.Color.DarkOrange;
            this.panelDash.Controls.Add(this.curveTextbox1);
            this.panelDash.Controls.Add(this.label2);
            this.panelDash.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDash.Location = new System.Drawing.Point(0, 0);
            this.panelDash.Name = "panelDash";
            this.panelDash.Size = new System.Drawing.Size(800, 100);
            this.panelDash.TabIndex = 2;
            // 
            // curveTextbox1
            // 
            this.curveTextbox1.BackColor = System.Drawing.SystemColors.Window;
            this.curveTextbox1.BorderColor = System.Drawing.Color.Black;
            this.curveTextbox1.BorderFocusColor = System.Drawing.Color.HotPink;
            this.curveTextbox1.BorderRadius = 15;
            this.curveTextbox1.BorderSize = 2;
            this.curveTextbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.curveTextbox1.ForeColor = System.Drawing.Color.DimGray;
            this.curveTextbox1.Location = new System.Drawing.Point(12, 36);
            this.curveTextbox1.Multiline = false;
            this.curveTextbox1.Name = "curveTextbox1";
            this.curveTextbox1.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.curveTextbox1.PasswordChar = false;
            this.curveTextbox1.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.curveTextbox1.PlaceholderText = "";
            this.curveTextbox1.Size = new System.Drawing.Size(250, 31);
            this.curveTextbox1.TabIndex = 1;
            this.curveTextbox1.Texts = "";
            this.curveTextbox1.UnderlinedStyle = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(95, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Search";
            // 
            // panelBBHome
            // 
            this.panelBBHome.BackColor = System.Drawing.Color.DimGray;
            this.panelBBHome.Controls.Add(this.dataGridViewBBPlayers);
            this.panelBBHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBBHome.Location = new System.Drawing.Point(0, 100);
            this.panelBBHome.Name = "panelBBHome";
            this.panelBBHome.Size = new System.Drawing.Size(800, 350);
            this.panelBBHome.TabIndex = 3;
            // 
            // dataGridViewBBPlayers
            // 
            this.dataGridViewBBPlayers.AllowUserToAddRows = false;
            this.dataGridViewBBPlayers.AllowUserToDeleteRows = false;
            this.dataGridViewBBPlayers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBBPlayers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBBPlayers.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewBBPlayers.Name = "dataGridViewBBPlayers";
            this.dataGridViewBBPlayers.ReadOnly = true;
            this.dataGridViewBBPlayers.Size = new System.Drawing.Size(800, 350);
            this.dataGridViewBBPlayers.TabIndex = 0;
            // 
            // FormBasketball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelBBHome);
            this.Controls.Add(this.panelDash);
            this.Name = "FormBasketball";
            this.Text = "Basketball";
            this.panelDash.ResumeLayout(false);
            this.panelDash.PerformLayout();
            this.panelBBHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBBPlayers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelDash;
        private System.Windows.Forms.Panel panelBBHome;
        private CustomControls.CurveTextbox curveTextbox1;
        private System.Windows.Forms.DataGridView dataGridViewBBPlayers;
        private System.Windows.Forms.Label label2;
    }
}