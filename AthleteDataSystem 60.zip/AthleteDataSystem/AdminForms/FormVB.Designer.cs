﻿namespace AthleteDataSystem.AdminForms
{
    partial class FormVB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PanelCommands = new System.Windows.Forms.Panel();
            this.txtReceive = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelReceive = new System.Windows.Forms.Label();
            this.txtDig = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtAce = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtBlockPerGame = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtPointsPerGame = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtAverageSet = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtSetsPlayed = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtTeam = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtName = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.newBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelTeam = new System.Windows.Forms.Label();
            this.saveBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.updateBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelName = new System.Windows.Forms.Label();
            this.deleteBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelAverageSet = new System.Windows.Forms.Label();
            this.labelBlock = new System.Windows.Forms.Label();
            this.labelPoints = new System.Windows.Forms.Label();
            this.labelAce = new System.Windows.Forms.Label();
            this.labelDig = new System.Windows.Forms.Label();
            this.labelSetsPlayed = new System.Windows.Forms.Label();
            this.panelTable = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.PanelCommands.SuspendLayout();
            this.panelTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelCommands
            // 
            this.PanelCommands.BackColor = System.Drawing.Color.White;
            this.PanelCommands.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PanelCommands.Controls.Add(this.txtReceive);
            this.PanelCommands.Controls.Add(this.labelReceive);
            this.PanelCommands.Controls.Add(this.txtDig);
            this.PanelCommands.Controls.Add(this.txtAce);
            this.PanelCommands.Controls.Add(this.txtBlockPerGame);
            this.PanelCommands.Controls.Add(this.txtPointsPerGame);
            this.PanelCommands.Controls.Add(this.txtAverageSet);
            this.PanelCommands.Controls.Add(this.txtSetsPlayed);
            this.PanelCommands.Controls.Add(this.txtTeam);
            this.PanelCommands.Controls.Add(this.txtName);
            this.PanelCommands.Controls.Add(this.newBtn);
            this.PanelCommands.Controls.Add(this.labelTeam);
            this.PanelCommands.Controls.Add(this.saveBtn);
            this.PanelCommands.Controls.Add(this.updateBtn);
            this.PanelCommands.Controls.Add(this.labelName);
            this.PanelCommands.Controls.Add(this.deleteBtn);
            this.PanelCommands.Controls.Add(this.labelAverageSet);
            this.PanelCommands.Controls.Add(this.labelBlock);
            this.PanelCommands.Controls.Add(this.labelPoints);
            this.PanelCommands.Controls.Add(this.labelAce);
            this.PanelCommands.Controls.Add(this.labelDig);
            this.PanelCommands.Controls.Add(this.labelSetsPlayed);
            this.PanelCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelCommands.ForeColor = System.Drawing.Color.Black;
            this.PanelCommands.Location = new System.Drawing.Point(0, 0);
            this.PanelCommands.Name = "PanelCommands";
            this.PanelCommands.Size = new System.Drawing.Size(800, 150);
            this.PanelCommands.TabIndex = 56;
            // 
            // txtReceive
            // 
            this.txtReceive.BackColor = System.Drawing.SystemColors.Window;
            this.txtReceive.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtReceive.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtReceive.BorderRadius = 0;
            this.txtReceive.BorderSize = 2;
            this.txtReceive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceive.ForeColor = System.Drawing.Color.DimGray;
            this.txtReceive.Location = new System.Drawing.Point(725, 17);
            this.txtReceive.Multiline = false;
            this.txtReceive.Name = "txtReceive";
            this.txtReceive.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtReceive.PasswordChar = false;
            this.txtReceive.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtReceive.PlaceholderText = "";
            this.txtReceive.Size = new System.Drawing.Size(70, 31);
            this.txtReceive.TabIndex = 63;
            this.txtReceive.Texts = "";
            this.txtReceive.UnderlinedStyle = false;
            // 
            // labelReceive
            // 
            this.labelReceive.AutoSize = true;
            this.labelReceive.BackColor = System.Drawing.Color.Transparent;
            this.labelReceive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelReceive.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReceive.ForeColor = System.Drawing.Color.Black;
            this.labelReceive.Location = new System.Drawing.Point(654, 17);
            this.labelReceive.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelReceive.Name = "labelReceive";
            this.labelReceive.Size = new System.Drawing.Size(66, 20);
            this.labelReceive.TabIndex = 62;
            this.labelReceive.Text = "Receive";
            // 
            // txtDig
            // 
            this.txtDig.BackColor = System.Drawing.SystemColors.Window;
            this.txtDig.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtDig.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtDig.BorderRadius = 0;
            this.txtDig.BorderSize = 2;
            this.txtDig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDig.ForeColor = System.Drawing.Color.DimGray;
            this.txtDig.Location = new System.Drawing.Point(569, 58);
            this.txtDig.Multiline = false;
            this.txtDig.Name = "txtDig";
            this.txtDig.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtDig.PasswordChar = false;
            this.txtDig.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtDig.PlaceholderText = "";
            this.txtDig.Size = new System.Drawing.Size(70, 31);
            this.txtDig.TabIndex = 61;
            this.txtDig.Texts = "";
            this.txtDig.UnderlinedStyle = false;
            // 
            // txtAce
            // 
            this.txtAce.BackColor = System.Drawing.SystemColors.Window;
            this.txtAce.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtAce.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAce.BorderRadius = 0;
            this.txtAce.BorderSize = 2;
            this.txtAce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAce.ForeColor = System.Drawing.Color.DimGray;
            this.txtAce.Location = new System.Drawing.Point(569, 17);
            this.txtAce.Multiline = false;
            this.txtAce.Name = "txtAce";
            this.txtAce.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtAce.PasswordChar = false;
            this.txtAce.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAce.PlaceholderText = "";
            this.txtAce.Size = new System.Drawing.Size(70, 31);
            this.txtAce.TabIndex = 60;
            this.txtAce.Texts = "";
            this.txtAce.UnderlinedStyle = false;
            // 
            // txtBlockPerGame
            // 
            this.txtBlockPerGame.BackColor = System.Drawing.SystemColors.Window;
            this.txtBlockPerGame.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtBlockPerGame.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtBlockPerGame.BorderRadius = 0;
            this.txtBlockPerGame.BorderSize = 2;
            this.txtBlockPerGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBlockPerGame.ForeColor = System.Drawing.Color.DimGray;
            this.txtBlockPerGame.Location = new System.Drawing.Point(431, 58);
            this.txtBlockPerGame.Multiline = false;
            this.txtBlockPerGame.Name = "txtBlockPerGame";
            this.txtBlockPerGame.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtBlockPerGame.PasswordChar = false;
            this.txtBlockPerGame.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtBlockPerGame.PlaceholderText = "";
            this.txtBlockPerGame.Size = new System.Drawing.Size(70, 31);
            this.txtBlockPerGame.TabIndex = 59;
            this.txtBlockPerGame.Texts = "";
            this.txtBlockPerGame.UnderlinedStyle = false;
            // 
            // txtPointsPerGame
            // 
            this.txtPointsPerGame.BackColor = System.Drawing.SystemColors.Window;
            this.txtPointsPerGame.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtPointsPerGame.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPointsPerGame.BorderRadius = 0;
            this.txtPointsPerGame.BorderSize = 2;
            this.txtPointsPerGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPointsPerGame.ForeColor = System.Drawing.Color.DimGray;
            this.txtPointsPerGame.Location = new System.Drawing.Point(431, 17);
            this.txtPointsPerGame.Multiline = false;
            this.txtPointsPerGame.Name = "txtPointsPerGame";
            this.txtPointsPerGame.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPointsPerGame.PasswordChar = false;
            this.txtPointsPerGame.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPointsPerGame.PlaceholderText = "";
            this.txtPointsPerGame.Size = new System.Drawing.Size(70, 31);
            this.txtPointsPerGame.TabIndex = 58;
            this.txtPointsPerGame.Texts = "";
            this.txtPointsPerGame.UnderlinedStyle = false;
            // 
            // txtAverageSet
            // 
            this.txtAverageSet.BackColor = System.Drawing.SystemColors.Window;
            this.txtAverageSet.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtAverageSet.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAverageSet.BorderRadius = 0;
            this.txtAverageSet.BorderSize = 2;
            this.txtAverageSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAverageSet.ForeColor = System.Drawing.Color.DimGray;
            this.txtAverageSet.Location = new System.Drawing.Point(275, 56);
            this.txtAverageSet.Multiline = false;
            this.txtAverageSet.Name = "txtAverageSet";
            this.txtAverageSet.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtAverageSet.PasswordChar = false;
            this.txtAverageSet.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAverageSet.PlaceholderText = "";
            this.txtAverageSet.Size = new System.Drawing.Size(70, 31);
            this.txtAverageSet.TabIndex = 57;
            this.txtAverageSet.Texts = "";
            this.txtAverageSet.UnderlinedStyle = false;
            // 
            // txtSetsPlayed
            // 
            this.txtSetsPlayed.BackColor = System.Drawing.SystemColors.Window;
            this.txtSetsPlayed.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtSetsPlayed.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtSetsPlayed.BorderRadius = 0;
            this.txtSetsPlayed.BorderSize = 2;
            this.txtSetsPlayed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSetsPlayed.ForeColor = System.Drawing.Color.DimGray;
            this.txtSetsPlayed.Location = new System.Drawing.Point(275, 19);
            this.txtSetsPlayed.Multiline = false;
            this.txtSetsPlayed.Name = "txtSetsPlayed";
            this.txtSetsPlayed.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSetsPlayed.PasswordChar = false;
            this.txtSetsPlayed.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtSetsPlayed.PlaceholderText = "";
            this.txtSetsPlayed.Size = new System.Drawing.Size(70, 31);
            this.txtSetsPlayed.TabIndex = 56;
            this.txtSetsPlayed.Texts = "";
            this.txtSetsPlayed.UnderlinedStyle = false;
            // 
            // txtTeam
            // 
            this.txtTeam.BackColor = System.Drawing.SystemColors.Window;
            this.txtTeam.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtTeam.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTeam.BorderRadius = 0;
            this.txtTeam.BorderSize = 2;
            this.txtTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTeam.ForeColor = System.Drawing.Color.DimGray;
            this.txtTeam.Location = new System.Drawing.Point(90, 56);
            this.txtTeam.Multiline = false;
            this.txtTeam.Name = "txtTeam";
            this.txtTeam.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtTeam.PasswordChar = false;
            this.txtTeam.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtTeam.PlaceholderText = "";
            this.txtTeam.Size = new System.Drawing.Size(70, 31);
            this.txtTeam.TabIndex = 55;
            this.txtTeam.Texts = "";
            this.txtTeam.UnderlinedStyle = false;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtName.BorderRadius = 0;
            this.txtName.BorderSize = 2;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.ForeColor = System.Drawing.Color.DimGray;
            this.txtName.Location = new System.Drawing.Point(90, 17);
            this.txtName.Multiline = false;
            this.txtName.Name = "txtName";
            this.txtName.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtName.PasswordChar = false;
            this.txtName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtName.PlaceholderText = "";
            this.txtName.Size = new System.Drawing.Size(70, 31);
            this.txtName.TabIndex = 54;
            this.txtName.Texts = "";
            this.txtName.UnderlinedStyle = false;
            // 
            // newBtn
            // 
            this.newBtn.BackColor = System.Drawing.Color.White;
            this.newBtn.BackgroundColor = System.Drawing.Color.White;
            this.newBtn.BorderColor = System.Drawing.Color.Black;
            this.newBtn.BorderRadius = 15;
            this.newBtn.BorderSize = 2;
            this.newBtn.FlatAppearance.BorderSize = 0;
            this.newBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newBtn.ForeColor = System.Drawing.Color.Black;
            this.newBtn.Location = new System.Drawing.Point(243, 99);
            this.newBtn.Margin = new System.Windows.Forms.Padding(2);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(75, 32);
            this.newBtn.TabIndex = 49;
            this.newBtn.Text = "NEW";
            this.newBtn.TextColor = System.Drawing.Color.Black;
            this.newBtn.UseVisualStyleBackColor = false;
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // labelTeam
            // 
            this.labelTeam.AutoSize = true;
            this.labelTeam.BackColor = System.Drawing.Color.Transparent;
            this.labelTeam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelTeam.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTeam.ForeColor = System.Drawing.Color.Black;
            this.labelTeam.Location = new System.Drawing.Point(28, 56);
            this.labelTeam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTeam.Name = "labelTeam";
            this.labelTeam.Size = new System.Drawing.Size(57, 20);
            this.labelTeam.TabIndex = 32;
            this.labelTeam.Text = "Team:";
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.White;
            this.saveBtn.BackgroundColor = System.Drawing.Color.White;
            this.saveBtn.BorderColor = System.Drawing.Color.Black;
            this.saveBtn.BorderRadius = 15;
            this.saveBtn.BorderSize = 2;
            this.saveBtn.FlatAppearance.BorderSize = 0;
            this.saveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveBtn.ForeColor = System.Drawing.Color.Black;
            this.saveBtn.Location = new System.Drawing.Point(322, 99);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(2);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(75, 32);
            this.saveBtn.TabIndex = 50;
            this.saveBtn.Text = "SAVE";
            this.saveBtn.TextColor = System.Drawing.Color.Black;
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.White;
            this.updateBtn.BackgroundColor = System.Drawing.Color.White;
            this.updateBtn.BorderColor = System.Drawing.Color.Black;
            this.updateBtn.BorderRadius = 15;
            this.updateBtn.BorderSize = 2;
            this.updateBtn.FlatAppearance.BorderSize = 0;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateBtn.ForeColor = System.Drawing.Color.Black;
            this.updateBtn.Location = new System.Drawing.Point(401, 99);
            this.updateBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(75, 32);
            this.updateBtn.TabIndex = 52;
            this.updateBtn.Text = "UPDATE";
            this.updateBtn.TextColor = System.Drawing.Color.Black;
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelName.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.Black;
            this.labelName.Location = new System.Drawing.Point(28, 17);
            this.labelName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(59, 20);
            this.labelName.TabIndex = 51;
            this.labelName.Text = "Name:";
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.White;
            this.deleteBtn.BackgroundColor = System.Drawing.Color.White;
            this.deleteBtn.BorderColor = System.Drawing.Color.Black;
            this.deleteBtn.BorderRadius = 15;
            this.deleteBtn.BorderSize = 2;
            this.deleteBtn.FlatAppearance.BorderSize = 0;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteBtn.ForeColor = System.Drawing.Color.Black;
            this.deleteBtn.Location = new System.Drawing.Point(480, 99);
            this.deleteBtn.Margin = new System.Windows.Forms.Padding(2);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 32);
            this.deleteBtn.TabIndex = 53;
            this.deleteBtn.Text = "DELETE";
            this.deleteBtn.TextColor = System.Drawing.Color.Black;
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // labelAverageSet
            // 
            this.labelAverageSet.AutoSize = true;
            this.labelAverageSet.BackColor = System.Drawing.Color.Transparent;
            this.labelAverageSet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAverageSet.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAverageSet.ForeColor = System.Drawing.Color.Black;
            this.labelAverageSet.Location = new System.Drawing.Point(176, 58);
            this.labelAverageSet.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAverageSet.Name = "labelAverageSet";
            this.labelAverageSet.Size = new System.Drawing.Size(97, 20);
            this.labelAverageSet.TabIndex = 36;
            this.labelAverageSet.Text = "Average Set";
            // 
            // labelBlock
            // 
            this.labelBlock.AutoSize = true;
            this.labelBlock.BackColor = System.Drawing.Color.Transparent;
            this.labelBlock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBlock.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBlock.ForeColor = System.Drawing.Color.Black;
            this.labelBlock.Location = new System.Drawing.Point(370, 56);
            this.labelBlock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBlock.Name = "labelBlock";
            this.labelBlock.Size = new System.Drawing.Size(51, 20);
            this.labelBlock.TabIndex = 40;
            this.labelBlock.Text = "Block";
            // 
            // labelPoints
            // 
            this.labelPoints.AutoSize = true;
            this.labelPoints.BackColor = System.Drawing.Color.Transparent;
            this.labelPoints.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPoints.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPoints.ForeColor = System.Drawing.Color.Black;
            this.labelPoints.Location = new System.Drawing.Point(370, 17);
            this.labelPoints.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPoints.Name = "labelPoints";
            this.labelPoints.Size = new System.Drawing.Size(56, 20);
            this.labelPoints.TabIndex = 38;
            this.labelPoints.Text = "Points";
            // 
            // labelAce
            // 
            this.labelAce.AutoSize = true;
            this.labelAce.BackColor = System.Drawing.Color.Transparent;
            this.labelAce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAce.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAce.ForeColor = System.Drawing.Color.Black;
            this.labelAce.Location = new System.Drawing.Point(528, 19);
            this.labelAce.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAce.Name = "labelAce";
            this.labelAce.Size = new System.Drawing.Size(36, 20);
            this.labelAce.TabIndex = 42;
            this.labelAce.Text = "Ace";
            // 
            // labelDig
            // 
            this.labelDig.AutoSize = true;
            this.labelDig.BackColor = System.Drawing.Color.Transparent;
            this.labelDig.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelDig.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDig.ForeColor = System.Drawing.Color.Black;
            this.labelDig.Location = new System.Drawing.Point(528, 56);
            this.labelDig.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelDig.Name = "labelDig";
            this.labelDig.Size = new System.Drawing.Size(36, 20);
            this.labelDig.TabIndex = 43;
            this.labelDig.Text = "Dig";
            // 
            // labelSetsPlayed
            // 
            this.labelSetsPlayed.AutoSize = true;
            this.labelSetsPlayed.BackColor = System.Drawing.Color.Transparent;
            this.labelSetsPlayed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelSetsPlayed.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSetsPlayed.ForeColor = System.Drawing.Color.Black;
            this.labelSetsPlayed.Location = new System.Drawing.Point(176, 17);
            this.labelSetsPlayed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSetsPlayed.Name = "labelSetsPlayed";
            this.labelSetsPlayed.Size = new System.Drawing.Size(94, 20);
            this.labelSetsPlayed.TabIndex = 35;
            this.labelSetsPlayed.Text = "Sets Played";
            // 
            // panelTable
            // 
            this.panelTable.Controls.Add(this.dataGridView1);
            this.panelTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTable.ForeColor = System.Drawing.Color.Black;
            this.panelTable.Location = new System.Drawing.Point(0, 150);
            this.panelTable.Name = "panelTable";
            this.panelTable.Size = new System.Drawing.Size(800, 300);
            this.panelTable.TabIndex = 57;
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Size = new System.Drawing.Size(800, 300);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // FormVB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelTable);
            this.Controls.Add(this.PanelCommands);
            this.Name = "FormVB";
            this.Text = "FormVB";
            this.PanelCommands.ResumeLayout(false);
            this.PanelCommands.PerformLayout();
            this.panelTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelCommands;
        private CustomControls.CurveTextbox txtDig;
        private CustomControls.CurveTextbox txtAce;
        private CustomControls.CurveTextbox txtBlockPerGame;
        private CustomControls.CurveTextbox txtPointsPerGame;
        private CustomControls.CurveTextbox txtAverageSet;
        private CustomControls.CurveTextbox txtSetsPlayed;
        private CustomControls.CurveTextbox txtTeam;
        private CustomControls.CurveTextbox txtName;
        private CustomTools.CurvedButton newBtn;
        private System.Windows.Forms.Label labelTeam;
        private CustomTools.CurvedButton saveBtn;
        private CustomTools.CurvedButton updateBtn;
        private System.Windows.Forms.Label labelName;
        private CustomTools.CurvedButton deleteBtn;
        private System.Windows.Forms.Label labelAverageSet;
        private System.Windows.Forms.Label labelBlock;
        private System.Windows.Forms.Label labelPoints;
        private System.Windows.Forms.Label labelAce;
        private System.Windows.Forms.Label labelDig;
        private System.Windows.Forms.Label labelSetsPlayed;
        private System.Windows.Forms.Label labelReceive;
        private CustomControls.CurveTextbox txtReceive;
        private System.Windows.Forms.Panel panelTable;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}