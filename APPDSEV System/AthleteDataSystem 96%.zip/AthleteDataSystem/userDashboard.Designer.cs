﻿namespace AthleteDataSystem
{
    partial class userDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userDashboard));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnLogout = new AthleteDataSystem.CustomTools.CurvedButton();
            this.btnGames = new System.Windows.Forms.Button();
            this.btnVolleyball = new System.Windows.Forms.Button();
            this.btnBasketball = new System.Windows.Forms.Button();
            this.btnProfile = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelTitleBar = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelDesktopPane = new System.Windows.Forms.Panel();
            this.panelFeatured2 = new System.Windows.Forms.Panel();
            this.btnFeatured2 = new System.Windows.Forms.Button();
            this.panelFeatured1 = new System.Windows.Forms.Panel();
            this.btnFeatured1 = new System.Windows.Forms.Button();
            this.lblFeatured = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            this.panelTitleBar.SuspendLayout();
            this.panelDesktopPane.SuspendLayout();
            this.panelFeatured2.SuspendLayout();
            this.panelFeatured1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panelMenu.Controls.Add(this.btnAbout);
            this.panelMenu.Controls.Add(this.btnLogout);
            this.panelMenu.Controls.Add(this.btnGames);
            this.panelMenu.Controls.Add(this.btnVolleyball);
            this.panelMenu.Controls.Add(this.btnBasketball);
            this.panelMenu.Controls.Add(this.btnProfile);
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(200, 611);
            this.panelMenu.TabIndex = 1;
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.btnAbout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnAbout.FlatAppearance.BorderSize = 0;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.ForeColor = System.Drawing.Color.White;
            this.btnAbout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAbout.Location = new System.Drawing.Point(0, 521);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(200, 50);
            this.btnAbout.TabIndex = 7;
            this.btnAbout.Text = "About Us";
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.White;
            this.btnLogout.BackgroundColor = System.Drawing.Color.White;
            this.btnLogout.BorderColor = System.Drawing.Color.Black;
            this.btnLogout.BorderRadius = 20;
            this.btnLogout.BorderSize = 1;
            this.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Black;
            this.btnLogout.Location = new System.Drawing.Point(0, 571);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(200, 40);
            this.btnLogout.TabIndex = 6;
            this.btnLogout.Text = "Log out";
            this.btnLogout.TextColor = System.Drawing.Color.Black;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnGames
            // 
            this.btnGames.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.btnGames.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGames.FlatAppearance.BorderSize = 0;
            this.btnGames.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGames.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGames.ForeColor = System.Drawing.Color.White;
            this.btnGames.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGames.Location = new System.Drawing.Point(0, 260);
            this.btnGames.Name = "btnGames";
            this.btnGames.Size = new System.Drawing.Size(200, 60);
            this.btnGames.TabIndex = 5;
            this.btnGames.Text = "Games\r\nSchedules";
            this.btnGames.UseVisualStyleBackColor = false;
            this.btnGames.Click += new System.EventHandler(this.btnGames_Click);
            // 
            // btnVolleyball
            // 
            this.btnVolleyball.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.btnVolleyball.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnVolleyball.FlatAppearance.BorderSize = 0;
            this.btnVolleyball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolleyball.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolleyball.ForeColor = System.Drawing.Color.White;
            this.btnVolleyball.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolleyball.Location = new System.Drawing.Point(0, 200);
            this.btnVolleyball.Name = "btnVolleyball";
            this.btnVolleyball.Size = new System.Drawing.Size(200, 60);
            this.btnVolleyball.TabIndex = 4;
            this.btnVolleyball.Text = "Women\'s\r\nVolleyball";
            this.btnVolleyball.UseVisualStyleBackColor = false;
            this.btnVolleyball.Click += new System.EventHandler(this.btnVolleyball_Click);
            // 
            // btnBasketball
            // 
            this.btnBasketball.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.btnBasketball.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBasketball.FlatAppearance.BorderSize = 0;
            this.btnBasketball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBasketball.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBasketball.ForeColor = System.Drawing.Color.White;
            this.btnBasketball.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBasketball.Location = new System.Drawing.Point(0, 140);
            this.btnBasketball.Name = "btnBasketball";
            this.btnBasketball.Size = new System.Drawing.Size(200, 60);
            this.btnBasketball.TabIndex = 3;
            this.btnBasketball.Text = "Men\'s\r\nBasketball";
            this.btnBasketball.UseVisualStyleBackColor = false;
            this.btnBasketball.Click += new System.EventHandler(this.btnBasketball_Click);
            // 
            // btnProfile
            // 
            this.btnProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.btnProfile.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnProfile.FlatAppearance.BorderSize = 0;
            this.btnProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProfile.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProfile.ForeColor = System.Drawing.Color.White;
            this.btnProfile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProfile.Location = new System.Drawing.Point(0, 80);
            this.btnProfile.Name = "btnProfile";
            this.btnProfile.Size = new System.Drawing.Size(200, 60);
            this.btnProfile.TabIndex = 2;
            this.btnProfile.Text = "Profile";
            this.btnProfile.UseVisualStyleBackColor = false;
            this.btnProfile.Click += new System.EventHandler(this.btnProfile_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panelLogo.Controls.Add(this.labelTitle);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(200, 80);
            this.panelLogo.TabIndex = 0;
            // 
            // labelTitle
            // 
            this.labelTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelTitle.AutoSize = true;
            this.labelTitle.BackColor = System.Drawing.Color.Transparent;
            this.labelTitle.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.White;
            this.labelTitle.Location = new System.Drawing.Point(12, 26);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(0, 28);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelTitleBar
            // 
            this.panelTitleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panelTitleBar.Controls.Add(this.btnBack);
            this.panelTitleBar.Controls.Add(this.lblTitle);
            this.panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitleBar.Location = new System.Drawing.Point(200, 0);
            this.panelTitleBar.Name = "panelTitleBar";
            this.panelTitleBar.Size = new System.Drawing.Size(804, 80);
            this.panelTitleBar.TabIndex = 2;
            // 
            // btnBack
            // 
            this.btnBack.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnBack.FlatAppearance.BorderSize = 0;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Image = ((System.Drawing.Image)(resources.GetObject("btnBack.Image")));
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 80);
            this.btnBack.TabIndex = 2;
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(90, 26);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(78, 28);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "HOME";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelDesktopPane
            // 
            this.panelDesktopPane.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.panelDesktopPane.Controls.Add(this.panelFeatured2);
            this.panelDesktopPane.Controls.Add(this.panelFeatured1);
            this.panelDesktopPane.Controls.Add(this.lblFeatured);
            this.panelDesktopPane.Controls.Add(this.pictureBox1);
            this.panelDesktopPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDesktopPane.Location = new System.Drawing.Point(200, 80);
            this.panelDesktopPane.Name = "panelDesktopPane";
            this.panelDesktopPane.Size = new System.Drawing.Size(804, 531);
            this.panelDesktopPane.TabIndex = 3;
            // 
            // panelFeatured2
            // 
            this.panelFeatured2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelFeatured2.Controls.Add(this.btnFeatured2);
            this.panelFeatured2.Location = new System.Drawing.Point(421, 221);
            this.panelFeatured2.Name = "panelFeatured2";
            this.panelFeatured2.Size = new System.Drawing.Size(350, 250);
            this.panelFeatured2.TabIndex = 11;
            // 
            // btnFeatured2
            // 
            this.btnFeatured2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFeatured2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFeatured2.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFeatured2.ForeColor = System.Drawing.Color.White;
            this.btnFeatured2.Image = global::AthleteDataSystem.Properties.Resources.SWU_NEWS;
            this.btnFeatured2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnFeatured2.Location = new System.Drawing.Point(0, 0);
            this.btnFeatured2.Name = "btnFeatured2";
            this.btnFeatured2.Size = new System.Drawing.Size(350, 250);
            this.btnFeatured2.TabIndex = 0;
            this.btnFeatured2.Text = "SWU-Phinma Cobras to exit Cesafi after 2023-2024 season";
            this.btnFeatured2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnFeatured2.UseVisualStyleBackColor = true;
            this.btnFeatured2.Click += new System.EventHandler(this.btnFeatured2_Click);
            // 
            // panelFeatured1
            // 
            this.panelFeatured1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelFeatured1.Controls.Add(this.btnFeatured1);
            this.panelFeatured1.Location = new System.Drawing.Point(34, 221);
            this.panelFeatured1.Name = "panelFeatured1";
            this.panelFeatured1.Size = new System.Drawing.Size(350, 250);
            this.panelFeatured1.TabIndex = 10;
            // 
            // btnFeatured1
            // 
            this.btnFeatured1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFeatured1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFeatured1.Font = new System.Drawing.Font("Cambria", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFeatured1.ForeColor = System.Drawing.Color.White;
            this.btnFeatured1.Image = global::AthleteDataSystem.Properties.Resources.basketball_featured;
            this.btnFeatured1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnFeatured1.Location = new System.Drawing.Point(0, 0);
            this.btnFeatured1.Name = "btnFeatured1";
            this.btnFeatured1.Size = new System.Drawing.Size(350, 250);
            this.btnFeatured1.TabIndex = 0;
            this.btnFeatured1.Text = "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nFour players who made me fall in love with Basketball";
            this.btnFeatured1.UseVisualStyleBackColor = true;
            this.btnFeatured1.Click += new System.EventHandler(this.btnFeatured1_Click);
            // 
            // lblFeatured
            // 
            this.lblFeatured.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFeatured.AutoSize = true;
            this.lblFeatured.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeatured.ForeColor = System.Drawing.Color.White;
            this.lblFeatured.Location = new System.Drawing.Point(327, 173);
            this.lblFeatured.Name = "lblFeatured";
            this.lblFeatured.Size = new System.Drawing.Size(166, 25);
            this.lblFeatured.TabIndex = 9;
            this.lblFeatured.Text = "Featured Articles";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(804, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // userDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(1004, 611);
            this.Controls.Add(this.panelDesktopPane);
            this.Controls.Add(this.panelTitleBar);
            this.Controls.Add(this.panelMenu);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(1020, 650);
            this.Name = "userDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "userDashboard";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.userDashboard_FormClosed);
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            this.panelTitleBar.ResumeLayout(false);
            this.panelTitleBar.PerformLayout();
            this.panelDesktopPane.ResumeLayout(false);
            this.panelDesktopPane.PerformLayout();
            this.panelFeatured2.ResumeLayout(false);
            this.panelFeatured1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Button btnBasketball;
        private System.Windows.Forms.Button btnProfile;
        private System.Windows.Forms.Button btnVolleyball;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panelDesktopPane;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnGames;
        private System.Windows.Forms.Label lblFeatured;
        private CustomTools.CurvedButton btnLogout;
        private System.Windows.Forms.Panel panelFeatured1;
        private System.Windows.Forms.Panel panelFeatured2;
        private System.Windows.Forms.Button btnFeatured1;
        private System.Windows.Forms.Button btnFeatured2;
        private System.Windows.Forms.Button btnAbout;
    }
}