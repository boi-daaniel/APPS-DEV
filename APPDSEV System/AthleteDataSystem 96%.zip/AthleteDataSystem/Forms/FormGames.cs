﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormGames : Form
    {
        public FormGames()
        {
            InitializeComponent();
            LoadGamesTable();
        }

        private void LoadGamesTable()
        {
            try
            {
                string query = "SELECT * FROM games";
                DBHelper.DBHelper.fill(query, dataGridViewGames);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }
}
