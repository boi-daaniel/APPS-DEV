﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormBasketball : Form
    {

        //Constructor
        public FormBasketball()
        {
            InitializeComponent();
            LoadBasketballPlayersHome();
            LoadBasketballPlayersInfo();
        }

        private void FormBasketball_Load(object sender, EventArgs e)
        {
            dataGridViewBBPlayersHome.Columns["PlayerID"].Visible = false;
            dataGridViewBBPlayersHome.Columns["PPG"].Visible = false;
            dataGridViewBBPlayersHome.Columns["APG"].Visible = false;
            dataGridViewBBPlayersHome.Columns["RPG"].Visible = false;
            dataGridViewBBPlayersHome.Columns["SPG"].Visible = false;
            dataGridViewBBPlayersStats.Columns["PlayerID"].Visible = false;
            dataGridViewBBPlayersHome.Sort(dataGridViewBBPlayersHome.Columns["PlayerID"], System.ComponentModel.ListSortDirection.Ascending);
        }

        //Load Players Stats
        private void LoadBasketballPlayersHome()
        {
            try
            {
                string query = "SELECT * FROM basketballPlayersInfo";
                DBHelper.DBHelper.fill(query, dataGridViewBBPlayersHome);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        //Load Player Info
        private void LoadBasketballPlayersInfo()
        {
            try
            {
                string query = "SELECT * FROM basketballPlayers";
                DBHelper.DBHelper.fill(query, dataGridViewBBPlayersStats);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        #region -> Buttons
        //Players Home Search Button
        private void btnSearchHome_Click(object sender, EventArgs e)
        {
            string searchedPlayersHome = txtSearchHome.Texts.Trim();

            try
            {
                string query = "SELECT * from basketballPlayersInfo where PlayerName like '" + searchedPlayersHome + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("Player " + searchedPlayersHome + " does not exist. Try entering full name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                DBHelper.DBHelper.fill(query, dataGridViewBBPlayersHome);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter full name of the player.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Keydown
        private void txtSearchHome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearchHome_Click(sender, e);
            }
        }

        //Players Stats Search Button
        private void btnSearchStats_Click(object sender, EventArgs e)
        {
            string searchedPlayerStats = txtSearchStats.Texts.Trim();

            try
            {
                string query = "SELECT * from basketballPlayers where PlayerName like '" + searchedPlayerStats + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("Player " + searchedPlayerStats + " does not exist. Try entering full name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                DBHelper.DBHelper.fill(query, dataGridViewBBPlayersStats);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter full name of the player.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Keydown
        private void txtSearchStats_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearchStats_Click(sender, e);
            }
        }
        #endregion

        private void dataGridViewBBPlayersHome_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int playerProfileColumnIndex = 0; // Index of the image column

            if (e.ColumnIndex == playerProfileColumnIndex && e.RowIndex >= 0)
            {
                string playerName = dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["PlayerName"].Value.ToString();
                string team = dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["Team"].Value.ToString();
                int jerseyNumber = Convert.ToInt32(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["Jersey Number"].Value);
                string position = dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["Position"].Value.ToString();
                double points = Convert.ToDouble(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["PPG"].Value);
                double assists = Convert.ToDouble(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["APG"].Value);
                double rebounds = Convert.ToDouble(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["RPG"].Value);
                double steals = Convert.ToDouble(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["SPG"].Value);
                double height = Convert.ToDouble(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["Height"].Value);
                int weight = Convert.ToInt32(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["Weight"].Value);
                int age = Convert.ToInt32(dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["Age"].Value);
                string birthday = dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["Birthdate"].Value.ToString();
                double efficiency = Convert.ToDouble(dataGridViewBBPlayersStats.Rows[e.RowIndex].Cells["Efficiency"].Value);
                byte[] imageBytes = dataGridViewBBPlayersHome.Rows[e.RowIndex].Cells["PlayerProfile"].Value as byte[];
                Image playerImage = null;

                if (imageBytes != null && imageBytes.Length > 0)
                {
                    playerImage = ConvertToImage(imageBytes);
                }

                FormBasketballProfiles openProfile = new FormBasketballProfiles(playerName, team, jerseyNumber, position, points, assists, rebounds, steals, height, weight, age, birthday, efficiency, playerImage);
                openProfile.Show();
            }
        }

    }
}
