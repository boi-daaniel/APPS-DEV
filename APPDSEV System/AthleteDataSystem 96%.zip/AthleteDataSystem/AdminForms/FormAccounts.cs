﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormAccounts : Form
    {
        //Constructor
        public FormAccounts()
        {
            InitializeComponent();
            LoadAccounts();
        }

        //Form Load
        private void FormAccounts_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns["ProfilePicture"].Visible = false;
        }

        //Load Table
        private void LoadAccounts()
        {
            try
            {
                string query = "SELECT * FROM accounts";
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        //Clear Text Fields
        private void ClearFields()
        {
            txtUsername.Texts = "";
            txtPassword.Texts = "";
            txtFullName.Texts = "";
            txtEmail.Texts = "";
            pictureBox1.Image = null;
        }

        //Cell Click
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtUsername.Texts = dataGridView1[1, e.RowIndex].Value.ToString();
                txtPassword.Texts = dataGridView1[2, e.RowIndex].Value.ToString();
                txtFullName.Texts = dataGridView1[3, e.RowIndex].Value.ToString();
                txtEmail.Texts = dataGridView1[4, e.RowIndex].Value.ToString();

                if (dataGridView1[5, e.RowIndex].Value != DBNull.Value)
                {
                    byte[] imageBytes = (byte[])dataGridView1[5, e.RowIndex].Value;
                    using (MemoryStream ms = new MemoryStream(imageBytes))
                    {
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    pictureBox1.Image = null;
                }
            }
            catch (Exception)
            { }
        }

        #region -> Buttons
        //New Button
        private void newBtn_Click(object sender, EventArgs e) 
        {
            ClearFields();
        }

        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO accounts (username, [password], fullName, Email, ProfilePicture) VALUES ('" + txtUsername.Texts + "', '" + txtPassword.Texts + "', '" + txtFullName.Texts + "', '" + txtEmail.Texts + "', @ProfilePicture)";
                OleDbConnection connection = new OleDbConnection(Connection.Connection.dbconnect);
                OleDbCommand command = new OleDbCommand(sql, connection);

                if (pictureBox1.Image != null)
                {
                    MemoryStream ms = new MemoryStream();
                    pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                    command.Parameters.AddWithValue("@ProfilePicture", ms.ToArray());
                }
                else
                {
                    command.Parameters.AddWithValue("@ProfilePicture", DBNull.Value);
                }

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("User added successfully.", "Save Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAccounts(); // Refresh the data in the DataGridView
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update Button
        private void updateBtn_Click(object sender, EventArgs e) 
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];

                if (selectedRow["ID"] != DBNull.Value)
                {
                    try
                    {
                        string sql = "UPDATE accounts SET username = '" + txtUsername.Texts + "', " + "[password] = '" + txtPassword.Texts + "', " + "fullName = '" + txtFullName.Texts + "', Email = '" + txtEmail.Texts + "', ProfilePicture = @ProfilePicture WHERE ID = " + selectedRow["ID"];

                        OleDbConnection connection = new OleDbConnection(Connection.Connection.dbconnect);
                        OleDbCommand command = new OleDbCommand(sql, connection);

                        if (pictureBox1.Image != null)
                        {
                            MemoryStream ms = new MemoryStream();
                            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                            command.Parameters.AddWithValue("@ProfilePicture", ms.ToArray());
                        }
                        else
                        {
                            command.Parameters.AddWithValue("@ProfilePicture", DBNull.Value);
                        }

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();

                        MessageBox.Show("User updated successfully.", "Update Account", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadAccounts(); // Refresh the data in the DataGridView
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("ID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];


                        if (selectedRow["ID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM accounts WHERE ID = " + selectedRow["ID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.", "Delete User", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadAccounts(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("ID cannot be null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Delete User", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //Search Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchedUser = txtSearch.Texts.Trim();

            try
            {
                string query = "SELECT * from accounts where username like '" + searchedUser + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("user " + searchedUser + " does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter a valid user!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSearch.Texts = "";
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Browse Button
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }

        //Keydown
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }
        #endregion
    }
}
