﻿namespace AthleteDataSystem.Forms
{
    partial class FormBasketball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelDash = new System.Windows.Forms.Panel();
            this.btnSearch = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelSearch = new System.Windows.Forms.Label();
            this.panelBBHome = new System.Windows.Forms.Panel();
            this.dataGridViewBBPlayers = new System.Windows.Forms.DataGridView();
            this.panelDash.SuspendLayout();
            this.panelBBHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBBPlayers)).BeginInit();
            this.SuspendLayout();
            // 
            // panelDash
            // 
            this.panelDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelDash.Controls.Add(this.btnSearch);
            this.panelDash.Controls.Add(this.labelSearch);
            this.panelDash.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDash.Location = new System.Drawing.Point(0, 0);
            this.panelDash.Name = "panelDash";
            this.panelDash.Size = new System.Drawing.Size(800, 100);
            this.panelDash.TabIndex = 2;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.Window;
            this.btnSearch.BorderColor = System.Drawing.Color.Black;
            this.btnSearch.BorderFocusColor = System.Drawing.Color.HotPink;
            this.btnSearch.BorderRadius = 15;
            this.btnSearch.BorderSize = 2;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.DimGray;
            this.btnSearch.Location = new System.Drawing.Point(12, 36);
            this.btnSearch.Multiline = false;
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.btnSearch.PasswordChar = false;
            this.btnSearch.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.btnSearch.PlaceholderText = "";
            this.btnSearch.Size = new System.Drawing.Size(250, 31);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Texts = "";
            this.btnSearch.UnderlinedStyle = false;
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.ForeColor = System.Drawing.Color.White;
            this.labelSearch.Location = new System.Drawing.Point(95, 9);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(80, 24);
            this.labelSearch.TabIndex = 2;
            this.labelSearch.Text = "Search";
            // 
            // panelBBHome
            // 
            this.panelBBHome.BackColor = System.Drawing.Color.DimGray;
            this.panelBBHome.Controls.Add(this.dataGridViewBBPlayers);
            this.panelBBHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBBHome.Location = new System.Drawing.Point(0, 100);
            this.panelBBHome.Name = "panelBBHome";
            this.panelBBHome.Size = new System.Drawing.Size(800, 350);
            this.panelBBHome.TabIndex = 3;
            // 
            // dataGridViewBBPlayers
            // 
            this.dataGridViewBBPlayers.AllowUserToAddRows = false;
            this.dataGridViewBBPlayers.AllowUserToDeleteRows = false;
            this.dataGridViewBBPlayers.AllowUserToResizeColumns = false;
            this.dataGridViewBBPlayers.AllowUserToResizeRows = false;
            this.dataGridViewBBPlayers.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dataGridViewBBPlayers.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewBBPlayers.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewBBPlayers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkSlateGray;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBBPlayers.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewBBPlayers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewBBPlayers.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewBBPlayers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBBPlayers.EnableHeadersVisualStyles = false;
            this.dataGridViewBBPlayers.GridColor = System.Drawing.Color.DarkSlateGray;
            this.dataGridViewBBPlayers.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewBBPlayers.Name = "dataGridViewBBPlayers";
            this.dataGridViewBBPlayers.ReadOnly = true;
            this.dataGridViewBBPlayers.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridViewBBPlayers.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewBBPlayers.Size = new System.Drawing.Size(800, 350);
            this.dataGridViewBBPlayers.TabIndex = 0;
            // 
            // FormBasketball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelBBHome);
            this.Controls.Add(this.panelDash);
            this.Name = "FormBasketball";
            this.Text = "Basketball";
            this.panelDash.ResumeLayout(false);
            this.panelDash.PerformLayout();
            this.panelBBHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBBPlayers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelDash;
        private System.Windows.Forms.Panel panelBBHome;
        private CustomControls.CurveTextbox btnSearch;
        private System.Windows.Forms.DataGridView dataGridViewBBPlayers;
        private System.Windows.Forms.Label labelSearch;
    }
}