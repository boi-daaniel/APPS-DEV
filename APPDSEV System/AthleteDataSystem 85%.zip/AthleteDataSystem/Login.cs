﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

namespace AthleteDataSystem
{
    public partial class Login : Form
    {
        public static string sendtext = "";
        private string username;

        //Constructor
        public Login()
        {
            InitializeComponent();
            timer1.Tick += new EventHandler(timer1_Tick);
        }

        #region -> Methods

        #region -> Buttons
        //Login Button
        private void loginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select * from accounts where [username] = '" + txtusername.Texts + "' and [password] = '" + txtpassword.Texts + "'";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                    username = DBHelper.DBHelper.reader["username"].ToString();
                    string password = DBHelper.DBHelper.reader["password"].ToString();

                    timer1.Enabled = true;
                    timer1.Interval = 5;
                    progressBar1.Maximum = 100;
                    progressBar1.Value = 0;
                    timer1.Start();
                }
                else
                {
                    MessageBox.Show("Invalid Username and Password");
                }

                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        //Create Account Button
        private void createAccountBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the Players form
            CreateAccount createAccountForm = new CreateAccount();
            createAccountForm.Show();
        }
        #endregion

        // Timer Properties Method
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < progressBar1.Maximum)
            {
                progressBar1.Value ++;
            }
            else
            {
                timer1.Stop();
                progressBar1.Value = 0;

                if (username == "admin")
                {
                    // Redirect to adminDashboard
                    this.Hide();
                    adminDashboard adminForm = new adminDashboard();
                    adminForm.Show();
                }
                else
                {
                    // Redirect to userDashboard
                    this.Hide();
                    userDashboard userForm = new userDashboard(username);
                    userForm.Show();
                }
            }
        }

        //Close form
        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application
        }
        #endregion

    }
}
