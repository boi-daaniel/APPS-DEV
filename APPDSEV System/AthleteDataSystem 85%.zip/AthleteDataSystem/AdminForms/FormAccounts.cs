﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormAccounts : Form
    {
        //Constructor
        public FormAccounts()
        {
            InitializeComponent();
            LoadAccounts();
        }

        #region -> Methods
        //Load Table
        private void LoadAccounts()
        {
            try
            {
                string query = "SELECT * FROM accounts";
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        //Clear Text Fields
        private void ClearFields()
        {
            txtUsername.Texts = "";
            txtPassword.Texts = "";
            txtFullName.Texts = "";
        }

        //Cell Click
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtUsername.Texts = dataGridView1[1, e.RowIndex].Value.ToString();
                txtPassword.Texts = dataGridView1[2, e.RowIndex].Value.ToString();
                txtFullName.Texts = dataGridView1[3, e.RowIndex].Value.ToString();
            }
            catch (Exception)
            { }
        }

        #region -> Buttons
        //New Button
        private void newBtn_Click(object sender, EventArgs e) 
        {
            ClearFields();
        }

        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO accounts(username, [password], fullName)" + "values('" + txtUsername.Texts + "'," + "'" + txtPassword.Texts + "'," + "'" + txtFullName.Texts + "')";

                DBHelper.DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added successfully.", "Save Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAccounts(); // Refresh the data in the DataGridView
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update Button
        private void updateBtn_Click(object sender, EventArgs e) 
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];

                if (selectedRow["ID"] != DBNull.Value)
                {
                    string sql = "UPDATE accounts SET " + "username = '" + txtUsername.Texts + "', " + "[password] = '" + txtPassword.Texts + "', " + "fullName = '" + txtFullName.Texts + "'" + " WHERE ID = " + selectedRow["ID"];
                    DBHelper.DBHelper.ModifyRecord(sql);
                    MessageBox.Show("Data has been updated successfully.", "Update Account", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAccounts(); // Refresh the data in the DataGridView
                }
                else
                {
                    MessageBox.Show("ID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];


                        if (selectedRow["ID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM accounts WHERE ID = " + selectedRow["ID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.", "Delete User", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadAccounts(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("ID cannot be null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Delete User", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #endregion
    }
}
