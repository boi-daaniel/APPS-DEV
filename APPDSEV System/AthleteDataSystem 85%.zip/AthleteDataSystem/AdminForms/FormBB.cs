﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormBB : Form
    {

        //Constructor
        public FormBB()
        {
            InitializeComponent();
            LoadBasketballPlayers();
        }

        #region -> Methods
        //Load Table
        private void LoadBasketballPlayers()
        {
            try
            {
                string query = "SELECT * FROM basketballPlayers";
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        //Clear Text Fields
        private void ClearFields()
        {
            txtName.Texts = "";
            txtTeam.Texts = "";
            txtGamesPlayed.Texts = "";
            txtAverageMinutes.Texts = "";
            txtPointsPerGame.Texts = "";
            txtAssistPerGame.Texts = "";
            txtFieldGoalMades.Texts = "";
            txtFieldGoalAttempted.Texts = "";
        }

        // Cellclick
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtName.Texts = dataGridView1[1, e.RowIndex].Value.ToString();
                txtTeam.Texts = dataGridView1[2, e.RowIndex].Value.ToString();
                txtGamesPlayed.Texts = dataGridView1[3, e.RowIndex].Value.ToString();
                txtAverageMinutes.Texts = dataGridView1[4, e.RowIndex].Value.ToString();
                txtPointsPerGame.Texts = dataGridView1[5, e.RowIndex].Value.ToString();
                txtAssistPerGame.Texts = dataGridView1[6, e.RowIndex].Value.ToString();
                txtFieldGoalMades.Texts = dataGridView1[7, e.RowIndex].Value.ToString();
                txtFieldGoalAttempted.Texts = dataGridView1[8, e.RowIndex].Value.ToString();
            }
            catch (Exception)
            { }
        }

        #region -> Buttons
        //New
        private void newBtn_Click(object sender, EventArgs e) 
        {
            ClearFields();
        }

        //Save 
        private void saveBtn_Click(object sender, EventArgs e) 
        {
            try
            {
                string sql = "INSERT INTO basketballPlayers (PlayerName, Team, GamesPlayed, AverageMinutes, PointsPerGame, AssistPerGame, FieldGoalsMade, FieldGoalsAttempted) " + "VALUES (" + "'" + txtName.Texts + "', " + "'" + txtTeam.Texts + "', " + int.Parse(txtGamesPlayed.Texts) + ", " + double.Parse(txtAverageMinutes.Texts) + ", " + double.Parse(txtPointsPerGame.Texts) + ", " + double.Parse(txtAssistPerGame.Texts) + ", " + double.Parse(txtFieldGoalMades.Texts) + ", " + double.Parse(txtFieldGoalAttempted.Texts) + ")";
                DBHelper.DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added successfully.", "Save Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadBasketballPlayers(); // Refresh the data in the DataGridView
                ClearFields(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update
        private void updateBtn_Click(object sender, EventArgs e) 
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];

                if (selectedRow["PlayerID"] != DBNull.Value)
                {
                    string sql = "UPDATE basketballPlayers SET " + "PlayerName = '" + txtName.Texts + "', " + "Team = '" + txtTeam.Texts + "', " + "GamesPlayed = " + int.Parse(txtGamesPlayed.Texts) + ", " + "AverageMinutes = " + double.Parse(txtAverageMinutes.Texts) + ", " + "PointsPerGame = " + double.Parse(txtPointsPerGame.Texts) + ", " + "AssistPerGame = " + double.Parse(txtAssistPerGame.Texts) + ", " + "FieldGoalsMade = " + double.Parse(txtFieldGoalMades.Texts) + ", " + "FieldGoalsAttempted = " + double.Parse(txtFieldGoalAttempted.Texts) + " WHERE PlayerID = " + selectedRow["PlayerID"];
                    DBHelper.DBHelper.ModifyRecord(sql);
                    MessageBox.Show("Data has been updated successfully.", "Update Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBasketballPlayers(); // Refresh the data in the DataGridView
                }
                else
                {
                    MessageBox.Show("PlayerID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        //Delete
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];


                        if (selectedRow["PlayerID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM basketballPlayers WHERE PlayerID = " + selectedRow["PlayerID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.", "Delete Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadBasketballPlayers(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("PlayerID cannot be null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Delete Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #endregion
    }
}
