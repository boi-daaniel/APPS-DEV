﻿namespace AthleteDataSystem.AdminForms
{
    partial class FormBB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PanelCommands = new System.Windows.Forms.Panel();
            this.txtSearch = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtFieldGoalAttempted = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtFieldGoalMades = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtAssistPerGame = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtPointsPerGame = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtAverageMinutes = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtGamesPlayed = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtTeam = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtName = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.newBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelTeam = new System.Windows.Forms.Label();
            this.saveBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.updateBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelName = new System.Windows.Forms.Label();
            this.deleteBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelAverageMinutes = new System.Windows.Forms.Label();
            this.labelAssistPerGame = new System.Windows.Forms.Label();
            this.labelPointsPerGame = new System.Windows.Forms.Label();
            this.labelFieldGoalsMade = new System.Windows.Forms.Label();
            this.labelFieldGoalsAttempted = new System.Windows.Forms.Label();
            this.labelGamesPlayed = new System.Windows.Forms.Label();
            this.panelTable = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.PanelCommands.SuspendLayout();
            this.panelTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelCommands
            // 
            this.PanelCommands.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.PanelCommands.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PanelCommands.Controls.Add(this.txtSearch);
            this.PanelCommands.Controls.Add(this.txtFieldGoalAttempted);
            this.PanelCommands.Controls.Add(this.txtFieldGoalMades);
            this.PanelCommands.Controls.Add(this.txtAssistPerGame);
            this.PanelCommands.Controls.Add(this.txtPointsPerGame);
            this.PanelCommands.Controls.Add(this.txtAverageMinutes);
            this.PanelCommands.Controls.Add(this.txtGamesPlayed);
            this.PanelCommands.Controls.Add(this.txtTeam);
            this.PanelCommands.Controls.Add(this.txtName);
            this.PanelCommands.Controls.Add(this.newBtn);
            this.PanelCommands.Controls.Add(this.labelTeam);
            this.PanelCommands.Controls.Add(this.saveBtn);
            this.PanelCommands.Controls.Add(this.updateBtn);
            this.PanelCommands.Controls.Add(this.labelName);
            this.PanelCommands.Controls.Add(this.deleteBtn);
            this.PanelCommands.Controls.Add(this.labelAverageMinutes);
            this.PanelCommands.Controls.Add(this.labelAssistPerGame);
            this.PanelCommands.Controls.Add(this.labelPointsPerGame);
            this.PanelCommands.Controls.Add(this.labelFieldGoalsMade);
            this.PanelCommands.Controls.Add(this.labelFieldGoalsAttempted);
            this.PanelCommands.Controls.Add(this.labelGamesPlayed);
            this.PanelCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelCommands.Location = new System.Drawing.Point(0, 0);
            this.PanelCommands.Name = "PanelCommands";
            this.PanelCommands.Size = new System.Drawing.Size(800, 150);
            this.PanelCommands.TabIndex = 55;
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearch.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtSearch.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtSearch.BorderRadius = 15;
            this.txtSearch.BorderSize = 2;
            this.txtSearch.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearch.Location = new System.Drawing.Point(679, 99);
            this.txtSearch.Multiline = false;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtSearch.PasswordChar = false;
            this.txtSearch.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtSearch.PlaceholderText = "Search";
            this.txtSearch.Size = new System.Drawing.Size(110, 28);
            this.txtSearch.TabIndex = 62;
            this.txtSearch.Texts = "";
            this.txtSearch.UnderlinedStyle = false;
            // 
            // txtFieldGoalAttempted
            // 
            this.txtFieldGoalAttempted.BackColor = System.Drawing.SystemColors.Window;
            this.txtFieldGoalAttempted.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtFieldGoalAttempted.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtFieldGoalAttempted.BorderRadius = 0;
            this.txtFieldGoalAttempted.BorderSize = 2;
            this.txtFieldGoalAttempted.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFieldGoalAttempted.ForeColor = System.Drawing.Color.DimGray;
            this.txtFieldGoalAttempted.Location = new System.Drawing.Point(707, 56);
            this.txtFieldGoalAttempted.Multiline = false;
            this.txtFieldGoalAttempted.Name = "txtFieldGoalAttempted";
            this.txtFieldGoalAttempted.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtFieldGoalAttempted.PasswordChar = false;
            this.txtFieldGoalAttempted.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtFieldGoalAttempted.PlaceholderText = "";
            this.txtFieldGoalAttempted.Size = new System.Drawing.Size(70, 29);
            this.txtFieldGoalAttempted.TabIndex = 61;
            this.txtFieldGoalAttempted.Texts = "";
            this.txtFieldGoalAttempted.UnderlinedStyle = false;
            // 
            // txtFieldGoalMades
            // 
            this.txtFieldGoalMades.BackColor = System.Drawing.SystemColors.Window;
            this.txtFieldGoalMades.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtFieldGoalMades.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtFieldGoalMades.BorderRadius = 0;
            this.txtFieldGoalMades.BorderSize = 2;
            this.txtFieldGoalMades.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFieldGoalMades.ForeColor = System.Drawing.Color.DimGray;
            this.txtFieldGoalMades.Location = new System.Drawing.Point(707, 17);
            this.txtFieldGoalMades.Multiline = false;
            this.txtFieldGoalMades.Name = "txtFieldGoalMades";
            this.txtFieldGoalMades.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtFieldGoalMades.PasswordChar = false;
            this.txtFieldGoalMades.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtFieldGoalMades.PlaceholderText = "";
            this.txtFieldGoalMades.Size = new System.Drawing.Size(70, 29);
            this.txtFieldGoalMades.TabIndex = 60;
            this.txtFieldGoalMades.Texts = "";
            this.txtFieldGoalMades.UnderlinedStyle = false;
            // 
            // txtAssistPerGame
            // 
            this.txtAssistPerGame.BackColor = System.Drawing.SystemColors.Window;
            this.txtAssistPerGame.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtAssistPerGame.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAssistPerGame.BorderRadius = 0;
            this.txtAssistPerGame.BorderSize = 2;
            this.txtAssistPerGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssistPerGame.ForeColor = System.Drawing.Color.DimGray;
            this.txtAssistPerGame.Location = new System.Drawing.Point(476, 56);
            this.txtAssistPerGame.Multiline = false;
            this.txtAssistPerGame.Name = "txtAssistPerGame";
            this.txtAssistPerGame.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtAssistPerGame.PasswordChar = false;
            this.txtAssistPerGame.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAssistPerGame.PlaceholderText = "";
            this.txtAssistPerGame.Size = new System.Drawing.Size(70, 29);
            this.txtAssistPerGame.TabIndex = 59;
            this.txtAssistPerGame.Texts = "";
            this.txtAssistPerGame.UnderlinedStyle = false;
            // 
            // txtPointsPerGame
            // 
            this.txtPointsPerGame.BackColor = System.Drawing.SystemColors.Window;
            this.txtPointsPerGame.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPointsPerGame.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPointsPerGame.BorderRadius = 0;
            this.txtPointsPerGame.BorderSize = 2;
            this.txtPointsPerGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPointsPerGame.ForeColor = System.Drawing.Color.DimGray;
            this.txtPointsPerGame.Location = new System.Drawing.Point(476, 17);
            this.txtPointsPerGame.Multiline = false;
            this.txtPointsPerGame.Name = "txtPointsPerGame";
            this.txtPointsPerGame.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtPointsPerGame.PasswordChar = false;
            this.txtPointsPerGame.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPointsPerGame.PlaceholderText = "";
            this.txtPointsPerGame.Size = new System.Drawing.Size(70, 29);
            this.txtPointsPerGame.TabIndex = 58;
            this.txtPointsPerGame.Texts = "";
            this.txtPointsPerGame.UnderlinedStyle = false;
            // 
            // txtAverageMinutes
            // 
            this.txtAverageMinutes.BackColor = System.Drawing.SystemColors.Window;
            this.txtAverageMinutes.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtAverageMinutes.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAverageMinutes.BorderRadius = 0;
            this.txtAverageMinutes.BorderSize = 2;
            this.txtAverageMinutes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAverageMinutes.ForeColor = System.Drawing.Color.DimGray;
            this.txtAverageMinutes.Location = new System.Drawing.Point(318, 56);
            this.txtAverageMinutes.Multiline = false;
            this.txtAverageMinutes.Name = "txtAverageMinutes";
            this.txtAverageMinutes.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtAverageMinutes.PasswordChar = false;
            this.txtAverageMinutes.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAverageMinutes.PlaceholderText = "";
            this.txtAverageMinutes.Size = new System.Drawing.Size(70, 29);
            this.txtAverageMinutes.TabIndex = 57;
            this.txtAverageMinutes.Texts = "";
            this.txtAverageMinutes.UnderlinedStyle = false;
            // 
            // txtGamesPlayed
            // 
            this.txtGamesPlayed.BackColor = System.Drawing.SystemColors.Window;
            this.txtGamesPlayed.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtGamesPlayed.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtGamesPlayed.BorderRadius = 0;
            this.txtGamesPlayed.BorderSize = 2;
            this.txtGamesPlayed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGamesPlayed.ForeColor = System.Drawing.Color.DimGray;
            this.txtGamesPlayed.Location = new System.Drawing.Point(318, 17);
            this.txtGamesPlayed.Multiline = false;
            this.txtGamesPlayed.Name = "txtGamesPlayed";
            this.txtGamesPlayed.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtGamesPlayed.PasswordChar = false;
            this.txtGamesPlayed.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtGamesPlayed.PlaceholderText = "";
            this.txtGamesPlayed.Size = new System.Drawing.Size(70, 29);
            this.txtGamesPlayed.TabIndex = 56;
            this.txtGamesPlayed.Texts = "";
            this.txtGamesPlayed.UnderlinedStyle = false;
            // 
            // txtTeam
            // 
            this.txtTeam.BackColor = System.Drawing.SystemColors.Window;
            this.txtTeam.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtTeam.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTeam.BorderRadius = 0;
            this.txtTeam.BorderSize = 2;
            this.txtTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTeam.ForeColor = System.Drawing.Color.DimGray;
            this.txtTeam.Location = new System.Drawing.Point(90, 56);
            this.txtTeam.Multiline = false;
            this.txtTeam.Name = "txtTeam";
            this.txtTeam.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtTeam.PasswordChar = false;
            this.txtTeam.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtTeam.PlaceholderText = "";
            this.txtTeam.Size = new System.Drawing.Size(70, 29);
            this.txtTeam.TabIndex = 55;
            this.txtTeam.Texts = "";
            this.txtTeam.UnderlinedStyle = false;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtName.BorderRadius = 0;
            this.txtName.BorderSize = 2;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.ForeColor = System.Drawing.Color.DimGray;
            this.txtName.Location = new System.Drawing.Point(90, 17);
            this.txtName.Multiline = false;
            this.txtName.Name = "txtName";
            this.txtName.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtName.PasswordChar = false;
            this.txtName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtName.PlaceholderText = "";
            this.txtName.Size = new System.Drawing.Size(70, 29);
            this.txtName.TabIndex = 54;
            this.txtName.Texts = "";
            this.txtName.UnderlinedStyle = false;
            // 
            // newBtn
            // 
            this.newBtn.BackColor = System.Drawing.Color.White;
            this.newBtn.BackgroundColor = System.Drawing.Color.White;
            this.newBtn.BorderColor = System.Drawing.Color.Black;
            this.newBtn.BorderRadius = 15;
            this.newBtn.BorderSize = 2;
            this.newBtn.FlatAppearance.BorderSize = 0;
            this.newBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBtn.ForeColor = System.Drawing.Color.Black;
            this.newBtn.Location = new System.Drawing.Point(243, 99);
            this.newBtn.Margin = new System.Windows.Forms.Padding(2);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(75, 32);
            this.newBtn.TabIndex = 49;
            this.newBtn.Text = "NEW";
            this.newBtn.TextColor = System.Drawing.Color.Black;
            this.newBtn.UseVisualStyleBackColor = false;
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // labelTeam
            // 
            this.labelTeam.AutoSize = true;
            this.labelTeam.BackColor = System.Drawing.Color.Transparent;
            this.labelTeam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelTeam.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTeam.ForeColor = System.Drawing.Color.White;
            this.labelTeam.Location = new System.Drawing.Point(30, 56);
            this.labelTeam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTeam.Name = "labelTeam";
            this.labelTeam.Size = new System.Drawing.Size(52, 20);
            this.labelTeam.TabIndex = 32;
            this.labelTeam.Text = "Team:";
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.White;
            this.saveBtn.BackgroundColor = System.Drawing.Color.White;
            this.saveBtn.BorderColor = System.Drawing.Color.Black;
            this.saveBtn.BorderRadius = 15;
            this.saveBtn.BorderSize = 2;
            this.saveBtn.FlatAppearance.BorderSize = 0;
            this.saveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.ForeColor = System.Drawing.Color.Black;
            this.saveBtn.Location = new System.Drawing.Point(322, 99);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(2);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(75, 32);
            this.saveBtn.TabIndex = 50;
            this.saveBtn.Text = "SAVE";
            this.saveBtn.TextColor = System.Drawing.Color.Black;
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.White;
            this.updateBtn.BackgroundColor = System.Drawing.Color.White;
            this.updateBtn.BorderColor = System.Drawing.Color.Black;
            this.updateBtn.BorderRadius = 15;
            this.updateBtn.BorderSize = 2;
            this.updateBtn.FlatAppearance.BorderSize = 0;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.ForeColor = System.Drawing.Color.Black;
            this.updateBtn.Location = new System.Drawing.Point(401, 99);
            this.updateBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(75, 32);
            this.updateBtn.TabIndex = 52;
            this.updateBtn.Text = "UPDATE";
            this.updateBtn.TextColor = System.Drawing.Color.Black;
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelName.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.White;
            this.labelName.Location = new System.Drawing.Point(30, 17);
            this.labelName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(55, 20);
            this.labelName.TabIndex = 51;
            this.labelName.Text = "Name:";
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.White;
            this.deleteBtn.BackgroundColor = System.Drawing.Color.White;
            this.deleteBtn.BorderColor = System.Drawing.Color.Black;
            this.deleteBtn.BorderRadius = 15;
            this.deleteBtn.BorderSize = 2;
            this.deleteBtn.FlatAppearance.BorderSize = 0;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.Black;
            this.deleteBtn.Location = new System.Drawing.Point(480, 99);
            this.deleteBtn.Margin = new System.Windows.Forms.Padding(2);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 32);
            this.deleteBtn.TabIndex = 53;
            this.deleteBtn.Text = "DELETE";
            this.deleteBtn.TextColor = System.Drawing.Color.Black;
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // labelAverageMinutes
            // 
            this.labelAverageMinutes.AutoSize = true;
            this.labelAverageMinutes.BackColor = System.Drawing.Color.Transparent;
            this.labelAverageMinutes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAverageMinutes.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAverageMinutes.ForeColor = System.Drawing.Color.White;
            this.labelAverageMinutes.Location = new System.Drawing.Point(180, 56);
            this.labelAverageMinutes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAverageMinutes.Name = "labelAverageMinutes";
            this.labelAverageMinutes.Size = new System.Drawing.Size(133, 20);
            this.labelAverageMinutes.TabIndex = 36;
            this.labelAverageMinutes.Text = "Average Minutes:";
            // 
            // labelAssistPerGame
            // 
            this.labelAssistPerGame.AutoSize = true;
            this.labelAssistPerGame.BackColor = System.Drawing.Color.Transparent;
            this.labelAssistPerGame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAssistPerGame.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelAssistPerGame.ForeColor = System.Drawing.Color.White;
            this.labelAssistPerGame.Location = new System.Drawing.Point(415, 56);
            this.labelAssistPerGame.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAssistPerGame.Name = "labelAssistPerGame";
            this.labelAssistPerGame.Size = new System.Drawing.Size(56, 20);
            this.labelAssistPerGame.TabIndex = 40;
            this.labelAssistPerGame.Text = "Assist:";
            // 
            // labelPointsPerGame
            // 
            this.labelPointsPerGame.AutoSize = true;
            this.labelPointsPerGame.BackColor = System.Drawing.Color.Transparent;
            this.labelPointsPerGame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPointsPerGame.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPointsPerGame.ForeColor = System.Drawing.Color.White;
            this.labelPointsPerGame.Location = new System.Drawing.Point(412, 17);
            this.labelPointsPerGame.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPointsPerGame.Name = "labelPointsPerGame";
            this.labelPointsPerGame.Size = new System.Drawing.Size(59, 20);
            this.labelPointsPerGame.TabIndex = 38;
            this.labelPointsPerGame.Text = "Points:";
            // 
            // labelFieldGoalsMade
            // 
            this.labelFieldGoalsMade.AutoSize = true;
            this.labelFieldGoalsMade.BackColor = System.Drawing.Color.Transparent;
            this.labelFieldGoalsMade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelFieldGoalsMade.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelFieldGoalsMade.ForeColor = System.Drawing.Color.White;
            this.labelFieldGoalsMade.Location = new System.Drawing.Point(574, 17);
            this.labelFieldGoalsMade.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFieldGoalsMade.Name = "labelFieldGoalsMade";
            this.labelFieldGoalsMade.Size = new System.Drawing.Size(128, 20);
            this.labelFieldGoalsMade.TabIndex = 42;
            this.labelFieldGoalsMade.Text = "Field Goal Made:";
            // 
            // labelFieldGoalsAttempted
            // 
            this.labelFieldGoalsAttempted.AutoSize = true;
            this.labelFieldGoalsAttempted.BackColor = System.Drawing.Color.Transparent;
            this.labelFieldGoalsAttempted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelFieldGoalsAttempted.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelFieldGoalsAttempted.ForeColor = System.Drawing.Color.White;
            this.labelFieldGoalsAttempted.Location = new System.Drawing.Point(553, 56);
            this.labelFieldGoalsAttempted.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFieldGoalsAttempted.Name = "labelFieldGoalsAttempted";
            this.labelFieldGoalsAttempted.Size = new System.Drawing.Size(149, 20);
            this.labelFieldGoalsAttempted.TabIndex = 43;
            this.labelFieldGoalsAttempted.Text = "Field Goal Attempt:";
            // 
            // labelGamesPlayed
            // 
            this.labelGamesPlayed.AutoSize = true;
            this.labelGamesPlayed.BackColor = System.Drawing.Color.Transparent;
            this.labelGamesPlayed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelGamesPlayed.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGamesPlayed.ForeColor = System.Drawing.Color.White;
            this.labelGamesPlayed.Location = new System.Drawing.Point(200, 17);
            this.labelGamesPlayed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelGamesPlayed.Name = "labelGamesPlayed";
            this.labelGamesPlayed.Size = new System.Drawing.Size(113, 20);
            this.labelGamesPlayed.TabIndex = 35;
            this.labelGamesPlayed.Text = "Games Played:";
            // 
            // panelTable
            // 
            this.panelTable.Controls.Add(this.dataGridView1);
            this.panelTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTable.ForeColor = System.Drawing.Color.Black;
            this.panelTable.Location = new System.Drawing.Point(0, 150);
            this.panelTable.Name = "panelTable";
            this.panelTable.Size = new System.Drawing.Size(800, 300);
            this.panelTable.TabIndex = 56;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(800, 300);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // FormBB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelTable);
            this.Controls.Add(this.PanelCommands);
            this.Name = "FormBB";
            this.Text = "FormBB";
            this.PanelCommands.ResumeLayout(false);
            this.PanelCommands.PerformLayout();
            this.panelTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelCommands;
        private CustomControls.CurveTextbox txtFieldGoalAttempted;
        private CustomControls.CurveTextbox txtFieldGoalMades;
        private CustomControls.CurveTextbox txtAssistPerGame;
        private CustomControls.CurveTextbox txtPointsPerGame;
        private CustomControls.CurveTextbox txtAverageMinutes;
        private CustomControls.CurveTextbox txtGamesPlayed;
        private CustomControls.CurveTextbox txtTeam;
        private CustomControls.CurveTextbox txtName;
        private CustomTools.CurvedButton newBtn;
        private CustomTools.CurvedButton saveBtn;
        private CustomTools.CurvedButton updateBtn;
        private CustomTools.CurvedButton deleteBtn;
        private System.Windows.Forms.Panel panelTable;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelTeam;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelAverageMinutes;
        private System.Windows.Forms.Label labelAssistPerGame;
        private System.Windows.Forms.Label labelPointsPerGame;
        private System.Windows.Forms.Label labelFieldGoalsMade;
        private System.Windows.Forms.Label labelFieldGoalsAttempted;
        private System.Windows.Forms.Label labelGamesPlayed;
        private CustomControls.CurveTextbox txtSearch;
    }
}