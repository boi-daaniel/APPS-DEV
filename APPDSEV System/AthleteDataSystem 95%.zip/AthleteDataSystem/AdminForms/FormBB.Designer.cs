﻿namespace AthleteDataSystem.AdminForms
{
    partial class FormBB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PanelCommands = new System.Windows.Forms.Panel();
            this.labelFGM = new System.Windows.Forms.Label();
            this.labelFGA = new System.Windows.Forms.Label();
            this.labelBlocks = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.labelTeam = new System.Windows.Forms.Label();
            this.labelName = new System.Windows.Forms.Label();
            this.labelAssist = new System.Windows.Forms.Label();
            this.labelPoints = new System.Windows.Forms.Label();
            this.labelRebounds = new System.Windows.Forms.Label();
            this.labelSteal = new System.Windows.Forms.Label();
            this.labelGamesPlayed = new System.Windows.Forms.Label();
            this.labelFTA = new System.Windows.Forms.Label();
            this.labelFTM = new System.Windows.Forms.Label();
            this.labelTurnovers = new System.Windows.Forms.Label();
            this.panelTable = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtTurnovers = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtFTM = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtFTA = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtFGM = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtFGA = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtBlocks = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtSearch = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtSteals = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtRebounds = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtAssist = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtPoints = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtGamesPlayed = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtTeam = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtName = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.newBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.saveBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.updateBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.deleteBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.tabControlBBAdmin = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.txtAge = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelAge = new System.Windows.Forms.Label();
            this.labelPlayerTeam = new System.Windows.Forms.Label();
            this.labelBirthdate = new System.Windows.Forms.Label();
            this.labelPlayerName = new System.Windows.Forms.Label();
            this.btnBrowse = new AthleteDataSystem.CustomTools.CurvedButton();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtSearchPlayer = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtPlayerTeam = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtBirthdate = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.txtPlayerName = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.curvedButton1 = new AthleteDataSystem.CustomTools.CurvedButton();
            this.curvedButton2 = new AthleteDataSystem.CustomTools.CurvedButton();
            this.curvedButton3 = new AthleteDataSystem.CustomTools.CurvedButton();
            this.curvedButton4 = new AthleteDataSystem.CustomTools.CurvedButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSearchPlayer = new System.Windows.Forms.Button();
            this.txtPosition = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelPosition = new System.Windows.Forms.Label();
            this.txtJerseyNumber = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelJerseyNumber = new System.Windows.Forms.Label();
            this.txtHeight = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelHeight = new System.Windows.Forms.Label();
            this.txtWeight = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.labelWeight = new System.Windows.Forms.Label();
            this.PanelCommands.SuspendLayout();
            this.panelTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControlBBAdmin.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // PanelCommands
            // 
            this.PanelCommands.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.PanelCommands.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PanelCommands.Controls.Add(this.txtTurnovers);
            this.PanelCommands.Controls.Add(this.txtFTM);
            this.PanelCommands.Controls.Add(this.txtFTA);
            this.PanelCommands.Controls.Add(this.txtFGM);
            this.PanelCommands.Controls.Add(this.txtFGA);
            this.PanelCommands.Controls.Add(this.txtBlocks);
            this.PanelCommands.Controls.Add(this.labelFGM);
            this.PanelCommands.Controls.Add(this.labelFGA);
            this.PanelCommands.Controls.Add(this.labelBlocks);
            this.PanelCommands.Controls.Add(this.btnSearch);
            this.PanelCommands.Controls.Add(this.txtSearch);
            this.PanelCommands.Controls.Add(this.txtSteals);
            this.PanelCommands.Controls.Add(this.txtRebounds);
            this.PanelCommands.Controls.Add(this.txtAssist);
            this.PanelCommands.Controls.Add(this.txtPoints);
            this.PanelCommands.Controls.Add(this.txtGamesPlayed);
            this.PanelCommands.Controls.Add(this.txtTeam);
            this.PanelCommands.Controls.Add(this.txtName);
            this.PanelCommands.Controls.Add(this.newBtn);
            this.PanelCommands.Controls.Add(this.labelTeam);
            this.PanelCommands.Controls.Add(this.saveBtn);
            this.PanelCommands.Controls.Add(this.updateBtn);
            this.PanelCommands.Controls.Add(this.labelName);
            this.PanelCommands.Controls.Add(this.deleteBtn);
            this.PanelCommands.Controls.Add(this.labelAssist);
            this.PanelCommands.Controls.Add(this.labelPoints);
            this.PanelCommands.Controls.Add(this.labelRebounds);
            this.PanelCommands.Controls.Add(this.labelSteal);
            this.PanelCommands.Controls.Add(this.labelGamesPlayed);
            this.PanelCommands.Controls.Add(this.labelFTA);
            this.PanelCommands.Controls.Add(this.labelFTM);
            this.PanelCommands.Controls.Add(this.labelTurnovers);
            this.PanelCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelCommands.Location = new System.Drawing.Point(3, 3);
            this.PanelCommands.Name = "PanelCommands";
            this.PanelCommands.Size = new System.Drawing.Size(786, 170);
            this.PanelCommands.TabIndex = 55;
            // 
            // labelFGM
            // 
            this.labelFGM.AutoSize = true;
            this.labelFGM.BackColor = System.Drawing.Color.Transparent;
            this.labelFGM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelFGM.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelFGM.ForeColor = System.Drawing.Color.White;
            this.labelFGM.Location = new System.Drawing.Point(255, 51);
            this.labelFGM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFGM.Name = "labelFGM";
            this.labelFGM.Size = new System.Drawing.Size(46, 20);
            this.labelFGM.TabIndex = 66;
            this.labelFGM.Text = "FGM:";
            // 
            // labelFGA
            // 
            this.labelFGA.AutoSize = true;
            this.labelFGA.BackColor = System.Drawing.Color.Transparent;
            this.labelFGA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelFGA.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelFGA.ForeColor = System.Drawing.Color.White;
            this.labelFGA.Location = new System.Drawing.Point(143, 51);
            this.labelFGA.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFGA.Name = "labelFGA";
            this.labelFGA.Size = new System.Drawing.Size(43, 20);
            this.labelFGA.TabIndex = 65;
            this.labelFGA.Text = "FGA:";
            // 
            // labelBlocks
            // 
            this.labelBlocks.AutoSize = true;
            this.labelBlocks.BackColor = System.Drawing.Color.Transparent;
            this.labelBlocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBlocks.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelBlocks.ForeColor = System.Drawing.Color.White;
            this.labelBlocks.Location = new System.Drawing.Point(41, 51);
            this.labelBlocks.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBlocks.Name = "labelBlocks";
            this.labelBlocks.Size = new System.Drawing.Size(61, 20);
            this.labelBlocks.TabIndex = 64;
            this.labelBlocks.Text = "Blocks:";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Location = new System.Drawing.Point(692, 103);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 63;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Visible = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // labelTeam
            // 
            this.labelTeam.AutoSize = true;
            this.labelTeam.BackColor = System.Drawing.Color.Transparent;
            this.labelTeam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelTeam.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTeam.ForeColor = System.Drawing.Color.White;
            this.labelTeam.Location = new System.Drawing.Point(143, -1);
            this.labelTeam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTeam.Name = "labelTeam";
            this.labelTeam.Size = new System.Drawing.Size(52, 20);
            this.labelTeam.TabIndex = 32;
            this.labelTeam.Text = "Team:";
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelName.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.White;
            this.labelName.Location = new System.Drawing.Point(41, -1);
            this.labelName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(55, 20);
            this.labelName.TabIndex = 51;
            this.labelName.Text = "Name:";
            // 
            // labelAssist
            // 
            this.labelAssist.AutoSize = true;
            this.labelAssist.BackColor = System.Drawing.Color.Transparent;
            this.labelAssist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAssist.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelAssist.ForeColor = System.Drawing.Color.White;
            this.labelAssist.Location = new System.Drawing.Point(593, -1);
            this.labelAssist.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAssist.Name = "labelAssist";
            this.labelAssist.Size = new System.Drawing.Size(56, 20);
            this.labelAssist.TabIndex = 40;
            this.labelAssist.Text = "Assist:";
            // 
            // labelPoints
            // 
            this.labelPoints.AutoSize = true;
            this.labelPoints.BackColor = System.Drawing.Color.Transparent;
            this.labelPoints.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPoints.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPoints.ForeColor = System.Drawing.Color.White;
            this.labelPoints.Location = new System.Drawing.Point(373, -1);
            this.labelPoints.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPoints.Name = "labelPoints";
            this.labelPoints.Size = new System.Drawing.Size(59, 20);
            this.labelPoints.TabIndex = 38;
            this.labelPoints.Text = "Points:";
            // 
            // labelRebounds
            // 
            this.labelRebounds.AutoSize = true;
            this.labelRebounds.BackColor = System.Drawing.Color.Transparent;
            this.labelRebounds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelRebounds.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelRebounds.ForeColor = System.Drawing.Color.White;
            this.labelRebounds.Location = new System.Drawing.Point(476, -1);
            this.labelRebounds.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelRebounds.Name = "labelRebounds";
            this.labelRebounds.Size = new System.Drawing.Size(84, 20);
            this.labelRebounds.TabIndex = 42;
            this.labelRebounds.Text = "Rebounds:";
            // 
            // labelSteal
            // 
            this.labelSteal.AutoSize = true;
            this.labelSteal.BackColor = System.Drawing.Color.Transparent;
            this.labelSteal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelSteal.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelSteal.ForeColor = System.Drawing.Color.White;
            this.labelSteal.Location = new System.Drawing.Point(708, 0);
            this.labelSteal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSteal.Name = "labelSteal";
            this.labelSteal.Size = new System.Drawing.Size(55, 20);
            this.labelSteal.TabIndex = 43;
            this.labelSteal.Text = "Steals:";
            // 
            // labelGamesPlayed
            // 
            this.labelGamesPlayed.AutoSize = true;
            this.labelGamesPlayed.BackColor = System.Drawing.Color.Transparent;
            this.labelGamesPlayed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelGamesPlayed.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGamesPlayed.ForeColor = System.Drawing.Color.White;
            this.labelGamesPlayed.Location = new System.Drawing.Point(222, -1);
            this.labelGamesPlayed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelGamesPlayed.Name = "labelGamesPlayed";
            this.labelGamesPlayed.Size = new System.Drawing.Size(113, 20);
            this.labelGamesPlayed.TabIndex = 35;
            this.labelGamesPlayed.Text = "Games Played:";
            // 
            // labelFTA
            // 
            this.labelFTA.AutoSize = true;
            this.labelFTA.BackColor = System.Drawing.Color.Transparent;
            this.labelFTA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelFTA.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelFTA.ForeColor = System.Drawing.Color.White;
            this.labelFTA.Location = new System.Drawing.Point(373, 51);
            this.labelFTA.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFTA.Name = "labelFTA";
            this.labelFTA.Size = new System.Drawing.Size(42, 20);
            this.labelFTA.TabIndex = 72;
            this.labelFTA.Text = "FTA:";
            // 
            // labelFTM
            // 
            this.labelFTM.AutoSize = true;
            this.labelFTM.BackColor = System.Drawing.Color.Transparent;
            this.labelFTM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelFTM.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelFTM.ForeColor = System.Drawing.Color.White;
            this.labelFTM.Location = new System.Drawing.Point(496, 51);
            this.labelFTM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelFTM.Name = "labelFTM";
            this.labelFTM.Size = new System.Drawing.Size(46, 20);
            this.labelFTM.TabIndex = 73;
            this.labelFTM.Text = "FTM:";
            // 
            // labelTurnovers
            // 
            this.labelTurnovers.AutoSize = true;
            this.labelTurnovers.BackColor = System.Drawing.Color.Transparent;
            this.labelTurnovers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelTurnovers.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelTurnovers.ForeColor = System.Drawing.Color.White;
            this.labelTurnovers.Location = new System.Drawing.Point(587, 51);
            this.labelTurnovers.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTurnovers.Name = "labelTurnovers";
            this.labelTurnovers.Size = new System.Drawing.Size(88, 20);
            this.labelTurnovers.TabIndex = 75;
            this.labelTurnovers.Text = "Turnovers:";
            // 
            // panelTable
            // 
            this.panelTable.Controls.Add(this.dataGridView1);
            this.panelTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTable.ForeColor = System.Drawing.Color.White;
            this.panelTable.Location = new System.Drawing.Point(3, 173);
            this.panelTable.Name = "panelTable";
            this.panelTable.Size = new System.Drawing.Size(786, 246);
            this.panelTable.TabIndex = 56;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.Size = new System.Drawing.Size(786, 246);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // txtTurnovers
            // 
            this.txtTurnovers.BackColor = System.Drawing.SystemColors.Window;
            this.txtTurnovers.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtTurnovers.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTurnovers.BorderRadius = 0;
            this.txtTurnovers.BorderSize = 2;
            this.txtTurnovers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTurnovers.ForeColor = System.Drawing.Color.DimGray;
            this.txtTurnovers.Location = new System.Drawing.Point(591, 69);
            this.txtTurnovers.Multiline = false;
            this.txtTurnovers.Name = "txtTurnovers";
            this.txtTurnovers.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtTurnovers.PasswordChar = false;
            this.txtTurnovers.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtTurnovers.PlaceholderText = "";
            this.txtTurnovers.Size = new System.Drawing.Size(70, 29);
            this.txtTurnovers.TabIndex = 74;
            this.txtTurnovers.Texts = "";
            this.txtTurnovers.UnderlinedStyle = false;
            // 
            // txtFTM
            // 
            this.txtFTM.BackColor = System.Drawing.SystemColors.Window;
            this.txtFTM.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtFTM.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtFTM.BorderRadius = 0;
            this.txtFTM.BorderSize = 2;
            this.txtFTM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFTM.ForeColor = System.Drawing.Color.DimGray;
            this.txtFTM.Location = new System.Drawing.Point(485, 69);
            this.txtFTM.Multiline = false;
            this.txtFTM.Name = "txtFTM";
            this.txtFTM.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtFTM.PasswordChar = false;
            this.txtFTM.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtFTM.PlaceholderText = "";
            this.txtFTM.Size = new System.Drawing.Size(70, 29);
            this.txtFTM.TabIndex = 71;
            this.txtFTM.Texts = "";
            this.txtFTM.UnderlinedStyle = false;
            // 
            // txtFTA
            // 
            this.txtFTA.BackColor = System.Drawing.SystemColors.Window;
            this.txtFTA.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtFTA.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtFTA.BorderRadius = 0;
            this.txtFTA.BorderSize = 2;
            this.txtFTA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFTA.ForeColor = System.Drawing.Color.DimGray;
            this.txtFTA.Location = new System.Drawing.Point(363, 69);
            this.txtFTA.Multiline = false;
            this.txtFTA.Name = "txtFTA";
            this.txtFTA.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtFTA.PasswordChar = false;
            this.txtFTA.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtFTA.PlaceholderText = "";
            this.txtFTA.Size = new System.Drawing.Size(70, 29);
            this.txtFTA.TabIndex = 70;
            this.txtFTA.Texts = "";
            this.txtFTA.UnderlinedStyle = false;
            // 
            // txtFGM
            // 
            this.txtFGM.BackColor = System.Drawing.SystemColors.Window;
            this.txtFGM.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtFGM.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtFGM.BorderRadius = 0;
            this.txtFGM.BorderSize = 2;
            this.txtFGM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFGM.ForeColor = System.Drawing.Color.DimGray;
            this.txtFGM.Location = new System.Drawing.Point(243, 69);
            this.txtFGM.Multiline = false;
            this.txtFGM.Name = "txtFGM";
            this.txtFGM.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtFGM.PasswordChar = false;
            this.txtFGM.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtFGM.PlaceholderText = "";
            this.txtFGM.Size = new System.Drawing.Size(70, 29);
            this.txtFGM.TabIndex = 69;
            this.txtFGM.Texts = "";
            this.txtFGM.UnderlinedStyle = false;
            // 
            // txtFGA
            // 
            this.txtFGA.BackColor = System.Drawing.SystemColors.Window;
            this.txtFGA.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtFGA.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtFGA.BorderRadius = 0;
            this.txtFGA.BorderSize = 2;
            this.txtFGA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFGA.ForeColor = System.Drawing.Color.DimGray;
            this.txtFGA.Location = new System.Drawing.Point(135, 69);
            this.txtFGA.Multiline = false;
            this.txtFGA.Name = "txtFGA";
            this.txtFGA.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtFGA.PasswordChar = false;
            this.txtFGA.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtFGA.PlaceholderText = "";
            this.txtFGA.Size = new System.Drawing.Size(70, 29);
            this.txtFGA.TabIndex = 68;
            this.txtFGA.Texts = "";
            this.txtFGA.UnderlinedStyle = false;
            // 
            // txtBlocks
            // 
            this.txtBlocks.BackColor = System.Drawing.SystemColors.Window;
            this.txtBlocks.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtBlocks.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtBlocks.BorderRadius = 0;
            this.txtBlocks.BorderSize = 2;
            this.txtBlocks.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBlocks.ForeColor = System.Drawing.Color.DimGray;
            this.txtBlocks.Location = new System.Drawing.Point(33, 69);
            this.txtBlocks.Multiline = false;
            this.txtBlocks.Name = "txtBlocks";
            this.txtBlocks.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtBlocks.PasswordChar = false;
            this.txtBlocks.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtBlocks.PlaceholderText = "";
            this.txtBlocks.Size = new System.Drawing.Size(70, 29);
            this.txtBlocks.TabIndex = 67;
            this.txtBlocks.Texts = "";
            this.txtBlocks.UnderlinedStyle = false;
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearch.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtSearch.BorderFocusColor = System.Drawing.SystemColors.Highlight;
            this.txtSearch.BorderRadius = 15;
            this.txtSearch.BorderSize = 2;
            this.txtSearch.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtSearch.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearch.Location = new System.Drawing.Point(0, 140);
            this.txtSearch.Multiline = false;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtSearch.PasswordChar = false;
            this.txtSearch.PlaceholderColor = System.Drawing.Color.Black;
            this.txtSearch.PlaceholderText = "Search Player";
            this.txtSearch.Size = new System.Drawing.Size(784, 28);
            this.txtSearch.TabIndex = 62;
            this.txtSearch.Texts = "";
            this.txtSearch.UnderlinedStyle = false;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // txtSteals
            // 
            this.txtSteals.BackColor = System.Drawing.SystemColors.Window;
            this.txtSteals.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtSteals.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtSteals.BorderRadius = 0;
            this.txtSteals.BorderSize = 2;
            this.txtSteals.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSteals.ForeColor = System.Drawing.Color.DimGray;
            this.txtSteals.Location = new System.Drawing.Point(697, 19);
            this.txtSteals.Multiline = false;
            this.txtSteals.Name = "txtSteals";
            this.txtSteals.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtSteals.PasswordChar = false;
            this.txtSteals.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtSteals.PlaceholderText = "";
            this.txtSteals.Size = new System.Drawing.Size(70, 29);
            this.txtSteals.TabIndex = 61;
            this.txtSteals.Texts = "";
            this.txtSteals.UnderlinedStyle = false;
            // 
            // txtRebounds
            // 
            this.txtRebounds.BackColor = System.Drawing.SystemColors.Window;
            this.txtRebounds.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtRebounds.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtRebounds.BorderRadius = 0;
            this.txtRebounds.BorderSize = 2;
            this.txtRebounds.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRebounds.ForeColor = System.Drawing.Color.DimGray;
            this.txtRebounds.Location = new System.Drawing.Point(485, 19);
            this.txtRebounds.Multiline = false;
            this.txtRebounds.Name = "txtRebounds";
            this.txtRebounds.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtRebounds.PasswordChar = false;
            this.txtRebounds.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtRebounds.PlaceholderText = "";
            this.txtRebounds.Size = new System.Drawing.Size(70, 29);
            this.txtRebounds.TabIndex = 60;
            this.txtRebounds.Texts = "";
            this.txtRebounds.UnderlinedStyle = false;
            // 
            // txtAssist
            // 
            this.txtAssist.BackColor = System.Drawing.SystemColors.Window;
            this.txtAssist.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtAssist.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAssist.BorderRadius = 0;
            this.txtAssist.BorderSize = 2;
            this.txtAssist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssist.ForeColor = System.Drawing.Color.DimGray;
            this.txtAssist.Location = new System.Drawing.Point(591, 19);
            this.txtAssist.Multiline = false;
            this.txtAssist.Name = "txtAssist";
            this.txtAssist.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtAssist.PasswordChar = false;
            this.txtAssist.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAssist.PlaceholderText = "";
            this.txtAssist.Size = new System.Drawing.Size(70, 29);
            this.txtAssist.TabIndex = 59;
            this.txtAssist.Texts = "";
            this.txtAssist.UnderlinedStyle = false;
            // 
            // txtPoints
            // 
            this.txtPoints.BackColor = System.Drawing.SystemColors.Window;
            this.txtPoints.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPoints.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPoints.BorderRadius = 0;
            this.txtPoints.BorderSize = 2;
            this.txtPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPoints.ForeColor = System.Drawing.Color.DimGray;
            this.txtPoints.Location = new System.Drawing.Point(363, 19);
            this.txtPoints.Multiline = false;
            this.txtPoints.Name = "txtPoints";
            this.txtPoints.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtPoints.PasswordChar = false;
            this.txtPoints.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPoints.PlaceholderText = "";
            this.txtPoints.Size = new System.Drawing.Size(70, 29);
            this.txtPoints.TabIndex = 58;
            this.txtPoints.Texts = "";
            this.txtPoints.UnderlinedStyle = false;
            // 
            // txtGamesPlayed
            // 
            this.txtGamesPlayed.BackColor = System.Drawing.SystemColors.Window;
            this.txtGamesPlayed.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtGamesPlayed.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtGamesPlayed.BorderRadius = 0;
            this.txtGamesPlayed.BorderSize = 2;
            this.txtGamesPlayed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGamesPlayed.ForeColor = System.Drawing.Color.DimGray;
            this.txtGamesPlayed.Location = new System.Drawing.Point(243, 19);
            this.txtGamesPlayed.Multiline = false;
            this.txtGamesPlayed.Name = "txtGamesPlayed";
            this.txtGamesPlayed.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtGamesPlayed.PasswordChar = false;
            this.txtGamesPlayed.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtGamesPlayed.PlaceholderText = "";
            this.txtGamesPlayed.Size = new System.Drawing.Size(70, 29);
            this.txtGamesPlayed.TabIndex = 56;
            this.txtGamesPlayed.Texts = "";
            this.txtGamesPlayed.UnderlinedStyle = false;
            // 
            // txtTeam
            // 
            this.txtTeam.BackColor = System.Drawing.SystemColors.Window;
            this.txtTeam.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtTeam.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTeam.BorderRadius = 0;
            this.txtTeam.BorderSize = 2;
            this.txtTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTeam.ForeColor = System.Drawing.Color.DimGray;
            this.txtTeam.Location = new System.Drawing.Point(135, 19);
            this.txtTeam.Multiline = false;
            this.txtTeam.Name = "txtTeam";
            this.txtTeam.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtTeam.PasswordChar = false;
            this.txtTeam.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtTeam.PlaceholderText = "";
            this.txtTeam.Size = new System.Drawing.Size(70, 29);
            this.txtTeam.TabIndex = 55;
            this.txtTeam.Texts = "";
            this.txtTeam.UnderlinedStyle = false;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtName.BorderRadius = 0;
            this.txtName.BorderSize = 2;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.ForeColor = System.Drawing.Color.DimGray;
            this.txtName.Location = new System.Drawing.Point(33, 19);
            this.txtName.Multiline = false;
            this.txtName.Name = "txtName";
            this.txtName.Padding = new System.Windows.Forms.Padding(10, 6, 10, 6);
            this.txtName.PasswordChar = false;
            this.txtName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtName.PlaceholderText = "";
            this.txtName.Size = new System.Drawing.Size(70, 29);
            this.txtName.TabIndex = 54;
            this.txtName.Texts = "";
            this.txtName.UnderlinedStyle = false;
            // 
            // newBtn
            // 
            this.newBtn.BackColor = System.Drawing.Color.White;
            this.newBtn.BackgroundColor = System.Drawing.Color.White;
            this.newBtn.BorderColor = System.Drawing.Color.Black;
            this.newBtn.BorderRadius = 15;
            this.newBtn.BorderSize = 2;
            this.newBtn.FlatAppearance.BorderSize = 0;
            this.newBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBtn.ForeColor = System.Drawing.Color.Black;
            this.newBtn.Location = new System.Drawing.Point(243, 103);
            this.newBtn.Margin = new System.Windows.Forms.Padding(2);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(75, 32);
            this.newBtn.TabIndex = 49;
            this.newBtn.Text = "NEW";
            this.newBtn.TextColor = System.Drawing.Color.Black;
            this.newBtn.UseVisualStyleBackColor = false;
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.White;
            this.saveBtn.BackgroundColor = System.Drawing.Color.White;
            this.saveBtn.BorderColor = System.Drawing.Color.Black;
            this.saveBtn.BorderRadius = 15;
            this.saveBtn.BorderSize = 2;
            this.saveBtn.FlatAppearance.BorderSize = 0;
            this.saveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.ForeColor = System.Drawing.Color.Black;
            this.saveBtn.Location = new System.Drawing.Point(322, 103);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(2);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(75, 32);
            this.saveBtn.TabIndex = 50;
            this.saveBtn.Text = "SAVE";
            this.saveBtn.TextColor = System.Drawing.Color.Black;
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.White;
            this.updateBtn.BackgroundColor = System.Drawing.Color.White;
            this.updateBtn.BorderColor = System.Drawing.Color.Black;
            this.updateBtn.BorderRadius = 15;
            this.updateBtn.BorderSize = 2;
            this.updateBtn.FlatAppearance.BorderSize = 0;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.ForeColor = System.Drawing.Color.Black;
            this.updateBtn.Location = new System.Drawing.Point(401, 103);
            this.updateBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(75, 32);
            this.updateBtn.TabIndex = 52;
            this.updateBtn.Text = "UPDATE";
            this.updateBtn.TextColor = System.Drawing.Color.Black;
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.White;
            this.deleteBtn.BackgroundColor = System.Drawing.Color.White;
            this.deleteBtn.BorderColor = System.Drawing.Color.Black;
            this.deleteBtn.BorderRadius = 15;
            this.deleteBtn.BorderSize = 2;
            this.deleteBtn.FlatAppearance.BorderSize = 0;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.Black;
            this.deleteBtn.Location = new System.Drawing.Point(480, 103);
            this.deleteBtn.Margin = new System.Windows.Forms.Padding(2);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 32);
            this.deleteBtn.TabIndex = 53;
            this.deleteBtn.Text = "DELETE";
            this.deleteBtn.TextColor = System.Drawing.Color.Black;
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // tabControlBBAdmin
            // 
            this.tabControlBBAdmin.Controls.Add(this.tabPage1);
            this.tabControlBBAdmin.Controls.Add(this.tabPage2);
            this.tabControlBBAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlBBAdmin.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlBBAdmin.Location = new System.Drawing.Point(0, 0);
            this.tabControlBBAdmin.Name = "tabControlBBAdmin";
            this.tabControlBBAdmin.SelectedIndex = 0;
            this.tabControlBBAdmin.Size = new System.Drawing.Size(800, 450);
            this.tabControlBBAdmin.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.tabPage1.Controls.Add(this.panelTable);
            this.tabPage1.Controls.Add(this.PanelCommands);
            this.tabPage1.ForeColor = System.Drawing.Color.White;
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 422);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Player Statistics";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.ForeColor = System.Drawing.Color.White;
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 422);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Player Information";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // txtAge
            // 
            this.txtAge.BackColor = System.Drawing.SystemColors.Window;
            this.txtAge.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtAge.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAge.BorderRadius = 0;
            this.txtAge.BorderSize = 2;
            this.txtAge.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.ForeColor = System.Drawing.Color.DimGray;
            this.txtAge.Location = new System.Drawing.Point(389, 99);
            this.txtAge.Multiline = false;
            this.txtAge.Name = "txtAge";
            this.txtAge.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtAge.PasswordChar = false;
            this.txtAge.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAge.PlaceholderText = "";
            this.txtAge.Size = new System.Drawing.Size(100, 30);
            this.txtAge.TabIndex = 70;
            this.txtAge.Texts = "";
            this.txtAge.UnderlinedStyle = false;
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.BackColor = System.Drawing.Color.Transparent;
            this.labelAge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAge.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelAge.ForeColor = System.Drawing.Color.White;
            this.labelAge.Location = new System.Drawing.Point(385, 75);
            this.labelAge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(40, 20);
            this.labelAge.TabIndex = 69;
            this.labelAge.Text = "Age:";
            // 
            // labelPlayerTeam
            // 
            this.labelPlayerTeam.AutoSize = true;
            this.labelPlayerTeam.BackColor = System.Drawing.Color.Transparent;
            this.labelPlayerTeam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPlayerTeam.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPlayerTeam.ForeColor = System.Drawing.Color.White;
            this.labelPlayerTeam.Location = new System.Drawing.Point(385, 8);
            this.labelPlayerTeam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPlayerTeam.Name = "labelPlayerTeam";
            this.labelPlayerTeam.Size = new System.Drawing.Size(52, 20);
            this.labelPlayerTeam.TabIndex = 68;
            this.labelPlayerTeam.Text = "Team:";
            // 
            // labelBirthdate
            // 
            this.labelBirthdate.AutoSize = true;
            this.labelBirthdate.BackColor = System.Drawing.Color.Transparent;
            this.labelBirthdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBirthdate.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelBirthdate.ForeColor = System.Drawing.Color.White;
            this.labelBirthdate.Location = new System.Drawing.Point(264, 75);
            this.labelBirthdate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBirthdate.Name = "labelBirthdate";
            this.labelBirthdate.Size = new System.Drawing.Size(81, 20);
            this.labelBirthdate.TabIndex = 67;
            this.labelBirthdate.Text = "Birthdate:";
            // 
            // labelPlayerName
            // 
            this.labelPlayerName.AutoSize = true;
            this.labelPlayerName.BackColor = System.Drawing.Color.Transparent;
            this.labelPlayerName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPlayerName.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPlayerName.ForeColor = System.Drawing.Color.White;
            this.labelPlayerName.Location = new System.Drawing.Point(264, 8);
            this.labelPlayerName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPlayerName.Name = "labelPlayerName";
            this.labelPlayerName.Size = new System.Drawing.Size(55, 20);
            this.labelPlayerName.TabIndex = 66;
            this.labelPlayerName.Text = "Name:";
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.White;
            this.btnBrowse.BackgroundColor = System.Drawing.Color.White;
            this.btnBrowse.BorderColor = System.Drawing.Color.Black;
            this.btnBrowse.BorderRadius = 15;
            this.btnBrowse.BorderSize = 2;
            this.btnBrowse.FlatAppearance.BorderSize = 0;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowse.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.ForeColor = System.Drawing.Color.Black;
            this.btnBrowse.Location = new System.Drawing.Point(12, 193);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(220, 30);
            this.btnBrowse.TabIndex = 61;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.TextColor = System.Drawing.Color.Black;
            this.btnBrowse.UseVisualStyleBackColor = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.White;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView2.Size = new System.Drawing.Size(786, 146);
            this.dataGridView2.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(3, 273);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(786, 146);
            this.panel1.TabIndex = 60;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(12, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(220, 184);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 60;
            this.pictureBox1.TabStop = false;
            // 
            // txtSearchPlayer
            // 
            this.txtSearchPlayer.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearchPlayer.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtSearchPlayer.BorderFocusColor = System.Drawing.SystemColors.Highlight;
            this.txtSearchPlayer.BorderRadius = 15;
            this.txtSearchPlayer.BorderSize = 2;
            this.txtSearchPlayer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtSearchPlayer.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchPlayer.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearchPlayer.Location = new System.Drawing.Point(0, 238);
            this.txtSearchPlayer.Multiline = false;
            this.txtSearchPlayer.Name = "txtSearchPlayer";
            this.txtSearchPlayer.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSearchPlayer.PasswordChar = false;
            this.txtSearchPlayer.PlaceholderColor = System.Drawing.Color.Black;
            this.txtSearchPlayer.PlaceholderText = "Search User";
            this.txtSearchPlayer.Size = new System.Drawing.Size(784, 30);
            this.txtSearchPlayer.TabIndex = 58;
            this.txtSearchPlayer.Texts = "";
            this.txtSearchPlayer.UnderlinedStyle = false;
            // 
            // txtPlayerTeam
            // 
            this.txtPlayerTeam.BackColor = System.Drawing.SystemColors.Window;
            this.txtPlayerTeam.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPlayerTeam.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPlayerTeam.BorderRadius = 0;
            this.txtPlayerTeam.BorderSize = 2;
            this.txtPlayerTeam.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlayerTeam.ForeColor = System.Drawing.Color.DimGray;
            this.txtPlayerTeam.Location = new System.Drawing.Point(389, 31);
            this.txtPlayerTeam.Multiline = false;
            this.txtPlayerTeam.Name = "txtPlayerTeam";
            this.txtPlayerTeam.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPlayerTeam.PasswordChar = false;
            this.txtPlayerTeam.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPlayerTeam.PlaceholderText = "";
            this.txtPlayerTeam.Size = new System.Drawing.Size(100, 30);
            this.txtPlayerTeam.TabIndex = 57;
            this.txtPlayerTeam.Texts = "";
            this.txtPlayerTeam.UnderlinedStyle = false;
            // 
            // txtBirthdate
            // 
            this.txtBirthdate.BackColor = System.Drawing.SystemColors.Window;
            this.txtBirthdate.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtBirthdate.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtBirthdate.BorderRadius = 0;
            this.txtBirthdate.BorderSize = 2;
            this.txtBirthdate.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBirthdate.ForeColor = System.Drawing.Color.DimGray;
            this.txtBirthdate.Location = new System.Drawing.Point(268, 99);
            this.txtBirthdate.Multiline = false;
            this.txtBirthdate.Name = "txtBirthdate";
            this.txtBirthdate.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtBirthdate.PasswordChar = false;
            this.txtBirthdate.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtBirthdate.PlaceholderText = "";
            this.txtBirthdate.Size = new System.Drawing.Size(100, 30);
            this.txtBirthdate.TabIndex = 55;
            this.txtBirthdate.Texts = "";
            this.txtBirthdate.UnderlinedStyle = false;
            // 
            // txtPlayerName
            // 
            this.txtPlayerName.BackColor = System.Drawing.SystemColors.Window;
            this.txtPlayerName.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPlayerName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPlayerName.BorderRadius = 0;
            this.txtPlayerName.BorderSize = 2;
            this.txtPlayerName.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlayerName.ForeColor = System.Drawing.Color.DimGray;
            this.txtPlayerName.Location = new System.Drawing.Point(268, 31);
            this.txtPlayerName.Multiline = false;
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPlayerName.PasswordChar = false;
            this.txtPlayerName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPlayerName.PlaceholderText = "";
            this.txtPlayerName.Size = new System.Drawing.Size(100, 30);
            this.txtPlayerName.TabIndex = 54;
            this.txtPlayerName.Texts = "";
            this.txtPlayerName.UnderlinedStyle = false;
            // 
            // curvedButton1
            // 
            this.curvedButton1.BackColor = System.Drawing.Color.White;
            this.curvedButton1.BackgroundColor = System.Drawing.Color.White;
            this.curvedButton1.BorderColor = System.Drawing.Color.Black;
            this.curvedButton1.BorderRadius = 15;
            this.curvedButton1.BorderSize = 2;
            this.curvedButton1.FlatAppearance.BorderSize = 0;
            this.curvedButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.curvedButton1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.curvedButton1.ForeColor = System.Drawing.Color.Black;
            this.curvedButton1.Location = new System.Drawing.Point(335, 164);
            this.curvedButton1.Margin = new System.Windows.Forms.Padding(2);
            this.curvedButton1.Name = "curvedButton1";
            this.curvedButton1.Size = new System.Drawing.Size(75, 32);
            this.curvedButton1.TabIndex = 49;
            this.curvedButton1.Text = "NEW";
            this.curvedButton1.TextColor = System.Drawing.Color.Black;
            this.curvedButton1.UseVisualStyleBackColor = false;
            // 
            // curvedButton2
            // 
            this.curvedButton2.BackColor = System.Drawing.Color.White;
            this.curvedButton2.BackgroundColor = System.Drawing.Color.White;
            this.curvedButton2.BorderColor = System.Drawing.Color.Black;
            this.curvedButton2.BorderRadius = 15;
            this.curvedButton2.BorderSize = 2;
            this.curvedButton2.FlatAppearance.BorderSize = 0;
            this.curvedButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.curvedButton2.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.curvedButton2.ForeColor = System.Drawing.Color.Black;
            this.curvedButton2.Location = new System.Drawing.Point(414, 164);
            this.curvedButton2.Margin = new System.Windows.Forms.Padding(2);
            this.curvedButton2.Name = "curvedButton2";
            this.curvedButton2.Size = new System.Drawing.Size(75, 32);
            this.curvedButton2.TabIndex = 50;
            this.curvedButton2.Text = "SAVE";
            this.curvedButton2.TextColor = System.Drawing.Color.Black;
            this.curvedButton2.UseVisualStyleBackColor = false;
            // 
            // curvedButton3
            // 
            this.curvedButton3.BackColor = System.Drawing.Color.White;
            this.curvedButton3.BackgroundColor = System.Drawing.Color.White;
            this.curvedButton3.BorderColor = System.Drawing.Color.Black;
            this.curvedButton3.BorderRadius = 15;
            this.curvedButton3.BorderSize = 2;
            this.curvedButton3.FlatAppearance.BorderSize = 0;
            this.curvedButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.curvedButton3.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.curvedButton3.ForeColor = System.Drawing.Color.Black;
            this.curvedButton3.Location = new System.Drawing.Point(510, 164);
            this.curvedButton3.Margin = new System.Windows.Forms.Padding(2);
            this.curvedButton3.Name = "curvedButton3";
            this.curvedButton3.Size = new System.Drawing.Size(75, 32);
            this.curvedButton3.TabIndex = 52;
            this.curvedButton3.Text = "UPDATE";
            this.curvedButton3.TextColor = System.Drawing.Color.Black;
            this.curvedButton3.UseVisualStyleBackColor = false;
            // 
            // curvedButton4
            // 
            this.curvedButton4.BackColor = System.Drawing.Color.White;
            this.curvedButton4.BackgroundColor = System.Drawing.Color.White;
            this.curvedButton4.BorderColor = System.Drawing.Color.Black;
            this.curvedButton4.BorderRadius = 15;
            this.curvedButton4.BorderSize = 2;
            this.curvedButton4.FlatAppearance.BorderSize = 0;
            this.curvedButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.curvedButton4.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.curvedButton4.ForeColor = System.Drawing.Color.Black;
            this.curvedButton4.Location = new System.Drawing.Point(587, 164);
            this.curvedButton4.Margin = new System.Windows.Forms.Padding(2);
            this.curvedButton4.Name = "curvedButton4";
            this.curvedButton4.Size = new System.Drawing.Size(75, 32);
            this.curvedButton4.TabIndex = 53;
            this.curvedButton4.Text = "DELETE";
            this.curvedButton4.TextColor = System.Drawing.Color.Black;
            this.curvedButton4.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.labelWeight);
            this.panel2.Controls.Add(this.txtWeight);
            this.panel2.Controls.Add(this.labelHeight);
            this.panel2.Controls.Add(this.txtHeight);
            this.panel2.Controls.Add(this.labelJerseyNumber);
            this.panel2.Controls.Add(this.txtJerseyNumber);
            this.panel2.Controls.Add(this.labelPosition);
            this.panel2.Controls.Add(this.txtPosition);
            this.panel2.Controls.Add(this.txtAge);
            this.panel2.Controls.Add(this.labelAge);
            this.panel2.Controls.Add(this.labelPlayerTeam);
            this.panel2.Controls.Add(this.labelBirthdate);
            this.panel2.Controls.Add(this.labelPlayerName);
            this.panel2.Controls.Add(this.btnBrowse);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.txtSearchPlayer);
            this.panel2.Controls.Add(this.txtPlayerTeam);
            this.panel2.Controls.Add(this.txtBirthdate);
            this.panel2.Controls.Add(this.txtPlayerName);
            this.panel2.Controls.Add(this.curvedButton1);
            this.panel2.Controls.Add(this.curvedButton2);
            this.panel2.Controls.Add(this.curvedButton3);
            this.panel2.Controls.Add(this.curvedButton4);
            this.panel2.Controls.Add(this.btnSearchPlayer);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(786, 270);
            this.panel2.TabIndex = 59;
            // 
            // btnSearchPlayer
            // 
            this.btnSearchPlayer.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchPlayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearchPlayer.FlatAppearance.BorderSize = 0;
            this.btnSearchPlayer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchPlayer.Location = new System.Drawing.Point(693, 169);
            this.btnSearchPlayer.Name = "btnSearchPlayer";
            this.btnSearchPlayer.Size = new System.Drawing.Size(75, 23);
            this.btnSearchPlayer.TabIndex = 59;
            this.btnSearchPlayer.UseVisualStyleBackColor = false;
            this.btnSearchPlayer.Visible = false;
            // 
            // txtPosition
            // 
            this.txtPosition.BackColor = System.Drawing.SystemColors.Window;
            this.txtPosition.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPosition.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPosition.BorderRadius = 0;
            this.txtPosition.BorderSize = 2;
            this.txtPosition.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPosition.ForeColor = System.Drawing.Color.DimGray;
            this.txtPosition.Location = new System.Drawing.Point(510, 31);
            this.txtPosition.Multiline = false;
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPosition.PasswordChar = false;
            this.txtPosition.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPosition.PlaceholderText = "";
            this.txtPosition.Size = new System.Drawing.Size(100, 30);
            this.txtPosition.TabIndex = 71;
            this.txtPosition.Texts = "";
            this.txtPosition.UnderlinedStyle = false;
            // 
            // labelPosition
            // 
            this.labelPosition.AutoSize = true;
            this.labelPosition.BackColor = System.Drawing.Color.Transparent;
            this.labelPosition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPosition.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPosition.ForeColor = System.Drawing.Color.White;
            this.labelPosition.Location = new System.Drawing.Point(506, 8);
            this.labelPosition.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPosition.Name = "labelPosition";
            this.labelPosition.Size = new System.Drawing.Size(73, 20);
            this.labelPosition.TabIndex = 72;
            this.labelPosition.Text = "Position:";
            // 
            // txtJerseyNumber
            // 
            this.txtJerseyNumber.BackColor = System.Drawing.SystemColors.Window;
            this.txtJerseyNumber.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtJerseyNumber.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtJerseyNumber.BorderRadius = 0;
            this.txtJerseyNumber.BorderSize = 2;
            this.txtJerseyNumber.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJerseyNumber.ForeColor = System.Drawing.Color.DimGray;
            this.txtJerseyNumber.Location = new System.Drawing.Point(631, 31);
            this.txtJerseyNumber.Multiline = false;
            this.txtJerseyNumber.Name = "txtJerseyNumber";
            this.txtJerseyNumber.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtJerseyNumber.PasswordChar = false;
            this.txtJerseyNumber.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtJerseyNumber.PlaceholderText = "";
            this.txtJerseyNumber.Size = new System.Drawing.Size(100, 30);
            this.txtJerseyNumber.TabIndex = 73;
            this.txtJerseyNumber.Texts = "";
            this.txtJerseyNumber.UnderlinedStyle = false;
            // 
            // labelJerseyNumber
            // 
            this.labelJerseyNumber.AutoSize = true;
            this.labelJerseyNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelJerseyNumber.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelJerseyNumber.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelJerseyNumber.ForeColor = System.Drawing.Color.White;
            this.labelJerseyNumber.Location = new System.Drawing.Point(627, 8);
            this.labelJerseyNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelJerseyNumber.Name = "labelJerseyNumber";
            this.labelJerseyNumber.Size = new System.Drawing.Size(120, 20);
            this.labelJerseyNumber.TabIndex = 74;
            this.labelJerseyNumber.Text = "Jersey Number:";
            // 
            // txtHeight
            // 
            this.txtHeight.BackColor = System.Drawing.SystemColors.Window;
            this.txtHeight.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtHeight.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtHeight.BorderRadius = 0;
            this.txtHeight.BorderSize = 2;
            this.txtHeight.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHeight.ForeColor = System.Drawing.Color.DimGray;
            this.txtHeight.Location = new System.Drawing.Point(510, 99);
            this.txtHeight.Multiline = false;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtHeight.PasswordChar = false;
            this.txtHeight.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtHeight.PlaceholderText = "";
            this.txtHeight.Size = new System.Drawing.Size(100, 30);
            this.txtHeight.TabIndex = 75;
            this.txtHeight.Texts = "";
            this.txtHeight.UnderlinedStyle = false;
            // 
            // labelHeight
            // 
            this.labelHeight.AutoSize = true;
            this.labelHeight.BackColor = System.Drawing.Color.Transparent;
            this.labelHeight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelHeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelHeight.ForeColor = System.Drawing.Color.White;
            this.labelHeight.Location = new System.Drawing.Point(506, 76);
            this.labelHeight.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelHeight.Name = "labelHeight";
            this.labelHeight.Size = new System.Drawing.Size(57, 20);
            this.labelHeight.TabIndex = 76;
            this.labelHeight.Text = "Height";
            // 
            // txtWeight
            // 
            this.txtWeight.BackColor = System.Drawing.SystemColors.Window;
            this.txtWeight.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtWeight.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtWeight.BorderRadius = 0;
            this.txtWeight.BorderSize = 2;
            this.txtWeight.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeight.ForeColor = System.Drawing.Color.DimGray;
            this.txtWeight.Location = new System.Drawing.Point(631, 99);
            this.txtWeight.Multiline = false;
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtWeight.PasswordChar = false;
            this.txtWeight.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtWeight.PlaceholderText = "";
            this.txtWeight.Size = new System.Drawing.Size(100, 30);
            this.txtWeight.TabIndex = 77;
            this.txtWeight.Texts = "";
            this.txtWeight.UnderlinedStyle = false;
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.BackColor = System.Drawing.Color.Transparent;
            this.labelWeight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelWeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelWeight.ForeColor = System.Drawing.Color.White;
            this.labelWeight.Location = new System.Drawing.Point(627, 76);
            this.labelWeight.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(60, 20);
            this.labelWeight.TabIndex = 78;
            this.labelWeight.Text = "Weight";
            // 
            // FormBB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControlBBAdmin);
            this.Name = "FormBB";
            this.Text = "FormBB";
            this.Load += new System.EventHandler(this.FormBB_Load);
            this.PanelCommands.ResumeLayout(false);
            this.PanelCommands.PerformLayout();
            this.panelTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControlBBAdmin.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelCommands;
        private CustomControls.CurveTextbox txtSteals;
        private CustomControls.CurveTextbox txtRebounds;
        private CustomControls.CurveTextbox txtAssist;
        private CustomControls.CurveTextbox txtPoints;
        private CustomControls.CurveTextbox txtGamesPlayed;
        private CustomControls.CurveTextbox txtTeam;
        private CustomControls.CurveTextbox txtName;
        private CustomTools.CurvedButton newBtn;
        private CustomTools.CurvedButton saveBtn;
        private CustomTools.CurvedButton updateBtn;
        private CustomTools.CurvedButton deleteBtn;
        private System.Windows.Forms.Panel panelTable;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelTeam;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelAssist;
        private System.Windows.Forms.Label labelPoints;
        private System.Windows.Forms.Label labelRebounds;
        private System.Windows.Forms.Label labelSteal;
        private System.Windows.Forms.Label labelGamesPlayed;
        private CustomControls.CurveTextbox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label labelFGA;
        private System.Windows.Forms.Label labelBlocks;
        private System.Windows.Forms.Label labelFGM;
        private CustomControls.CurveTextbox txtFGA;
        private CustomControls.CurveTextbox txtBlocks;
        private CustomControls.CurveTextbox txtFTM;
        private CustomControls.CurveTextbox txtFTA;
        private CustomControls.CurveTextbox txtFGM;
        private System.Windows.Forms.Label labelFTA;
        private System.Windows.Forms.Label labelFTM;
        private CustomControls.CurveTextbox txtTurnovers;
        private System.Windows.Forms.Label labelTurnovers;
        private System.Windows.Forms.TabControl tabControlBBAdmin;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Panel panel2;
        private CustomControls.CurveTextbox txtAge;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelPlayerTeam;
        private System.Windows.Forms.Label labelBirthdate;
        private System.Windows.Forms.Label labelPlayerName;
        private CustomTools.CurvedButton btnBrowse;
        private System.Windows.Forms.PictureBox pictureBox1;
        private CustomControls.CurveTextbox txtSearchPlayer;
        private CustomControls.CurveTextbox txtPlayerTeam;
        private CustomControls.CurveTextbox txtBirthdate;
        private CustomControls.CurveTextbox txtPlayerName;
        private CustomTools.CurvedButton curvedButton1;
        private CustomTools.CurvedButton curvedButton2;
        private CustomTools.CurvedButton curvedButton3;
        private CustomTools.CurvedButton curvedButton4;
        private System.Windows.Forms.Button btnSearchPlayer;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private CustomControls.CurveTextbox txtPosition;
        private System.Windows.Forms.Label labelWeight;
        private CustomControls.CurveTextbox txtWeight;
        private System.Windows.Forms.Label labelHeight;
        private CustomControls.CurveTextbox txtHeight;
        private System.Windows.Forms.Label labelJerseyNumber;
        private CustomControls.CurveTextbox txtJerseyNumber;
        private System.Windows.Forms.Label labelPosition;
    }
}