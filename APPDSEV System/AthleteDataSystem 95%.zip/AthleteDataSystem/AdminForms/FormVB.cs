﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormVB : Form
    {

        //Constructor
        public FormVB()
        {
            InitializeComponent();
            LoadVolleyballPlayers();
        }

        #region -> Methods
        //Load Table
        private void LoadVolleyballPlayers()
        {
            try
            {
                string query = "SELECT * FROM volleyballPlayers";
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        //Clear Text Fields
        private void ClearFields()
        {
            txtName.Texts = "";
            txtTeam.Texts = "";
            txtSetsPlayed.Texts = "";
            txtAverageSet.Texts = "";
            txtPointsPerGame.Texts = "";
            txtBlockPerGame.Texts = "";
            txtAce.Texts = "";
            txtDig.Texts = "";
            txtReceive.Texts = "";
        }

        //Cell Click
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtName.Texts = dataGridView1[1, e.RowIndex].Value.ToString();
                txtTeam.Texts = dataGridView1[2, e.RowIndex].Value.ToString();
                txtSetsPlayed.Texts = dataGridView1[3, e.RowIndex].Value.ToString();
                txtAverageSet.Texts = dataGridView1[4, e.RowIndex].Value.ToString();
                txtPointsPerGame.Texts = dataGridView1[5, e.RowIndex].Value.ToString();
                txtBlockPerGame.Texts = dataGridView1[6, e.RowIndex].Value.ToString();
                txtAce.Texts = dataGridView1[7, e.RowIndex].Value.ToString();
                txtDig.Texts = dataGridView1[8, e.RowIndex].Value.ToString();
                txtReceive.Texts = dataGridView1[8, e.RowIndex].Value.ToString();
            }
            catch (Exception) { }
        }

        #region -> Buttons
        //New Button
        private void newBtn_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO volleyballPlayers (PlayersName, Team, SetsPlayed, AverageSets, Points, Block, Ace, Dig, Receive) " + "VALUES (" + "'" + txtName.Texts + "', " + "'" + txtTeam.Texts + "', " + int.Parse(txtSetsPlayed.Texts) + ", " + double.Parse(txtAverageSet.Texts) + ", " + int.Parse(txtPointsPerGame.Texts) + ", " + int.Parse(txtBlockPerGame.Texts) + ", " + int.Parse(txtAce.Texts) + ", " + int.Parse(txtDig.Texts) + ", " + int.Parse(txtReceive.Texts) + ")";
                DBHelper.DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added successfully.", "Save Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadVolleyballPlayers(); // Refresh the data in the DataGridView
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update Button
        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];

                if (selectedRow["PlayerID"] != DBNull.Value)
                {
                    string sql = "UPDATE volleyballPlayers SET " + "PlayersName = '" + txtName.Texts + "', " + "Team = '" + txtTeam.Texts + "', " + "SetsPlayed = " + int.Parse(txtSetsPlayed.Texts) + ", " + "AverageSets = " + double.Parse(txtAverageSet.Texts) + ", " + "Points = " + int.Parse(txtPointsPerGame.Texts) + ", " + "Block = " + int.Parse(txtBlockPerGame.Texts) + ", " + "Ace = " + int.Parse(txtAce.Texts) + ", " + "Dig = " + int.Parse(txtDig.Texts) + ", " + "Receive = "+ int.Parse(txtReceive.Texts)  + " WHERE PlayerID = " + selectedRow["PlayerID"];
                    DBHelper.DBHelper.ModifyRecord(sql);
                    MessageBox.Show("Data has been updated successfully.", "Update Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadVolleyballPlayers(); // Refresh the data in the DataGridView
                }
                else
                {
                    MessageBox.Show("PlayerID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];

                        if (selectedRow["PlayerID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM volleyballPlayers WHERE PlayerID = " + selectedRow["PlayerID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.", "Delete Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadVolleyballPlayers(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("PlayerID cannot be null.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Delete Player", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #endregion
        //Search Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchedPlayer = txtSearch.Texts.Trim();

            try
            {
                string query = "SELECT * from volleyballPlayers where PlayersName like '" + searchedPlayer + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("Player " + searchedPlayer + " does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter full name of the player.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSearch.Texts = "";
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Keydown
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }
    }
}
