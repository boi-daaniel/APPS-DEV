﻿namespace AthleteDataSystem.Forms
{
    partial class FormVolleyball
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVolleyball));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControlVolleyball = new System.Windows.Forms.TabControl();
            this.tabPagePlayersHome = new System.Windows.Forms.TabPage();
            this.panelPlayersHome = new System.Windows.Forms.Panel();
            this.dataGridViewVBPlayersHome = new System.Windows.Forms.DataGridView();
            this.ColumnProfile = new System.Windows.Forms.DataGridViewImageColumn();
            this.panelPlayersHomeDash = new System.Windows.Forms.Panel();
            this.txtSearchHome = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.btnSearchHome = new System.Windows.Forms.Button();
            this.tabPagePlayersStats = new System.Windows.Forms.TabPage();
            this.panelPlayersStats = new System.Windows.Forms.Panel();
            this.dataGridViewVBPlayersStats = new System.Windows.Forms.DataGridView();
            this.panelPlayersStatsDash = new System.Windows.Forms.Panel();
            this.txtSearchStats = new AthleteDataSystem.CustomControls.CurveTextbox();
            this.btnSearchStats = new System.Windows.Forms.Button();
            this.tabControlVolleyball.SuspendLayout();
            this.tabPagePlayersHome.SuspendLayout();
            this.panelPlayersHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVBPlayersHome)).BeginInit();
            this.panelPlayersHomeDash.SuspendLayout();
            this.tabPagePlayersStats.SuspendLayout();
            this.panelPlayersStats.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVBPlayersStats)).BeginInit();
            this.panelPlayersStatsDash.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlVolleyball
            // 
            this.tabControlVolleyball.Controls.Add(this.tabPagePlayersHome);
            this.tabControlVolleyball.Controls.Add(this.tabPagePlayersStats);
            this.tabControlVolleyball.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlVolleyball.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControlVolleyball.Location = new System.Drawing.Point(0, 0);
            this.tabControlVolleyball.Name = "tabControlVolleyball";
            this.tabControlVolleyball.SelectedIndex = 0;
            this.tabControlVolleyball.Size = new System.Drawing.Size(800, 450);
            this.tabControlVolleyball.TabIndex = 68;
            // 
            // tabPagePlayersHome
            // 
            this.tabPagePlayersHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.tabPagePlayersHome.Controls.Add(this.panelPlayersHome);
            this.tabPagePlayersHome.Controls.Add(this.panelPlayersHomeDash);
            this.tabPagePlayersHome.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPagePlayersHome.ForeColor = System.Drawing.Color.White;
            this.tabPagePlayersHome.Location = new System.Drawing.Point(4, 24);
            this.tabPagePlayersHome.Name = "tabPagePlayersHome";
            this.tabPagePlayersHome.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePlayersHome.Size = new System.Drawing.Size(792, 422);
            this.tabPagePlayersHome.TabIndex = 0;
            this.tabPagePlayersHome.Text = "Players Home";
            // 
            // panelPlayersHome
            // 
            this.panelPlayersHome.Controls.Add(this.dataGridViewVBPlayersHome);
            this.panelPlayersHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPlayersHome.Location = new System.Drawing.Point(3, 38);
            this.panelPlayersHome.Name = "panelPlayersHome";
            this.panelPlayersHome.Size = new System.Drawing.Size(786, 381);
            this.panelPlayersHome.TabIndex = 68;
            // 
            // dataGridViewVBPlayersHome
            // 
            this.dataGridViewVBPlayersHome.AllowUserToAddRows = false;
            this.dataGridViewVBPlayersHome.AllowUserToDeleteRows = false;
            this.dataGridViewVBPlayersHome.AllowUserToResizeColumns = false;
            this.dataGridViewVBPlayersHome.AllowUserToResizeRows = false;
            this.dataGridViewVBPlayersHome.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridViewVBPlayersHome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewVBPlayersHome.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewVBPlayersHome.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewVBPlayersHome.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewVBPlayersHome.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVBPlayersHome.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnProfile});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVBPlayersHome.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewVBPlayersHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVBPlayersHome.EnableHeadersVisualStyles = false;
            this.dataGridViewVBPlayersHome.GridColor = System.Drawing.Color.White;
            this.dataGridViewVBPlayersHome.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewVBPlayersHome.Name = "dataGridViewVBPlayersHome";
            this.dataGridViewVBPlayersHome.ReadOnly = true;
            this.dataGridViewVBPlayersHome.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewVBPlayersHome.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewVBPlayersHome.RowHeadersVisible = false;
            this.dataGridViewVBPlayersHome.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewVBPlayersHome.Size = new System.Drawing.Size(786, 381);
            this.dataGridViewVBPlayersHome.TabIndex = 66;
            // 
            // ColumnProfile
            // 
            this.ColumnProfile.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.NullValue = ((object)(resources.GetObject("dataGridViewCellStyle2.NullValue")));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Transparent;
            this.ColumnProfile.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnProfile.HeaderText = "";
            this.ColumnProfile.Image = global::AthleteDataSystem.Properties.Resources.female_player_icon;
            this.ColumnProfile.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.ColumnProfile.Name = "ColumnProfile";
            this.ColumnProfile.ReadOnly = true;
            this.ColumnProfile.Width = 5;
            // 
            // panelPlayersHomeDash
            // 
            this.panelPlayersHomeDash.Controls.Add(this.txtSearchHome);
            this.panelPlayersHomeDash.Controls.Add(this.btnSearchHome);
            this.panelPlayersHomeDash.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPlayersHomeDash.Location = new System.Drawing.Point(3, 3);
            this.panelPlayersHomeDash.Name = "panelPlayersHomeDash";
            this.panelPlayersHomeDash.Size = new System.Drawing.Size(786, 35);
            this.panelPlayersHomeDash.TabIndex = 67;
            // 
            // txtSearchHome
            // 
            this.txtSearchHome.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearchHome.BorderColor = System.Drawing.Color.Blue;
            this.txtSearchHome.BorderFocusColor = System.Drawing.Color.DarkViolet;
            this.txtSearchHome.BorderRadius = 15;
            this.txtSearchHome.BorderSize = 2;
            this.txtSearchHome.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchHome.ForeColor = System.Drawing.Color.Black;
            this.txtSearchHome.Location = new System.Drawing.Point(0, 0);
            this.txtSearchHome.Multiline = false;
            this.txtSearchHome.Name = "txtSearchHome";
            this.txtSearchHome.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSearchHome.PasswordChar = false;
            this.txtSearchHome.PlaceholderColor = System.Drawing.Color.DimGray;
            this.txtSearchHome.PlaceholderText = "Search Player Name";
            this.txtSearchHome.Size = new System.Drawing.Size(786, 30);
            this.txtSearchHome.TabIndex = 1;
            this.txtSearchHome.Texts = "";
            this.txtSearchHome.UnderlinedStyle = false;
            // 
            // btnSearchHome
            // 
            this.btnSearchHome.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearchHome.FlatAppearance.BorderSize = 0;
            this.btnSearchHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchHome.Location = new System.Drawing.Point(-7, 3);
            this.btnSearchHome.Name = "btnSearchHome";
            this.btnSearchHome.Size = new System.Drawing.Size(786, 30);
            this.btnSearchHome.TabIndex = 64;
            this.btnSearchHome.UseVisualStyleBackColor = false;
            this.btnSearchHome.Visible = false;
            // 
            // tabPagePlayersStats
            // 
            this.tabPagePlayersStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.tabPagePlayersStats.Controls.Add(this.panelPlayersStats);
            this.tabPagePlayersStats.Controls.Add(this.panelPlayersStatsDash);
            this.tabPagePlayersStats.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPagePlayersStats.ForeColor = System.Drawing.Color.White;
            this.tabPagePlayersStats.Location = new System.Drawing.Point(4, 24);
            this.tabPagePlayersStats.Name = "tabPagePlayersStats";
            this.tabPagePlayersStats.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePlayersStats.Size = new System.Drawing.Size(792, 422);
            this.tabPagePlayersStats.TabIndex = 1;
            this.tabPagePlayersStats.Text = "Players Stats";
            // 
            // panelPlayersStats
            // 
            this.panelPlayersStats.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.panelPlayersStats.Controls.Add(this.dataGridViewVBPlayersStats);
            this.panelPlayersStats.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPlayersStats.Location = new System.Drawing.Point(3, 38);
            this.panelPlayersStats.Name = "panelPlayersStats";
            this.panelPlayersStats.Size = new System.Drawing.Size(786, 381);
            this.panelPlayersStats.TabIndex = 1;
            // 
            // dataGridViewVBPlayersStats
            // 
            this.dataGridViewVBPlayersStats.AllowUserToAddRows = false;
            this.dataGridViewVBPlayersStats.AllowUserToDeleteRows = false;
            this.dataGridViewVBPlayersStats.AllowUserToResizeColumns = false;
            this.dataGridViewVBPlayersStats.AllowUserToResizeRows = false;
            this.dataGridViewVBPlayersStats.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridViewVBPlayersStats.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewVBPlayersStats.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewVBPlayersStats.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewVBPlayersStats.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewVBPlayersStats.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewVBPlayersStats.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewVBPlayersStats.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewVBPlayersStats.EnableHeadersVisualStyles = false;
            this.dataGridViewVBPlayersStats.GridColor = System.Drawing.Color.White;
            this.dataGridViewVBPlayersStats.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewVBPlayersStats.Name = "dataGridViewVBPlayersStats";
            this.dataGridViewVBPlayersStats.ReadOnly = true;
            this.dataGridViewVBPlayersStats.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewVBPlayersStats.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewVBPlayersStats.RowHeadersVisible = false;
            this.dataGridViewVBPlayersStats.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewVBPlayersStats.Size = new System.Drawing.Size(786, 381);
            this.dataGridViewVBPlayersStats.TabIndex = 68;
            // 
            // panelPlayersStatsDash
            // 
            this.panelPlayersStatsDash.Controls.Add(this.txtSearchStats);
            this.panelPlayersStatsDash.Controls.Add(this.btnSearchStats);
            this.panelPlayersStatsDash.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPlayersStatsDash.Location = new System.Drawing.Point(3, 3);
            this.panelPlayersStatsDash.Name = "panelPlayersStatsDash";
            this.panelPlayersStatsDash.Size = new System.Drawing.Size(786, 35);
            this.panelPlayersStatsDash.TabIndex = 0;
            // 
            // txtSearchStats
            // 
            this.txtSearchStats.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearchStats.BorderColor = System.Drawing.Color.Blue;
            this.txtSearchStats.BorderFocusColor = System.Drawing.Color.DarkViolet;
            this.txtSearchStats.BorderRadius = 15;
            this.txtSearchStats.BorderSize = 2;
            this.txtSearchStats.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchStats.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearchStats.Location = new System.Drawing.Point(0, 0);
            this.txtSearchStats.Multiline = false;
            this.txtSearchStats.Name = "txtSearchStats";
            this.txtSearchStats.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSearchStats.PasswordChar = false;
            this.txtSearchStats.PlaceholderColor = System.Drawing.Color.DimGray;
            this.txtSearchStats.PlaceholderText = "Search Player Name";
            this.txtSearchStats.Size = new System.Drawing.Size(786, 30);
            this.txtSearchStats.TabIndex = 2;
            this.txtSearchStats.Texts = "";
            this.txtSearchStats.UnderlinedStyle = false;
            // 
            // btnSearchStats
            // 
            this.btnSearchStats.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchStats.FlatAppearance.BorderSize = 0;
            this.btnSearchStats.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchStats.Location = new System.Drawing.Point(0, 2);
            this.btnSearchStats.Name = "btnSearchStats";
            this.btnSearchStats.Size = new System.Drawing.Size(786, 30);
            this.btnSearchStats.TabIndex = 0;
            this.btnSearchStats.UseVisualStyleBackColor = false;
            this.btnSearchStats.Visible = false;
            // 
            // FormVolleyball
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControlVolleyball);
            this.Name = "FormVolleyball";
            this.Text = "Women\'s Volleyball";
            this.Load += new System.EventHandler(this.FormVolleyball_Load);
            this.tabControlVolleyball.ResumeLayout(false);
            this.tabPagePlayersHome.ResumeLayout(false);
            this.panelPlayersHome.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVBPlayersHome)).EndInit();
            this.panelPlayersHomeDash.ResumeLayout(false);
            this.tabPagePlayersStats.ResumeLayout(false);
            this.panelPlayersStats.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVBPlayersStats)).EndInit();
            this.panelPlayersStatsDash.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlVolleyball;
        private System.Windows.Forms.TabPage tabPagePlayersHome;
        private System.Windows.Forms.Panel panelPlayersHome;
        private System.Windows.Forms.DataGridView dataGridViewVBPlayersHome;
        private System.Windows.Forms.Panel panelPlayersHomeDash;
        private CustomControls.CurveTextbox txtSearchHome;
        private System.Windows.Forms.Button btnSearchHome;
        private System.Windows.Forms.TabPage tabPagePlayersStats;
        private System.Windows.Forms.Panel panelPlayersStats;
        private System.Windows.Forms.DataGridView dataGridViewVBPlayersStats;
        private System.Windows.Forms.Panel panelPlayersStatsDash;
        private CustomControls.CurveTextbox txtSearchStats;
        private System.Windows.Forms.Button btnSearchStats;
        private System.Windows.Forms.DataGridViewImageColumn ColumnProfile;
    }
}