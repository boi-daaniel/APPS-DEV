﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormVolleyball : Form
    {
        public FormVolleyball()
        {
            InitializeComponent();
            LoadVolleyballPlayersHome();
            LoadVolleyballPlayersStats();
        }
        private void FormVolleyball_Load(object sender, EventArgs e)
        {
            dataGridViewVBPlayersHome.Columns["PlayerID"].Visible = false;
            dataGridViewVBPlayersHome.Columns["APS"].Visible = false;
            dataGridViewVBPlayersHome.Columns["PPG"].Visible = false;
            dataGridViewVBPlayersStats.Columns["PlayerID"].Visible = false;
        }

        //Load Table
        private void LoadVolleyballPlayersHome()
        {
            try
            {
                string query = "SELECT * FROM volleyballPlayersInfo";
                DBHelper.DBHelper.fill(query, dataGridViewVBPlayersHome);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void LoadVolleyballPlayersStats()
        {
            try
            {
                string query = "SELECT * FROM volleyballPlayers";
                DBHelper.DBHelper.fill(query, dataGridViewVBPlayersStats);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }
}
