﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormBasketballProfiles : Form
    {
        private Dictionary<int, Image> PlayerProfiles;

        //Constructor
        public FormBasketballProfiles(string playerName, string team, int jerseyNumber, string position, double points, double assists, double rebounds, double steals, double height, int weight, int age, string birthday, double efficiency, int playerId)
        {
            InitializeComponent();
            LoadPlayerProfiles();
            lblPlayerName.Text = playerName;
            lblTeam.Text = team;
            lblJerseyNumber.Text = "#" + jerseyNumber.ToString();
            lblPosition.Text = position;
            lblPoints.Text = points.ToString();
            lblAssist.Text = assists.ToString();
            lblRebounds.Text = rebounds.ToString();
            lblSteals.Text = steals.ToString();
            lblHeight.Text = height.ToString() + "m";
            lblWeight.Text = weight.ToString() + "kg";
            lblAge.Text = age.ToString() + " years";
            lblBirthday.Text = birthday;
            lblEfficiency.Text = "+" + efficiency.ToString();

            // Ensure the playerId is in the dictionary
            if (PlayerProfiles.ContainsKey(playerId))
            {
                pictureBoxPlayer.Image = PlayerProfiles[playerId];
            }
            else
            {
                // Handle missing playerId if necessary, e.g., by using a default image
                pictureBoxPlayer.Image = PlayerProfiles.Values.First(); // or any default image
            }
        }

        //Load Profile
        private void LoadPlayerProfiles()
        {
            PlayerProfiles = new Dictionary<int, Image>(); // Initialize the dictionary
            string imagesFolder = @"C:\Users\danie\Documents\C# Repos\AthleteDataSystem\bin\Debug\BBProfiles";
            // Add player profiles with PlayerID as the key
            PlayerProfiles.Add(1, Image.FromFile(Path.Combine(imagesFolder, "Player1.png")));
            PlayerProfiles.Add(2, Image.FromFile(Path.Combine(imagesFolder, "Player2.png")));
            PlayerProfiles.Add(3, Image.FromFile(Path.Combine(imagesFolder, "Player3.png")));
        }
    }
}
