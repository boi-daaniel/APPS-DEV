﻿namespace AthleteDataSystem.Forms
{
    partial class FormGames
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewGames = new System.Windows.Forms.DataGridView();
            this.panelBBHome = new System.Windows.Forms.Panel();
            this.panelDash = new System.Windows.Forms.Panel();
            this.TextboxSearch = new AthleteDataSystem.CustomControls.CurveTextbox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGames)).BeginInit();
            this.panelBBHome.SuspendLayout();
            this.panelDash.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewGames
            // 
            this.dataGridViewGames.AllowUserToAddRows = false;
            this.dataGridViewGames.AllowUserToDeleteRows = false;
            this.dataGridViewGames.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridViewGames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGames.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewGames.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewGames.Name = "dataGridViewGames";
            this.dataGridViewGames.ReadOnly = true;
            this.dataGridViewGames.Size = new System.Drawing.Size(800, 350);
            this.dataGridViewGames.TabIndex = 0;
            // 
            // panelBBHome
            // 
            this.panelBBHome.BackColor = System.Drawing.Color.DimGray;
            this.panelBBHome.Controls.Add(this.dataGridViewGames);
            this.panelBBHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBBHome.Location = new System.Drawing.Point(0, 100);
            this.panelBBHome.Name = "panelBBHome";
            this.panelBBHome.Size = new System.Drawing.Size(800, 350);
            this.panelBBHome.TabIndex = 7;
            // 
            // panelDash
            // 
            this.panelDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.panelDash.Controls.Add(this.TextboxSearch);
            this.panelDash.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDash.Location = new System.Drawing.Point(0, 0);
            this.panelDash.Name = "panelDash";
            this.panelDash.Size = new System.Drawing.Size(800, 100);
            this.panelDash.TabIndex = 6;
            // 
            // TextboxSearch
            // 
            this.TextboxSearch.BackColor = System.Drawing.SystemColors.Window;
            this.TextboxSearch.BorderColor = System.Drawing.Color.Black;
            this.TextboxSearch.BorderFocusColor = System.Drawing.Color.HotPink;
            this.TextboxSearch.BorderRadius = 15;
            this.TextboxSearch.BorderSize = 2;
            this.TextboxSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.TextboxSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextboxSearch.ForeColor = System.Drawing.Color.DimGray;
            this.TextboxSearch.Location = new System.Drawing.Point(0, 0);
            this.TextboxSearch.Multiline = false;
            this.TextboxSearch.Name = "TextboxSearch";
            this.TextboxSearch.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.TextboxSearch.PasswordChar = false;
            this.TextboxSearch.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.TextboxSearch.PlaceholderText = "Search";
            this.TextboxSearch.Size = new System.Drawing.Size(800, 31);
            this.TextboxSearch.TabIndex = 1;
            this.TextboxSearch.Texts = "";
            this.TextboxSearch.UnderlinedStyle = false;
            // 
            // FormGames
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelBBHome);
            this.Controls.Add(this.panelDash);
            this.Name = "FormGames";
            this.Text = "Games Schedules";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGames)).EndInit();
            this.panelBBHome.ResumeLayout(false);
            this.panelDash.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewGames;
        private System.Windows.Forms.Panel panelBBHome;
        private System.Windows.Forms.Panel panelDash;
        private CustomControls.CurveTextbox TextboxSearch;
    }
}