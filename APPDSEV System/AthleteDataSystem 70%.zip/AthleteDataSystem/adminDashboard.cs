﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem
{
    public partial class adminDashboard : Form
    {
        private Form activeForm;// Field to open form

        //Constructor
        public adminDashboard()
        {
            InitializeComponent();
        }

        //Methods
        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
            activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDBTable.Controls.Add(childForm);
            this.panelDBTable.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        //Switching Forms
        private void btnBasketball_Click(object sender, EventArgs e)
        {
            OpenChildForm(new AdminForms.FormBB(), sender); //Open Form
        }
        private void btnVolleyball_Click(object sender, EventArgs e)
        {
            OpenChildForm(new AdminForms.FormVB(), sender); //Open Form
        }
        private void btnGamesSchedules_Click(object sender, EventArgs e)
        {
            OpenChildForm(new AdminForms.FormGS(), sender); //Open Form

        }
        private void btnAccounts_Click(object sender, EventArgs e)
        {
            OpenChildForm(new AdminForms.FormAccounts(), sender); //Open Form
        }
        //Logout Button
        private void logoutBtn_Click_1(object sender, EventArgs e)
        {
            this.Hide(); // Hide the Players form
            Login loginForm = new Login();
            loginForm.Show(); // Show the Login form
        }

        //Close Form
        private void adminDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application
        }

    }
}
