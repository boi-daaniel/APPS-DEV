﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem
{
    public partial class CreateAccount : Form
    {
        public CreateAccount()
        {
            InitializeComponent();
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text.Trim();
            string password = passwordTextBox.Text.Trim();

            // Validate username and password
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter a username and password.");
                return;
            }

            try
            {
                // Check if the username already exists in the database
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select count(*) from users where [username] = '" + username + "'";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                int count = (int)DBHelper.DBHelper.command.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("Username already exists. Please choose a different username.");
                    return;
                }

                // Insert the new account into the database
                DBHelper.DBHelper.gen = "Insert into users ([username], [password]) values (@username, @password)";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.command.Parameters.AddWithValue("@username", username);
                DBHelper.DBHelper.command.Parameters.AddWithValue("@password", password);
                DBHelper.DBHelper.command.ExecuteNonQuery();

                MessageBox.Show("Account created successfully.");
                this.Close(); // Close the CreateAccount form
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating account: " + ex.Message);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the Players form
            Login loginForm = new Login();
            loginForm.Show(); // Show the Login form
            this.Hide(); // Hide the Players form

        }
    }
}
