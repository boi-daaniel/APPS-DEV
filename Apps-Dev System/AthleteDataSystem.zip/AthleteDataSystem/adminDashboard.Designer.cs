﻿namespace AthleteDataSystem
{
    partial class adminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminDashboard));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtFieldGoalAttempted = new System.Windows.Forms.TextBox();
            this.txtFieldGoalMades = new System.Windows.Forms.TextBox();
            this.FieldGoalsAttempted = new System.Windows.Forms.Label();
            this.FieldGoalsMade = new System.Windows.Forms.Label();
            this.txtAssistPerGame = new System.Windows.Forms.TextBox();
            this.AssistPerGame = new System.Windows.Forms.Label();
            this.txtPointsPerGame = new System.Windows.Forms.TextBox();
            this.PointsPerGame = new System.Windows.Forms.Label();
            this.txtAverageMinutes = new System.Windows.Forms.TextBox();
            this.AverageMinutes = new System.Windows.Forms.Label();
            this.GamesPlayed = new System.Windows.Forms.Label();
            this.txtGamesPlayed = new System.Windows.Forms.TextBox();
            this.txtTeam = new System.Windows.Forms.TextBox();
            this.Team = new System.Windows.Forms.Label();
            this.Name = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.newBtn = new System.Windows.Forms.Button();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.saveBtn = new System.Windows.Forms.Button();
            this.greetings = new System.Windows.Forms.Label();
            this.logoutBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.GridColor = System.Drawing.Color.Black;
            this.dataGridView1.Location = new System.Drawing.Point(135, 246);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(751, 286);
            this.dataGridView1.TabIndex = 46;
            // 
            // txtFieldGoalAttempted
            // 
            this.txtFieldGoalAttempted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFieldGoalAttempted.Location = new System.Drawing.Point(769, 194);
            this.txtFieldGoalAttempted.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFieldGoalAttempted.Multiline = true;
            this.txtFieldGoalAttempted.Name = "txtFieldGoalAttempted";
            this.txtFieldGoalAttempted.Size = new System.Drawing.Size(101, 24);
            this.txtFieldGoalAttempted.TabIndex = 45;
            // 
            // txtFieldGoalMades
            // 
            this.txtFieldGoalMades.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFieldGoalMades.Location = new System.Drawing.Point(769, 158);
            this.txtFieldGoalMades.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFieldGoalMades.Multiline = true;
            this.txtFieldGoalMades.Name = "txtFieldGoalMades";
            this.txtFieldGoalMades.Size = new System.Drawing.Size(101, 24);
            this.txtFieldGoalMades.TabIndex = 44;
            // 
            // FieldGoalsAttempted
            // 
            this.FieldGoalsAttempted.AutoSize = true;
            this.FieldGoalsAttempted.BackColor = System.Drawing.Color.Transparent;
            this.FieldGoalsAttempted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FieldGoalsAttempted.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FieldGoalsAttempted.ForeColor = System.Drawing.Color.Black;
            this.FieldGoalsAttempted.Location = new System.Drawing.Point(707, 194);
            this.FieldGoalsAttempted.Name = "FieldGoalsAttempted";
            this.FieldGoalsAttempted.Size = new System.Drawing.Size(41, 18);
            this.FieldGoalsAttempted.TabIndex = 43;
            this.FieldGoalsAttempted.Text = "FGA";
            // 
            // FieldGoalsMade
            // 
            this.FieldGoalsMade.AutoSize = true;
            this.FieldGoalsMade.BackColor = System.Drawing.Color.Transparent;
            this.FieldGoalsMade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FieldGoalsMade.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FieldGoalsMade.ForeColor = System.Drawing.Color.Black;
            this.FieldGoalsMade.Location = new System.Drawing.Point(707, 158);
            this.FieldGoalsMade.Name = "FieldGoalsMade";
            this.FieldGoalsMade.Size = new System.Drawing.Size(45, 18);
            this.FieldGoalsMade.TabIndex = 42;
            this.FieldGoalsMade.Text = "FGM";
            // 
            // txtAssistPerGame
            // 
            this.txtAssistPerGame.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAssistPerGame.Location = new System.Drawing.Point(589, 194);
            this.txtAssistPerGame.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAssistPerGame.Multiline = true;
            this.txtAssistPerGame.Name = "txtAssistPerGame";
            this.txtAssistPerGame.Size = new System.Drawing.Size(101, 24);
            this.txtAssistPerGame.TabIndex = 41;
            // 
            // AssistPerGame
            // 
            this.AssistPerGame.AutoSize = true;
            this.AssistPerGame.BackColor = System.Drawing.Color.Transparent;
            this.AssistPerGame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AssistPerGame.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AssistPerGame.ForeColor = System.Drawing.Color.Black;
            this.AssistPerGame.Location = new System.Drawing.Point(535, 194);
            this.AssistPerGame.Name = "AssistPerGame";
            this.AssistPerGame.Size = new System.Drawing.Size(41, 18);
            this.AssistPerGame.TabIndex = 40;
            this.AssistPerGame.Text = "APG";
            // 
            // txtPointsPerGame
            // 
            this.txtPointsPerGame.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPointsPerGame.Location = new System.Drawing.Point(589, 158);
            this.txtPointsPerGame.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPointsPerGame.Multiline = true;
            this.txtPointsPerGame.Name = "txtPointsPerGame";
            this.txtPointsPerGame.Size = new System.Drawing.Size(101, 24);
            this.txtPointsPerGame.TabIndex = 39;
            // 
            // PointsPerGame
            // 
            this.PointsPerGame.AutoSize = true;
            this.PointsPerGame.BackColor = System.Drawing.Color.Transparent;
            this.PointsPerGame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PointsPerGame.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PointsPerGame.ForeColor = System.Drawing.Color.Black;
            this.PointsPerGame.Location = new System.Drawing.Point(535, 158);
            this.PointsPerGame.Name = "PointsPerGame";
            this.PointsPerGame.Size = new System.Drawing.Size(40, 18);
            this.PointsPerGame.TabIndex = 38;
            this.PointsPerGame.Text = "PPG";
            // 
            // txtAverageMinutes
            // 
            this.txtAverageMinutes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAverageMinutes.Location = new System.Drawing.Point(364, 194);
            this.txtAverageMinutes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAverageMinutes.Multiline = true;
            this.txtAverageMinutes.Name = "txtAverageMinutes";
            this.txtAverageMinutes.Size = new System.Drawing.Size(101, 24);
            this.txtAverageMinutes.TabIndex = 37;
            // 
            // AverageMinutes
            // 
            this.AverageMinutes.AutoSize = true;
            this.AverageMinutes.BackColor = System.Drawing.Color.Transparent;
            this.AverageMinutes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AverageMinutes.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AverageMinutes.ForeColor = System.Drawing.Color.Black;
            this.AverageMinutes.Location = new System.Drawing.Point(320, 194);
            this.AverageMinutes.Name = "AverageMinutes";
            this.AverageMinutes.Size = new System.Drawing.Size(34, 18);
            this.AverageMinutes.TabIndex = 36;
            this.AverageMinutes.Text = "AM";
            // 
            // GamesPlayed
            // 
            this.GamesPlayed.AutoSize = true;
            this.GamesPlayed.BackColor = System.Drawing.Color.Transparent;
            this.GamesPlayed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GamesPlayed.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GamesPlayed.ForeColor = System.Drawing.Color.Black;
            this.GamesPlayed.Location = new System.Drawing.Point(320, 158);
            this.GamesPlayed.Name = "GamesPlayed";
            this.GamesPlayed.Size = new System.Drawing.Size(30, 18);
            this.GamesPlayed.TabIndex = 35;
            this.GamesPlayed.Text = "GP";
            // 
            // txtGamesPlayed
            // 
            this.txtGamesPlayed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGamesPlayed.Location = new System.Drawing.Point(364, 158);
            this.txtGamesPlayed.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGamesPlayed.Multiline = true;
            this.txtGamesPlayed.Name = "txtGamesPlayed";
            this.txtGamesPlayed.Size = new System.Drawing.Size(101, 24);
            this.txtGamesPlayed.TabIndex = 34;
            // 
            // txtTeam
            // 
            this.txtTeam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTeam.Location = new System.Drawing.Point(213, 194);
            this.txtTeam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTeam.Multiline = true;
            this.txtTeam.Name = "txtTeam";
            this.txtTeam.Size = new System.Drawing.Size(101, 24);
            this.txtTeam.TabIndex = 33;
            // 
            // Team
            // 
            this.Team.AutoSize = true;
            this.Team.BackColor = System.Drawing.Color.Transparent;
            this.Team.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Team.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Team.ForeColor = System.Drawing.Color.Black;
            this.Team.Location = new System.Drawing.Point(137, 194);
            this.Team.Name = "Team";
            this.Team.Size = new System.Drawing.Size(55, 18);
            this.Team.TabIndex = 32;
            this.Team.Text = "TEAM";
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.BackColor = System.Drawing.Color.Transparent;
            this.Name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Name.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name.ForeColor = System.Drawing.Color.Black;
            this.Name.Location = new System.Drawing.Point(136, 158);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(56, 18);
            this.Name.TabIndex = 31;
            this.Name.Text = "NAME";
            // 
            // txtName
            // 
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.Location = new System.Drawing.Point(213, 158);
            this.txtName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(101, 24);
            this.txtName.TabIndex = 30;
            // 
            // newBtn
            // 
            this.newBtn.BackColor = System.Drawing.Color.White;
            this.newBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.newBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.newBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newBtn.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBtn.ForeColor = System.Drawing.Color.Black;
            this.newBtn.Location = new System.Drawing.Point(163, 103);
            this.newBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(85, 30);
            this.newBtn.TabIndex = 29;
            this.newBtn.Text = "NEW";
            this.newBtn.UseVisualStyleBackColor = false;
            this.newBtn.Click += new System.EventHandler(this.insertBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.White;
            this.deleteBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.deleteBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteBtn.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.Black;
            this.deleteBtn.Location = new System.Drawing.Point(756, 106);
            this.deleteBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(85, 30);
            this.deleteBtn.TabIndex = 28;
            this.deleteBtn.Text = "DELETE";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.White;
            this.updateBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.updateBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateBtn.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.ForeColor = System.Drawing.Color.Black;
            this.updateBtn.Location = new System.Drawing.Point(577, 106);
            this.updateBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(104, 30);
            this.updateBtn.TabIndex = 27;
            this.updateBtn.Text = "UPDATE";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.White;
            this.saveBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.saveBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.saveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveBtn.Font = new System.Drawing.Font("Georgia", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.ForeColor = System.Drawing.Color.Black;
            this.saveBtn.Location = new System.Drawing.Point(335, 106);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(85, 30);
            this.saveBtn.TabIndex = 26;
            this.saveBtn.Text = "SAVE";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // greetings
            // 
            this.greetings.AutoSize = true;
            this.greetings.BackColor = System.Drawing.Color.Transparent;
            this.greetings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.greetings.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.greetings.ForeColor = System.Drawing.Color.White;
            this.greetings.Location = new System.Drawing.Point(407, 36);
            this.greetings.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.greetings.Name = "greetings";
            this.greetings.Size = new System.Drawing.Size(175, 25);
            this.greetings.TabIndex = 25;
            this.greetings.Text = "Welcome Admins";
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.Transparent;
            this.logoutBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.logoutBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.logoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutBtn.Font = new System.Drawing.Font("Georgia", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutBtn.ForeColor = System.Drawing.Color.Black;
            this.logoutBtn.Location = new System.Drawing.Point(887, 16);
            this.logoutBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(75, 30);
            this.logoutBtn.TabIndex = 47;
            this.logoutBtn.Text = "Back";
            this.logoutBtn.UseVisualStyleBackColor = false;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // adminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1003, 603);
            this.Controls.Add(this.logoutBtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtFieldGoalAttempted);
            this.Controls.Add(this.txtFieldGoalMades);
            this.Controls.Add(this.FieldGoalsAttempted);
            this.Controls.Add(this.FieldGoalsMade);
            this.Controls.Add(this.txtAssistPerGame);
            this.Controls.Add(this.AssistPerGame);
            this.Controls.Add(this.txtPointsPerGame);
            this.Controls.Add(this.PointsPerGame);
            this.Controls.Add(this.txtAverageMinutes);
            this.Controls.Add(this.AverageMinutes);
            this.Controls.Add(this.GamesPlayed);
            this.Controls.Add(this.txtGamesPlayed);
            this.Controls.Add(this.txtTeam);
            this.Controls.Add(this.Team);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.newBtn);
            this.Controls.Add(this.deleteBtn);
            this.Controls.Add(this.updateBtn);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.greetings);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "adminDashboard";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtFieldGoalAttempted;
        private System.Windows.Forms.TextBox txtFieldGoalMades;
        private System.Windows.Forms.Label FieldGoalsAttempted;
        private System.Windows.Forms.Label FieldGoalsMade;
        private System.Windows.Forms.TextBox txtAssistPerGame;
        private System.Windows.Forms.Label AssistPerGame;
        private System.Windows.Forms.TextBox txtPointsPerGame;
        private System.Windows.Forms.Label PointsPerGame;
        private System.Windows.Forms.TextBox txtAverageMinutes;
        private System.Windows.Forms.Label AverageMinutes;
        private System.Windows.Forms.Label GamesPlayed;
        private System.Windows.Forms.TextBox txtGamesPlayed;
        private System.Windows.Forms.TextBox txtTeam;
        private System.Windows.Forms.Label Team;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button newBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.Button updateBtn;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.Label greetings;
        private System.Windows.Forms.Button logoutBtn;
    }
}