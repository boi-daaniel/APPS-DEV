﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace AthleteDataSystem
{
    public partial class Login : Form
    {
        public static string sendtext = "";
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select * from users where [username] = '" + txtusername.Text + "' and [password] = '" + txtpassword.Text + "'";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                    //database  
                    string username = DBHelper.DBHelper.reader["username"].ToString();
                    string password = DBHelper.DBHelper.reader["password"].ToString();

                    timer1.Enabled = true;
                    timer1.Interval = 1;
                    progressBar1.Maximum = 200;
                    timer1.Start();
                    timer1.Tick += new EventHandler(timer1_Tick);

                    if (username == "admin" && password == "admin")
                    {
                        // Redirect to adminDashboard
                        this.Hide();
                        adminDashboard adminForm = new adminDashboard();
                        adminForm.Show();
                    }
                    else
                    {
                        // Redirect to userDashboard
                        this.Hide();
                        userDashboard userForm = new userDashboard();
                        userForm.Show();
                    }

                }
                else
                {
                    MessageBox.Show("Invalid Username and Password");
                }
                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message);

            }

        }

        // Timer Properties Method
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value != 200)
            {
                progressBar1.Value += 1;
            }
            else
            {
                timer1.Stop();
                this.Hide();
                progressBar1.Value = 0;
                sendtext = txtusername.Text;

            }
        }

        // Create Account Method
        private void createAccountBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the Players form
            CreateAccount createAccountForm = new CreateAccount();
            createAccountForm.Show();
        }

        //Close form
        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.Exit(); // Close the application
            }
        }
    }
}
