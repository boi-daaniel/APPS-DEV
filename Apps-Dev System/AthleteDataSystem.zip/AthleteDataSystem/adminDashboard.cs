﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem
{
    public partial class adminDashboard : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;
        private int selectedRowIndex;
        public adminDashboard()
        {
            InitializeComponent();
            LoadData();
        }

        // Load Database Table Method
        private void LoadData()
        {
            try
            {
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Players.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM players", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "Players");
                dataGridView1.DataSource = dataSet.Tables["Players"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        // Save Button Method
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("INSERT INTO players (Name, Team, GamesPlayed, AverageMinutes, PointsPerGame, AssistPerGame, FieldGoalsMade, FieldGoalsAttempted) VALUES (@Name, @Team, @GamesPlayed, @AverageMinutes, @PointsPerGame, @AssistPerGame, @FieldGoalMades, @FieldGoalAttempted)", connection);
                command.Parameters.AddWithValue("@Name", txtName.Text);
                command.Parameters.AddWithValue("@Team", txtTeam.Text);
                command.Parameters.AddWithValue("@GamesPlayed", int.Parse(txtGamesPlayed.Text));
                command.Parameters.AddWithValue("@AverageMinutes", double.Parse(txtAverageMinutes.Text));
                command.Parameters.AddWithValue("@PointsPerGame", double.Parse(txtPointsPerGame.Text));
                command.Parameters.AddWithValue("@AssistPerGame", double.Parse(txtAssistPerGame.Text));
                command.Parameters.AddWithValue("@FieldGoalMades", double.Parse(txtFieldGoalMades.Text));
                command.Parameters.AddWithValue("@FieldGoalAttempted", double.Parse(txtFieldGoalAttempted.Text));
                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                LoadData(); // Refresh the data in the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }


        // Update Button Method
        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                    DataRow selectedRow = dataSet.Tables["players"].Rows[selectedRowIndex];

                    /*selectedRow["Name"] = txtName.Text;
                    selectedRow["Team"] = txtTeam.Text;*/
                    if (!string.IsNullOrEmpty(txtGamesPlayed.Text))
                    {
                        selectedRow["GamesPlayed"] = int.Parse(txtGamesPlayed.Text);
                    }

                    if (!string.IsNullOrEmpty(txtAverageMinutes.Text))
                    {
                        selectedRow["AverageMinutes"] = double.Parse(txtAverageMinutes.Text);
                    }

                    if (!string.IsNullOrEmpty(txtPointsPerGame.Text))
                    {
                        selectedRow["PointsPerGame"] = double.Parse(txtPointsPerGame.Text);
                    }

                    if (!string.IsNullOrEmpty(txtAssistPerGame.Text))
                    {
                        selectedRow["AssistPerGame"] = double.Parse(txtAssistPerGame.Text);
                    }

                    if (!string.IsNullOrEmpty(txtFieldGoalMades.Text))
                    {
                        selectedRow["FieldGoalsMade"] = double.Parse(txtFieldGoalMades.Text);
                    }

                    if (!string.IsNullOrEmpty(txtFieldGoalAttempted.Text))
                    {
                        selectedRow["FieldGoalsAttempted"] = double.Parse(txtFieldGoalAttempted.Text);
                    }

                    connection.Open();
                    OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                    dataAdapter.UpdateCommand = cmdBuilder.GetUpdateCommand();
                    dataAdapter.Update(dataSet, "Players");

                    MessageBox.Show("Data updated successfully.");
                    LoadData(); // Refresh the data in the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }
        
        // Delete Button Method
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        dataSet.Tables["Players"].Rows[selectedRowIndex].Delete();

                        connection.Open();
                        OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                        dataAdapter.DeleteCommand = cmdBuilder.GetDeleteCommand();
                        dataAdapter.Update(dataSet, "Players");

                        MessageBox.Show("Record deleted successfully.");
                        LoadData(); // Refresh the data in the DataGridView
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        // New Button Method
        private void insertBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                    DataRow selectedRow = dataSet.Tables["players"].Rows[selectedRowIndex];

                    /*selectedRow["Name"] = txtName.Text;
                    selectedRow["Team"] = txtTeam.Text;*/
                    if (!string.IsNullOrEmpty(txtGamesPlayed.Text))
                    {
                        selectedRow["GamesPlayed"] = int.Parse(txtGamesPlayed.Text);
                    }

                    if (!string.IsNullOrEmpty(txtAverageMinutes.Text))
                    {
                        selectedRow["AverageMinutes"] = double.Parse(txtAverageMinutes.Text);
                    }

                    if (!string.IsNullOrEmpty(txtPointsPerGame.Text))
                    {
                        selectedRow["PointsPerGame"] = double.Parse(txtPointsPerGame.Text);
                    }

                    if (!string.IsNullOrEmpty(txtAssistPerGame.Text))
                    {
                        selectedRow["AssistPerGame"] = double.Parse(txtAssistPerGame.Text);
                    }

                    if (!string.IsNullOrEmpty(txtFieldGoalMades.Text))
                    {
                        selectedRow["FieldGoalsMade"] = double.Parse(txtFieldGoalMades.Text);
                    }

                    if (!string.IsNullOrEmpty(txtFieldGoalAttempted.Text))
                    {
                        selectedRow["FieldGoalsAttempted"] = double.Parse(txtFieldGoalAttempted.Text);
                    }

                    connection.Open();
                    OleDbCommandBuilder cmdBuilder = new OleDbCommandBuilder(dataAdapter);
                    dataAdapter.UpdateCommand = cmdBuilder.GetUpdateCommand();
                    dataAdapter.Update(dataSet, "Players");

                    MessageBox.Show("Data updated successfully.");
                    LoadData(); // Refresh the data in the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        // Logout Button
        private void logoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the Players form
            Login loginForm = new Login();
            loginForm.Show(); // Show the Login form
        }

        //Close form
        private void adminDashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.Exit(); // Close the application
            }
        }
    }
}
