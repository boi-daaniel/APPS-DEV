﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormGS : Form
    {
        //Fields
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;

        //Constructor
        public FormGS()
        {
            InitializeComponent();
            LoadGamesSchedules();
        }

        //Load Table
        private void LoadGamesSchedules()
        {
            try
            {
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ADS.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM games", connection);
                dataSet = new DataSet();  // Initialize dataSet here

                connection.Open();
                dataAdapter.Fill(dataSet, "ADS");
                dataGridViewGames.DataSource = dataSet.Tables["ADS"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        //New Button
        private void newBtn_Click(object sender, EventArgs e)
        {
            txtGames.Texts = "";
            txtTeamMatchup.Texts = "";
            txtTime.Texts = "";
            txtDate.Value = DateTime.Now;
        }
        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("INSERT INTO games ([TeamMatchup], [Games], [Time], [GameDate]) VALUES (@TeamMatchup, @Games, @Time, @Date)", connection);
                command.Parameters.AddWithValue("@TeamMatchup", txtTeamMatchup.Texts);
                command.Parameters.AddWithValue("@Games", txtGames.Texts);
                command.Parameters.AddWithValue("@Time", txtTime.Texts);
                command.Parameters.AddWithValue("@Date", txtDate.Value);
                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                LoadGamesSchedules();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        //Update Button
        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridViewGames.SelectedCells.Count > 0)
            {
                try
                {
                    int selectedRowIndex = dataGridViewGames.SelectedCells[0].RowIndex;
                    int selectedColumnIndex = dataGridViewGames.SelectedCells[0].ColumnIndex;
                    string columnName = dataGridViewGames.Columns[selectedColumnIndex].Name;
                    DataRow selectedRow = dataSet.Tables["ADS"].Rows[selectedRowIndex];

                    switch (columnName)
                    {
                        case "TeamMatchup":
                            selectedRow["TeamMatchup"] = txtTeamMatchup.Texts;
                            break;
                        case "Games":
                            selectedRow["Games"] = txtGames.Texts;
                            break;
                        case "Time":
                            selectedRow["Time"] = txtTime.Texts;
                            break;
                        case "GameDate":
                            selectedRow["GameDate"] = txtDate.Value;
                            break;
                        default:
                            MessageBox.Show("Cannot Update");
                            break;
                    }

                    connection.Open();
                    OleDbCommand command = new OleDbCommand("UPDATE games SET [" + columnName + "] = @Value WHERE MatchID = @MatchID", connection);
                    command.Parameters.AddWithValue("@Value", selectedRow[columnName]);
                    command.Parameters.AddWithValue("@MatchID", selectedRow["MatchID"]);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Data updated successfully.");
                    LoadGamesSchedules();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
        }
            //Delete Button
            private void deleteBtn_Click(object sender, EventArgs e)
            {
                if (dataGridViewGames.SelectedRows.Count > 0)
                {
                    if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        try
                        {
                            int selectedRowIndex = dataGridViewGames.SelectedRows[0].Index;
                            DataRow selectedRow = dataSet.Tables["ADS"].Rows[selectedRowIndex];

                            if (selectedRow["TeamMatchup"] != DBNull.Value)
                            {
                                connection.Open();
                                OleDbCommand command = new OleDbCommand("DELETE FROM games WHERE TeamMatchup = @MatchID", connection);
                                command.Parameters.AddWithValue("@MatchID", selectedRow["TeamMatchup"]);
                                command.ExecuteNonQuery();
                                MessageBox.Show("Record deleted successfully.");
                                LoadGamesSchedules(); // Refresh the data in the DataGridView
                            }
                            else
                            {
                                MessageBox.Show("Fileds cannot be null.");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }
                        finally
                        {
                            if (connection != null && connection.State == ConnectionState.Open)
                            {
                                connection.Close();
                            }
                        }
                    }
                }
            }

            private void dataGridViewGames_CellClick(object sender, DataGridViewCellEventArgs e)
            {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridViewGames.Rows.Count)
            {
                txtTeamMatchup.Texts = dataGridViewGames[1, e.RowIndex].Value?.ToString();
                txtGames.Texts = dataGridViewGames[2, e.RowIndex].Value?.ToString();
                txtTime.Texts = dataGridViewGames[3, e.RowIndex].Value?.ToString();
                txtDate.Value = Convert.ToDateTime(dataGridViewGames[4, e.RowIndex].Value);
            }
        }
        
    }
}
