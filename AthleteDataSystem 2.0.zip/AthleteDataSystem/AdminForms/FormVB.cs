﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormVB : Form
    {
        //Fields
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private DataSet dataSet;

        //Constructor
        public FormVB()
        {
            InitializeComponent();
            LoadVolleyballPlayers();
        }

        //Load Table
        private void LoadVolleyballPlayers()
        {
            try
            {
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=ADS.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM volleyballPlayers", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "ADS");
                dataGridView1.DataSource = dataSet.Tables["ADS"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        //New Button
        private void newBtn_Click(object sender, EventArgs e)
        {
            // Clear text fields when a row is selected
            txtName.Texts = "";
            txtTeam.Texts = "";
            txtSetsPlayed.Texts = "";
            txtAverageSet.Texts = "";
            txtPointsPerGame.Texts = "";
            txtBlockPerGame.Texts = "";
            txtAce.Texts = "";
            txtDig.Texts = "";
            txtReceive.Texts = "";
        }

        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand("INSERT INTO volleyballPlayers (Name, Team, Sets Played, Average Sets, Points, Block, Ace, Dig, Receive) VALUES (@Name, @Team, @Sets Played, @Average Sets, @Points, @Block, @Ace, @Dig, @Receive)", connection);
                command.Parameters.AddWithValue("@Name", txtName.Texts);
                command.Parameters.AddWithValue("@Team", txtTeam.Texts);
                command.Parameters.AddWithValue("@Sets Played", int.Parse(txtSetsPlayed.Texts));
                command.Parameters.AddWithValue("@Average Sets", double.Parse(txtAverageSet.Texts));
                command.Parameters.AddWithValue("@Points", double.Parse(txtPointsPerGame.Texts));
                command.Parameters.AddWithValue("@Block", double.Parse(txtBlockPerGame.Texts));
                command.Parameters.AddWithValue("@Ace", double.Parse(txtAce.Texts));
                command.Parameters.AddWithValue("@Dig", double.Parse(txtDig.Texts));                
                command.Parameters.AddWithValue("@Receive", double.Parse(txtReceive.Texts));                
                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                LoadVolleyballPlayers(); // Refresh the data in the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        //Update Button
        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                try
                {
                    int selectedRowIndex = dataGridView1.SelectedCells[0].RowIndex;
                    int selectedColumnIndex = dataGridView1.SelectedCells[0].ColumnIndex;
                    string columnName = dataGridView1.Columns[selectedColumnIndex].Name;
                    DataRow selectedRow = dataSet.Tables["ADS"].Rows[selectedRowIndex];

                    switch (columnName)
                    {
                        case "PlayersName":
                            selectedRow["PlayersName"] = txtName.Texts;
                            break;
                        case "Team":
                            selectedRow["Team"] = txtTeam.Texts;
                            break;
                        case "Sets Played":
                            selectedRow["Sets Played"] = int.Parse(txtSetsPlayed.Texts);
                            break;
                        case "Average Sets":
                            selectedRow["Average Sets"] = double.Parse(txtAverageSet.Texts);
                            break;
                        case "Points":
                            selectedRow["Points"] = int.Parse(txtPointsPerGame.Texts);
                            break;
                        case "Block":
                            selectedRow["Block"] = int.Parse(txtBlockPerGame.Texts);
                            break;
                        case "Ace":
                            selectedRow["Ace"] = int.Parse(txtAce.Texts);
                            break;
                        case "Dig":
                            selectedRow["Dig"] = int.Parse(txtDig.Texts);
                            break;
                        case "Receive":
                            selectedRow["Receive"] = int.Parse(txtReceive.Texts);
                            break;
                        default:
                            MessageBox.Show("Cannot Update Row. Select Column Only");
                            return;
                    }

                    connection.Open();
                    OleDbCommand command = new OleDbCommand("UPDATE volleyballPlayers SET [" + columnName + "] = @Value WHERE PlayerID = @ID", connection);
                    command.Parameters.AddWithValue("@Value", selectedRow[columnName]);
                    command.Parameters.AddWithValue("@ID", selectedRow["PlayerID"]);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Data updated successfully.");
                    LoadVolleyballPlayers(); // Refresh the data in the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a cell to update.");
            }
        }

        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = dataSet.Tables["ADS"].Rows[selectedRowIndex];

                        if (selectedRow["Player ID"] != DBNull.Value)
                        {
                            connection.Open();
                            OleDbCommand command = new OleDbCommand("DELETE FROM volleyballPlayers WHERE Player ID = @PlayerID", connection);
                            command.Parameters.AddWithValue("@Player ID", selectedRow["PlayerID"]);
                            command.ExecuteNonQuery();
                            MessageBox.Show("Record deleted successfully.");
                            LoadVolleyballPlayers(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("PlayerID cannot be null.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        //Data Table Cell Click
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtName.Texts = dataGridView1[1, e.RowIndex].Value.ToString();
                txtTeam.Texts = dataGridView1[2, e.RowIndex].Value.ToString();
                txtSetsPlayed.Texts = dataGridView1[3, e.RowIndex].Value.ToString();
                txtAverageSet.Texts = dataGridView1[4, e.RowIndex].Value.ToString();
                txtPointsPerGame.Texts = dataGridView1[5, e.RowIndex].Value.ToString();
                txtBlockPerGame.Texts = dataGridView1[6, e.RowIndex].Value.ToString();
                txtAce.Texts = dataGridView1[7, e.RowIndex].Value.ToString();
                txtDig.Texts = dataGridView1[8, e.RowIndex].Value.ToString();
                txtReceive.Texts = dataGridView1[8, e.RowIndex].Value.ToString();
            }
            catch (Exception) { }
        }
    }
}
