﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem
{
    public partial class CreateAccount : Form
    {
        //Constructor
        public CreateAccount()
        {
            InitializeComponent();
        }

        //Close form
        private void CreateAccount_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                Application.Exit(); // Close the application
            }
        }


        private void submitButton_Click(object sender, EventArgs e)
        {
            string username = usernameTxt.Texts.Trim();
            string password = passwordTxt.Texts.Trim();

            // Validate username and password
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter a username and password.");
                return;
            }

            try
            {
                // Check if the username already exists in the database
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select count(*) from users where [username] = '" + username + "'";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                int count = (int)DBHelper.DBHelper.command.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("Username already exists. Please choose a different username.");
                    return;
                }

                // Insert the new account into the database
                DBHelper.DBHelper.gen = "Insert into users ([username], [password]) values (@username, @password)";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.command.Parameters.AddWithValue("@username", username);
                DBHelper.DBHelper.command.Parameters.AddWithValue("@password", password);
                DBHelper.DBHelper.command.ExecuteNonQuery();

                // Get the ID of the newly created account
                DBHelper.DBHelper.gen = "Select @@Identity";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                int newID = (int)DBHelper.DBHelper.command.ExecuteScalar();


                //Succesful
                MessageBox.Show("Account created successfully.");
                this.Hide(); // Hide the CreateAccount form
                Login loginForm = new Login();
                loginForm.Show(); // Show the Login form
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error creating account: " + ex.Message);
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Back Button
        private void backBtn_Click_1(object sender, EventArgs e)
        {
            this.Hide(); // Hide the Players form
            Login loginForm = new Login();
            loginForm.Show(); // Show the Login form
            this.Hide(); // Hide the Players form
        }

        //Close Form
        private void CreateAccount_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application
        }

        
    }
}
