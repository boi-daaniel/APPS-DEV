﻿namespace AthleteDataSystem.AdminForms
{
    partial class FormVB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PanelCommands = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtReceive = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.labelReceive = new System.Windows.Forms.Label();
            this.txtDig = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtAce = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtBlockPerGame = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtPointsPerGame = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtAverageSet = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtSetsPlayed = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtTeam = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtName = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.newBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelTeam = new System.Windows.Forms.Label();
            this.saveBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.updateBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelName = new System.Windows.Forms.Label();
            this.deleteBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelAverageSet = new System.Windows.Forms.Label();
            this.labelBlock = new System.Windows.Forms.Label();
            this.labelPoints = new System.Windows.Forms.Label();
            this.labelAce = new System.Windows.Forms.Label();
            this.labelDig = new System.Windows.Forms.Label();
            this.labelSetsPlayed = new System.Windows.Forms.Label();
            this.panelTable = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControlVolleyball = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelInfoTable = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panelInfoCommands = new System.Windows.Forms.Panel();
            this.labelWeight = new System.Windows.Forms.Label();
            this.txtWeight = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.labelHeight = new System.Windows.Forms.Label();
            this.txtHeight = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.labelJerseyNumber = new System.Windows.Forms.Label();
            this.txtJerseyNumber = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.labelPosition = new System.Windows.Forms.Label();
            this.txtPosition = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtAge = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.labelAge = new System.Windows.Forms.Label();
            this.labelPlayerTeam = new System.Windows.Forms.Label();
            this.labelBirthdate = new System.Windows.Forms.Label();
            this.labelPlayerName = new System.Windows.Forms.Label();
            this.btnBrowse = new AthleteDataSystem.CustomTools.CurvedButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtSearchPlayer = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtPlayerTeam = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtBirthdate = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtPlayerName = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.btnNew = new AthleteDataSystem.CustomTools.CurvedButton();
            this.btnSave = new AthleteDataSystem.CustomTools.CurvedButton();
            this.btnUpdate = new AthleteDataSystem.CustomTools.CurvedButton();
            this.btnDelete = new AthleteDataSystem.CustomTools.CurvedButton();
            this.btnSearchPlayer = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.PanelCommands.SuspendLayout();
            this.panelTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControlVolleyball.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panelInfoTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panelInfoCommands.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelCommands
            // 
            this.PanelCommands.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.PanelCommands.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PanelCommands.Controls.Add(this.btnSearch);
            this.PanelCommands.Controls.Add(this.txtSearch);
            this.PanelCommands.Controls.Add(this.txtReceive);
            this.PanelCommands.Controls.Add(this.labelReceive);
            this.PanelCommands.Controls.Add(this.txtDig);
            this.PanelCommands.Controls.Add(this.txtAce);
            this.PanelCommands.Controls.Add(this.txtBlockPerGame);
            this.PanelCommands.Controls.Add(this.txtPointsPerGame);
            this.PanelCommands.Controls.Add(this.txtAverageSet);
            this.PanelCommands.Controls.Add(this.txtSetsPlayed);
            this.PanelCommands.Controls.Add(this.txtTeam);
            this.PanelCommands.Controls.Add(this.txtName);
            this.PanelCommands.Controls.Add(this.newBtn);
            this.PanelCommands.Controls.Add(this.labelTeam);
            this.PanelCommands.Controls.Add(this.saveBtn);
            this.PanelCommands.Controls.Add(this.updateBtn);
            this.PanelCommands.Controls.Add(this.labelName);
            this.PanelCommands.Controls.Add(this.deleteBtn);
            this.PanelCommands.Controls.Add(this.labelAverageSet);
            this.PanelCommands.Controls.Add(this.labelBlock);
            this.PanelCommands.Controls.Add(this.labelPoints);
            this.PanelCommands.Controls.Add(this.labelAce);
            this.PanelCommands.Controls.Add(this.labelDig);
            this.PanelCommands.Controls.Add(this.labelSetsPlayed);
            this.PanelCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelCommands.ForeColor = System.Drawing.Color.Black;
            this.PanelCommands.Location = new System.Drawing.Point(0, 0);
            this.PanelCommands.Name = "PanelCommands";
            this.PanelCommands.Size = new System.Drawing.Size(786, 170);
            this.PanelCommands.TabIndex = 56;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Location = new System.Drawing.Point(712, 99);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 65;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Visible = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearch.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtSearch.BorderFocusColor = System.Drawing.SystemColors.Highlight;
            this.txtSearch.BorderRadius = 15;
            this.txtSearch.BorderSize = 2;
            this.txtSearch.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtSearch.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearch.Location = new System.Drawing.Point(0, 138);
            this.txtSearch.Multiline = false;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSearch.PasswordChar = false;
            this.txtSearch.PlaceholderColor = System.Drawing.Color.Black;
            this.txtSearch.PlaceholderText = "Search Player";
            this.txtSearch.Size = new System.Drawing.Size(784, 30);
            this.txtSearch.TabIndex = 64;
            this.txtSearch.Texts = "";
            this.txtSearch.UnderlinedStyle = false;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // txtReceive
            // 
            this.txtReceive.BackColor = System.Drawing.SystemColors.Window;
            this.txtReceive.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtReceive.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtReceive.BorderRadius = 0;
            this.txtReceive.BorderSize = 2;
            this.txtReceive.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReceive.ForeColor = System.Drawing.Color.DimGray;
            this.txtReceive.Location = new System.Drawing.Point(725, 17);
            this.txtReceive.Multiline = false;
            this.txtReceive.Name = "txtReceive";
            this.txtReceive.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtReceive.PasswordChar = false;
            this.txtReceive.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtReceive.PlaceholderText = "";
            this.txtReceive.Size = new System.Drawing.Size(70, 31);
            this.txtReceive.TabIndex = 63;
            this.txtReceive.Texts = "";
            this.txtReceive.UnderlinedStyle = false;
            // 
            // labelReceive
            // 
            this.labelReceive.AutoSize = true;
            this.labelReceive.BackColor = System.Drawing.Color.Transparent;
            this.labelReceive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelReceive.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReceive.ForeColor = System.Drawing.Color.White;
            this.labelReceive.Location = new System.Drawing.Point(650, 17);
            this.labelReceive.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelReceive.Name = "labelReceive";
            this.labelReceive.Size = new System.Drawing.Size(70, 20);
            this.labelReceive.TabIndex = 62;
            this.labelReceive.Text = "Receive:";
            // 
            // txtDig
            // 
            this.txtDig.BackColor = System.Drawing.SystemColors.Window;
            this.txtDig.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtDig.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtDig.BorderRadius = 0;
            this.txtDig.BorderSize = 2;
            this.txtDig.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDig.ForeColor = System.Drawing.Color.DimGray;
            this.txtDig.Location = new System.Drawing.Point(569, 58);
            this.txtDig.Multiline = false;
            this.txtDig.Name = "txtDig";
            this.txtDig.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtDig.PasswordChar = false;
            this.txtDig.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtDig.PlaceholderText = "";
            this.txtDig.Size = new System.Drawing.Size(70, 31);
            this.txtDig.TabIndex = 61;
            this.txtDig.Texts = "";
            this.txtDig.UnderlinedStyle = false;
            // 
            // txtAce
            // 
            this.txtAce.BackColor = System.Drawing.SystemColors.Window;
            this.txtAce.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtAce.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAce.BorderRadius = 0;
            this.txtAce.BorderSize = 2;
            this.txtAce.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAce.ForeColor = System.Drawing.Color.DimGray;
            this.txtAce.Location = new System.Drawing.Point(569, 17);
            this.txtAce.Multiline = false;
            this.txtAce.Name = "txtAce";
            this.txtAce.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtAce.PasswordChar = false;
            this.txtAce.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAce.PlaceholderText = "";
            this.txtAce.Size = new System.Drawing.Size(70, 31);
            this.txtAce.TabIndex = 60;
            this.txtAce.Texts = "";
            this.txtAce.UnderlinedStyle = false;
            // 
            // txtBlockPerGame
            // 
            this.txtBlockPerGame.BackColor = System.Drawing.SystemColors.Window;
            this.txtBlockPerGame.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtBlockPerGame.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtBlockPerGame.BorderRadius = 0;
            this.txtBlockPerGame.BorderSize = 2;
            this.txtBlockPerGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBlockPerGame.ForeColor = System.Drawing.Color.DimGray;
            this.txtBlockPerGame.Location = new System.Drawing.Point(431, 58);
            this.txtBlockPerGame.Multiline = false;
            this.txtBlockPerGame.Name = "txtBlockPerGame";
            this.txtBlockPerGame.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtBlockPerGame.PasswordChar = false;
            this.txtBlockPerGame.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtBlockPerGame.PlaceholderText = "";
            this.txtBlockPerGame.Size = new System.Drawing.Size(70, 31);
            this.txtBlockPerGame.TabIndex = 59;
            this.txtBlockPerGame.Texts = "";
            this.txtBlockPerGame.UnderlinedStyle = false;
            // 
            // txtPointsPerGame
            // 
            this.txtPointsPerGame.BackColor = System.Drawing.SystemColors.Window;
            this.txtPointsPerGame.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPointsPerGame.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPointsPerGame.BorderRadius = 0;
            this.txtPointsPerGame.BorderSize = 2;
            this.txtPointsPerGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPointsPerGame.ForeColor = System.Drawing.Color.DimGray;
            this.txtPointsPerGame.Location = new System.Drawing.Point(431, 17);
            this.txtPointsPerGame.Multiline = false;
            this.txtPointsPerGame.Name = "txtPointsPerGame";
            this.txtPointsPerGame.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPointsPerGame.PasswordChar = false;
            this.txtPointsPerGame.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPointsPerGame.PlaceholderText = "";
            this.txtPointsPerGame.Size = new System.Drawing.Size(70, 31);
            this.txtPointsPerGame.TabIndex = 58;
            this.txtPointsPerGame.Texts = "";
            this.txtPointsPerGame.UnderlinedStyle = false;
            // 
            // txtAverageSet
            // 
            this.txtAverageSet.BackColor = System.Drawing.SystemColors.Window;
            this.txtAverageSet.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtAverageSet.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAverageSet.BorderRadius = 0;
            this.txtAverageSet.BorderSize = 2;
            this.txtAverageSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAverageSet.ForeColor = System.Drawing.Color.DimGray;
            this.txtAverageSet.Location = new System.Drawing.Point(275, 58);
            this.txtAverageSet.Multiline = false;
            this.txtAverageSet.Name = "txtAverageSet";
            this.txtAverageSet.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtAverageSet.PasswordChar = false;
            this.txtAverageSet.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAverageSet.PlaceholderText = "";
            this.txtAverageSet.Size = new System.Drawing.Size(70, 31);
            this.txtAverageSet.TabIndex = 57;
            this.txtAverageSet.Texts = "";
            this.txtAverageSet.UnderlinedStyle = false;
            // 
            // txtSetsPlayed
            // 
            this.txtSetsPlayed.BackColor = System.Drawing.SystemColors.Window;
            this.txtSetsPlayed.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtSetsPlayed.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtSetsPlayed.BorderRadius = 0;
            this.txtSetsPlayed.BorderSize = 2;
            this.txtSetsPlayed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSetsPlayed.ForeColor = System.Drawing.Color.DimGray;
            this.txtSetsPlayed.Location = new System.Drawing.Point(275, 19);
            this.txtSetsPlayed.Multiline = false;
            this.txtSetsPlayed.Name = "txtSetsPlayed";
            this.txtSetsPlayed.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSetsPlayed.PasswordChar = false;
            this.txtSetsPlayed.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtSetsPlayed.PlaceholderText = "";
            this.txtSetsPlayed.Size = new System.Drawing.Size(70, 31);
            this.txtSetsPlayed.TabIndex = 56;
            this.txtSetsPlayed.Texts = "";
            this.txtSetsPlayed.UnderlinedStyle = false;
            // 
            // txtTeam
            // 
            this.txtTeam.BackColor = System.Drawing.SystemColors.Window;
            this.txtTeam.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtTeam.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTeam.BorderRadius = 0;
            this.txtTeam.BorderSize = 2;
            this.txtTeam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTeam.ForeColor = System.Drawing.Color.DimGray;
            this.txtTeam.Location = new System.Drawing.Point(90, 58);
            this.txtTeam.Multiline = false;
            this.txtTeam.Name = "txtTeam";
            this.txtTeam.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtTeam.PasswordChar = false;
            this.txtTeam.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtTeam.PlaceholderText = "";
            this.txtTeam.Size = new System.Drawing.Size(70, 31);
            this.txtTeam.TabIndex = 55;
            this.txtTeam.Texts = "";
            this.txtTeam.UnderlinedStyle = false;
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.SystemColors.Window;
            this.txtName.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtName.BorderRadius = 0;
            this.txtName.BorderSize = 2;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.ForeColor = System.Drawing.Color.DimGray;
            this.txtName.Location = new System.Drawing.Point(90, 17);
            this.txtName.Multiline = false;
            this.txtName.Name = "txtName";
            this.txtName.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtName.PasswordChar = false;
            this.txtName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtName.PlaceholderText = "";
            this.txtName.Size = new System.Drawing.Size(70, 31);
            this.txtName.TabIndex = 54;
            this.txtName.Texts = "";
            this.txtName.UnderlinedStyle = false;
            // 
            // newBtn
            // 
            this.newBtn.BackColor = System.Drawing.Color.White;
            this.newBtn.BackgroundColor = System.Drawing.Color.White;
            this.newBtn.BorderColor = System.Drawing.Color.Black;
            this.newBtn.BorderRadius = 15;
            this.newBtn.BorderSize = 2;
            this.newBtn.FlatAppearance.BorderSize = 0;
            this.newBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newBtn.ForeColor = System.Drawing.Color.Black;
            this.newBtn.Location = new System.Drawing.Point(243, 99);
            this.newBtn.Margin = new System.Windows.Forms.Padding(2);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(75, 32);
            this.newBtn.TabIndex = 49;
            this.newBtn.Text = "NEW";
            this.newBtn.TextColor = System.Drawing.Color.Black;
            this.newBtn.UseVisualStyleBackColor = false;
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // labelTeam
            // 
            this.labelTeam.AutoSize = true;
            this.labelTeam.BackColor = System.Drawing.Color.Transparent;
            this.labelTeam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelTeam.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTeam.ForeColor = System.Drawing.Color.White;
            this.labelTeam.Location = new System.Drawing.Point(33, 58);
            this.labelTeam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelTeam.Name = "labelTeam";
            this.labelTeam.Size = new System.Drawing.Size(52, 20);
            this.labelTeam.TabIndex = 32;
            this.labelTeam.Text = "Team:";
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.White;
            this.saveBtn.BackgroundColor = System.Drawing.Color.White;
            this.saveBtn.BorderColor = System.Drawing.Color.Black;
            this.saveBtn.BorderRadius = 15;
            this.saveBtn.BorderSize = 2;
            this.saveBtn.FlatAppearance.BorderSize = 0;
            this.saveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveBtn.ForeColor = System.Drawing.Color.Black;
            this.saveBtn.Location = new System.Drawing.Point(322, 99);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(2);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(75, 32);
            this.saveBtn.TabIndex = 50;
            this.saveBtn.Text = "SAVE";
            this.saveBtn.TextColor = System.Drawing.Color.Black;
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.White;
            this.updateBtn.BackgroundColor = System.Drawing.Color.White;
            this.updateBtn.BorderColor = System.Drawing.Color.Black;
            this.updateBtn.BorderRadius = 15;
            this.updateBtn.BorderSize = 2;
            this.updateBtn.FlatAppearance.BorderSize = 0;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateBtn.ForeColor = System.Drawing.Color.Black;
            this.updateBtn.Location = new System.Drawing.Point(401, 99);
            this.updateBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(75, 32);
            this.updateBtn.TabIndex = 52;
            this.updateBtn.Text = "UPDATE";
            this.updateBtn.TextColor = System.Drawing.Color.Black;
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.BackColor = System.Drawing.Color.Transparent;
            this.labelName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelName.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.ForeColor = System.Drawing.Color.White;
            this.labelName.Location = new System.Drawing.Point(30, 17);
            this.labelName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(55, 20);
            this.labelName.TabIndex = 51;
            this.labelName.Text = "Name:";
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.White;
            this.deleteBtn.BackgroundColor = System.Drawing.Color.White;
            this.deleteBtn.BorderColor = System.Drawing.Color.Black;
            this.deleteBtn.BorderRadius = 15;
            this.deleteBtn.BorderSize = 2;
            this.deleteBtn.FlatAppearance.BorderSize = 0;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteBtn.ForeColor = System.Drawing.Color.Black;
            this.deleteBtn.Location = new System.Drawing.Point(480, 99);
            this.deleteBtn.Margin = new System.Windows.Forms.Padding(2);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 32);
            this.deleteBtn.TabIndex = 53;
            this.deleteBtn.Text = "DELETE";
            this.deleteBtn.TextColor = System.Drawing.Color.Black;
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // labelAverageSet
            // 
            this.labelAverageSet.AutoSize = true;
            this.labelAverageSet.BackColor = System.Drawing.Color.Transparent;
            this.labelAverageSet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAverageSet.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAverageSet.ForeColor = System.Drawing.Color.White;
            this.labelAverageSet.Location = new System.Drawing.Point(173, 58);
            this.labelAverageSet.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAverageSet.Name = "labelAverageSet";
            this.labelAverageSet.Size = new System.Drawing.Size(97, 20);
            this.labelAverageSet.TabIndex = 36;
            this.labelAverageSet.Text = "Average Set:";
            // 
            // labelBlock
            // 
            this.labelBlock.AutoSize = true;
            this.labelBlock.BackColor = System.Drawing.Color.Transparent;
            this.labelBlock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBlock.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBlock.ForeColor = System.Drawing.Color.White;
            this.labelBlock.Location = new System.Drawing.Point(372, 58);
            this.labelBlock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBlock.Name = "labelBlock";
            this.labelBlock.Size = new System.Drawing.Size(54, 20);
            this.labelBlock.TabIndex = 40;
            this.labelBlock.Text = "Block:";
            // 
            // labelPoints
            // 
            this.labelPoints.AutoSize = true;
            this.labelPoints.BackColor = System.Drawing.Color.Transparent;
            this.labelPoints.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPoints.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPoints.ForeColor = System.Drawing.Color.White;
            this.labelPoints.Location = new System.Drawing.Point(367, 17);
            this.labelPoints.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPoints.Name = "labelPoints";
            this.labelPoints.Size = new System.Drawing.Size(59, 20);
            this.labelPoints.TabIndex = 38;
            this.labelPoints.Text = "Points:";
            // 
            // labelAce
            // 
            this.labelAce.AutoSize = true;
            this.labelAce.BackColor = System.Drawing.Color.Transparent;
            this.labelAce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAce.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAce.ForeColor = System.Drawing.Color.White;
            this.labelAce.Location = new System.Drawing.Point(524, 17);
            this.labelAce.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAce.Name = "labelAce";
            this.labelAce.Size = new System.Drawing.Size(40, 20);
            this.labelAce.TabIndex = 42;
            this.labelAce.Text = "Ace:";
            // 
            // labelDig
            // 
            this.labelDig.AutoSize = true;
            this.labelDig.BackColor = System.Drawing.Color.Transparent;
            this.labelDig.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelDig.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDig.ForeColor = System.Drawing.Color.White;
            this.labelDig.Location = new System.Drawing.Point(527, 58);
            this.labelDig.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelDig.Name = "labelDig";
            this.labelDig.Size = new System.Drawing.Size(37, 20);
            this.labelDig.TabIndex = 43;
            this.labelDig.Text = "Dig:";
            // 
            // labelSetsPlayed
            // 
            this.labelSetsPlayed.AutoSize = true;
            this.labelSetsPlayed.BackColor = System.Drawing.Color.Transparent;
            this.labelSetsPlayed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelSetsPlayed.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSetsPlayed.ForeColor = System.Drawing.Color.White;
            this.labelSetsPlayed.Location = new System.Drawing.Point(175, 17);
            this.labelSetsPlayed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSetsPlayed.Name = "labelSetsPlayed";
            this.labelSetsPlayed.Size = new System.Drawing.Size(95, 20);
            this.labelSetsPlayed.TabIndex = 35;
            this.labelSetsPlayed.Text = "Sets Played:";
            // 
            // panelTable
            // 
            this.panelTable.Controls.Add(this.dataGridView1);
            this.panelTable.Controls.Add(this.PanelCommands);
            this.panelTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTable.ForeColor = System.Drawing.Color.White;
            this.panelTable.Location = new System.Drawing.Point(3, 3);
            this.panelTable.Name = "panelTable";
            this.panelTable.Size = new System.Drawing.Size(786, 416);
            this.panelTable.TabIndex = 57;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(0, 170);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.Size = new System.Drawing.Size(786, 246);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tabControlVolleyball
            // 
            this.tabControlVolleyball.Controls.Add(this.tabPage1);
            this.tabControlVolleyball.Controls.Add(this.tabPage2);
            this.tabControlVolleyball.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlVolleyball.Font = new System.Drawing.Font("Cambria", 9.75F);
            this.tabControlVolleyball.Location = new System.Drawing.Point(0, 0);
            this.tabControlVolleyball.Name = "tabControlVolleyball";
            this.tabControlVolleyball.SelectedIndex = 0;
            this.tabControlVolleyball.Size = new System.Drawing.Size(800, 450);
            this.tabControlVolleyball.TabIndex = 58;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.tabPage1.Controls.Add(this.panelTable);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 422);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Player Statistics";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.tabPage2.Controls.Add(this.panelInfoTable);
            this.tabPage2.Controls.Add(this.panelInfoCommands);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 422);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Player Information";
            // 
            // panelInfoTable
            // 
            this.panelInfoTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.panelInfoTable.Controls.Add(this.dataGridView2);
            this.panelInfoTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInfoTable.Location = new System.Drawing.Point(3, 273);
            this.panelInfoTable.Name = "panelInfoTable";
            this.panelInfoTable.Size = new System.Drawing.Size(786, 146);
            this.panelInfoTable.TabIndex = 61;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.White;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Cambria", 9.75F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView2.Size = new System.Drawing.Size(786, 146);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // panelInfoCommands
            // 
            this.panelInfoCommands.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.panelInfoCommands.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelInfoCommands.Controls.Add(this.labelWeight);
            this.panelInfoCommands.Controls.Add(this.txtWeight);
            this.panelInfoCommands.Controls.Add(this.labelHeight);
            this.panelInfoCommands.Controls.Add(this.txtHeight);
            this.panelInfoCommands.Controls.Add(this.labelJerseyNumber);
            this.panelInfoCommands.Controls.Add(this.txtJerseyNumber);
            this.panelInfoCommands.Controls.Add(this.labelPosition);
            this.panelInfoCommands.Controls.Add(this.txtPosition);
            this.panelInfoCommands.Controls.Add(this.txtAge);
            this.panelInfoCommands.Controls.Add(this.labelAge);
            this.panelInfoCommands.Controls.Add(this.labelPlayerTeam);
            this.panelInfoCommands.Controls.Add(this.labelBirthdate);
            this.panelInfoCommands.Controls.Add(this.labelPlayerName);
            this.panelInfoCommands.Controls.Add(this.btnBrowse);
            this.panelInfoCommands.Controls.Add(this.pictureBox1);
            this.panelInfoCommands.Controls.Add(this.txtSearchPlayer);
            this.panelInfoCommands.Controls.Add(this.txtPlayerTeam);
            this.panelInfoCommands.Controls.Add(this.txtBirthdate);
            this.panelInfoCommands.Controls.Add(this.txtPlayerName);
            this.panelInfoCommands.Controls.Add(this.btnNew);
            this.panelInfoCommands.Controls.Add(this.btnSave);
            this.panelInfoCommands.Controls.Add(this.btnUpdate);
            this.panelInfoCommands.Controls.Add(this.btnDelete);
            this.panelInfoCommands.Controls.Add(this.btnSearchPlayer);
            this.panelInfoCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelInfoCommands.Location = new System.Drawing.Point(3, 3);
            this.panelInfoCommands.Name = "panelInfoCommands";
            this.panelInfoCommands.Size = new System.Drawing.Size(786, 270);
            this.panelInfoCommands.TabIndex = 60;
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.BackColor = System.Drawing.Color.Transparent;
            this.labelWeight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelWeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelWeight.ForeColor = System.Drawing.Color.White;
            this.labelWeight.Location = new System.Drawing.Point(506, 75);
            this.labelWeight.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(60, 20);
            this.labelWeight.TabIndex = 78;
            this.labelWeight.Text = "Weight";
            // 
            // txtWeight
            // 
            this.txtWeight.BackColor = System.Drawing.SystemColors.Window;
            this.txtWeight.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtWeight.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtWeight.BorderRadius = 0;
            this.txtWeight.BorderSize = 2;
            this.txtWeight.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeight.ForeColor = System.Drawing.Color.DimGray;
            this.txtWeight.Location = new System.Drawing.Point(510, 98);
            this.txtWeight.Multiline = false;
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtWeight.PasswordChar = false;
            this.txtWeight.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtWeight.PlaceholderText = "";
            this.txtWeight.Size = new System.Drawing.Size(100, 30);
            this.txtWeight.TabIndex = 77;
            this.txtWeight.Texts = "";
            this.txtWeight.UnderlinedStyle = false;
            // 
            // labelHeight
            // 
            this.labelHeight.AutoSize = true;
            this.labelHeight.BackColor = System.Drawing.Color.Transparent;
            this.labelHeight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelHeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelHeight.ForeColor = System.Drawing.Color.White;
            this.labelHeight.Location = new System.Drawing.Point(627, 75);
            this.labelHeight.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelHeight.Name = "labelHeight";
            this.labelHeight.Size = new System.Drawing.Size(57, 20);
            this.labelHeight.TabIndex = 76;
            this.labelHeight.Text = "Height";
            // 
            // txtHeight
            // 
            this.txtHeight.BackColor = System.Drawing.SystemColors.Window;
            this.txtHeight.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtHeight.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtHeight.BorderRadius = 0;
            this.txtHeight.BorderSize = 2;
            this.txtHeight.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHeight.ForeColor = System.Drawing.Color.DimGray;
            this.txtHeight.Location = new System.Drawing.Point(631, 99);
            this.txtHeight.Multiline = false;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtHeight.PasswordChar = false;
            this.txtHeight.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtHeight.PlaceholderText = "";
            this.txtHeight.Size = new System.Drawing.Size(100, 30);
            this.txtHeight.TabIndex = 75;
            this.txtHeight.Texts = "";
            this.txtHeight.UnderlinedStyle = false;
            // 
            // labelJerseyNumber
            // 
            this.labelJerseyNumber.AutoSize = true;
            this.labelJerseyNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelJerseyNumber.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelJerseyNumber.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelJerseyNumber.ForeColor = System.Drawing.Color.White;
            this.labelJerseyNumber.Location = new System.Drawing.Point(261, 75);
            this.labelJerseyNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelJerseyNumber.Name = "labelJerseyNumber";
            this.labelJerseyNumber.Size = new System.Drawing.Size(120, 20);
            this.labelJerseyNumber.TabIndex = 74;
            this.labelJerseyNumber.Text = "Jersey Number:";
            // 
            // txtJerseyNumber
            // 
            this.txtJerseyNumber.BackColor = System.Drawing.SystemColors.Window;
            this.txtJerseyNumber.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtJerseyNumber.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtJerseyNumber.BorderRadius = 0;
            this.txtJerseyNumber.BorderSize = 2;
            this.txtJerseyNumber.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJerseyNumber.ForeColor = System.Drawing.Color.DimGray;
            this.txtJerseyNumber.Location = new System.Drawing.Point(268, 99);
            this.txtJerseyNumber.Multiline = false;
            this.txtJerseyNumber.Name = "txtJerseyNumber";
            this.txtJerseyNumber.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtJerseyNumber.PasswordChar = false;
            this.txtJerseyNumber.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtJerseyNumber.PlaceholderText = "";
            this.txtJerseyNumber.Size = new System.Drawing.Size(100, 30);
            this.txtJerseyNumber.TabIndex = 73;
            this.txtJerseyNumber.Texts = "";
            this.txtJerseyNumber.UnderlinedStyle = false;
            // 
            // labelPosition
            // 
            this.labelPosition.AutoSize = true;
            this.labelPosition.BackColor = System.Drawing.Color.Transparent;
            this.labelPosition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPosition.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPosition.ForeColor = System.Drawing.Color.White;
            this.labelPosition.Location = new System.Drawing.Point(506, 8);
            this.labelPosition.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPosition.Name = "labelPosition";
            this.labelPosition.Size = new System.Drawing.Size(73, 20);
            this.labelPosition.TabIndex = 72;
            this.labelPosition.Text = "Position:";
            // 
            // txtPosition
            // 
            this.txtPosition.BackColor = System.Drawing.SystemColors.Window;
            this.txtPosition.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPosition.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPosition.BorderRadius = 0;
            this.txtPosition.BorderSize = 2;
            this.txtPosition.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPosition.ForeColor = System.Drawing.Color.DimGray;
            this.txtPosition.Location = new System.Drawing.Point(510, 31);
            this.txtPosition.Multiline = false;
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPosition.PasswordChar = false;
            this.txtPosition.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPosition.PlaceholderText = "";
            this.txtPosition.Size = new System.Drawing.Size(100, 30);
            this.txtPosition.TabIndex = 71;
            this.txtPosition.Texts = "";
            this.txtPosition.UnderlinedStyle = false;
            // 
            // txtAge
            // 
            this.txtAge.BackColor = System.Drawing.SystemColors.Window;
            this.txtAge.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtAge.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtAge.BorderRadius = 0;
            this.txtAge.BorderSize = 2;
            this.txtAge.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAge.ForeColor = System.Drawing.Color.DimGray;
            this.txtAge.Location = new System.Drawing.Point(389, 99);
            this.txtAge.Multiline = false;
            this.txtAge.Name = "txtAge";
            this.txtAge.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtAge.PasswordChar = false;
            this.txtAge.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtAge.PlaceholderText = "";
            this.txtAge.Size = new System.Drawing.Size(100, 30);
            this.txtAge.TabIndex = 70;
            this.txtAge.Texts = "";
            this.txtAge.UnderlinedStyle = false;
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.BackColor = System.Drawing.Color.Transparent;
            this.labelAge.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelAge.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelAge.ForeColor = System.Drawing.Color.White;
            this.labelAge.Location = new System.Drawing.Point(385, 75);
            this.labelAge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(40, 20);
            this.labelAge.TabIndex = 69;
            this.labelAge.Text = "Age:";
            // 
            // labelPlayerTeam
            // 
            this.labelPlayerTeam.AutoSize = true;
            this.labelPlayerTeam.BackColor = System.Drawing.Color.Transparent;
            this.labelPlayerTeam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPlayerTeam.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPlayerTeam.ForeColor = System.Drawing.Color.White;
            this.labelPlayerTeam.Location = new System.Drawing.Point(385, 8);
            this.labelPlayerTeam.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPlayerTeam.Name = "labelPlayerTeam";
            this.labelPlayerTeam.Size = new System.Drawing.Size(52, 20);
            this.labelPlayerTeam.TabIndex = 68;
            this.labelPlayerTeam.Text = "Team:";
            // 
            // labelBirthdate
            // 
            this.labelBirthdate.AutoSize = true;
            this.labelBirthdate.BackColor = System.Drawing.Color.Transparent;
            this.labelBirthdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelBirthdate.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelBirthdate.ForeColor = System.Drawing.Color.White;
            this.labelBirthdate.Location = new System.Drawing.Point(627, 8);
            this.labelBirthdate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelBirthdate.Name = "labelBirthdate";
            this.labelBirthdate.Size = new System.Drawing.Size(81, 20);
            this.labelBirthdate.TabIndex = 67;
            this.labelBirthdate.Text = "Birthdate:";
            // 
            // labelPlayerName
            // 
            this.labelPlayerName.AutoSize = true;
            this.labelPlayerName.BackColor = System.Drawing.Color.Transparent;
            this.labelPlayerName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPlayerName.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPlayerName.ForeColor = System.Drawing.Color.White;
            this.labelPlayerName.Location = new System.Drawing.Point(264, 8);
            this.labelPlayerName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelPlayerName.Name = "labelPlayerName";
            this.labelPlayerName.Size = new System.Drawing.Size(55, 20);
            this.labelPlayerName.TabIndex = 66;
            this.labelPlayerName.Text = "Name:";
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.White;
            this.btnBrowse.BackgroundColor = System.Drawing.Color.White;
            this.btnBrowse.BorderColor = System.Drawing.Color.Black;
            this.btnBrowse.BorderRadius = 15;
            this.btnBrowse.BorderSize = 2;
            this.btnBrowse.FlatAppearance.BorderSize = 0;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowse.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.ForeColor = System.Drawing.Color.Black;
            this.btnBrowse.Location = new System.Drawing.Point(12, 193);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(220, 30);
            this.btnBrowse.TabIndex = 61;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.TextColor = System.Drawing.Color.Black;
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(12, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(220, 184);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 60;
            this.pictureBox1.TabStop = false;
            // 
            // txtSearchPlayer
            // 
            this.txtSearchPlayer.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearchPlayer.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtSearchPlayer.BorderFocusColor = System.Drawing.SystemColors.Highlight;
            this.txtSearchPlayer.BorderRadius = 15;
            this.txtSearchPlayer.BorderSize = 2;
            this.txtSearchPlayer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtSearchPlayer.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchPlayer.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearchPlayer.Location = new System.Drawing.Point(0, 238);
            this.txtSearchPlayer.Multiline = false;
            this.txtSearchPlayer.Name = "txtSearchPlayer";
            this.txtSearchPlayer.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSearchPlayer.PasswordChar = false;
            this.txtSearchPlayer.PlaceholderColor = System.Drawing.Color.Black;
            this.txtSearchPlayer.PlaceholderText = "Search Player Name";
            this.txtSearchPlayer.Size = new System.Drawing.Size(784, 30);
            this.txtSearchPlayer.TabIndex = 58;
            this.txtSearchPlayer.Texts = "";
            this.txtSearchPlayer.UnderlinedStyle = false;
            this.txtSearchPlayer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearchPlayer_KeyDown);
            // 
            // txtPlayerTeam
            // 
            this.txtPlayerTeam.BackColor = System.Drawing.SystemColors.Window;
            this.txtPlayerTeam.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPlayerTeam.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPlayerTeam.BorderRadius = 0;
            this.txtPlayerTeam.BorderSize = 2;
            this.txtPlayerTeam.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlayerTeam.ForeColor = System.Drawing.Color.DimGray;
            this.txtPlayerTeam.Location = new System.Drawing.Point(389, 31);
            this.txtPlayerTeam.Multiline = false;
            this.txtPlayerTeam.Name = "txtPlayerTeam";
            this.txtPlayerTeam.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPlayerTeam.PasswordChar = false;
            this.txtPlayerTeam.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPlayerTeam.PlaceholderText = "";
            this.txtPlayerTeam.Size = new System.Drawing.Size(100, 30);
            this.txtPlayerTeam.TabIndex = 57;
            this.txtPlayerTeam.Texts = "";
            this.txtPlayerTeam.UnderlinedStyle = false;
            // 
            // txtBirthdate
            // 
            this.txtBirthdate.BackColor = System.Drawing.SystemColors.Window;
            this.txtBirthdate.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtBirthdate.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtBirthdate.BorderRadius = 0;
            this.txtBirthdate.BorderSize = 2;
            this.txtBirthdate.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBirthdate.ForeColor = System.Drawing.Color.DimGray;
            this.txtBirthdate.Location = new System.Drawing.Point(631, 31);
            this.txtBirthdate.Multiline = false;
            this.txtBirthdate.Name = "txtBirthdate";
            this.txtBirthdate.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtBirthdate.PasswordChar = false;
            this.txtBirthdate.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtBirthdate.PlaceholderText = "";
            this.txtBirthdate.Size = new System.Drawing.Size(100, 30);
            this.txtBirthdate.TabIndex = 55;
            this.txtBirthdate.Texts = "";
            this.txtBirthdate.UnderlinedStyle = false;
            // 
            // txtPlayerName
            // 
            this.txtPlayerName.BackColor = System.Drawing.SystemColors.Window;
            this.txtPlayerName.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtPlayerName.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtPlayerName.BorderRadius = 0;
            this.txtPlayerName.BorderSize = 2;
            this.txtPlayerName.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPlayerName.ForeColor = System.Drawing.Color.DimGray;
            this.txtPlayerName.Location = new System.Drawing.Point(268, 31);
            this.txtPlayerName.Multiline = false;
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPlayerName.PasswordChar = false;
            this.txtPlayerName.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtPlayerName.PlaceholderText = "";
            this.txtPlayerName.Size = new System.Drawing.Size(100, 30);
            this.txtPlayerName.TabIndex = 54;
            this.txtPlayerName.Texts = "";
            this.txtPlayerName.UnderlinedStyle = false;
            // 
            // btnNew
            // 
            this.btnNew.BackColor = System.Drawing.Color.White;
            this.btnNew.BackgroundColor = System.Drawing.Color.White;
            this.btnNew.BorderColor = System.Drawing.Color.Black;
            this.btnNew.BorderRadius = 15;
            this.btnNew.BorderSize = 2;
            this.btnNew.FlatAppearance.BorderSize = 0;
            this.btnNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNew.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.ForeColor = System.Drawing.Color.Black;
            this.btnNew.Location = new System.Drawing.Point(335, 164);
            this.btnNew.Margin = new System.Windows.Forms.Padding(2);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 32);
            this.btnNew.TabIndex = 49;
            this.btnNew.Text = "NEW";
            this.btnNew.TextColor = System.Drawing.Color.Black;
            this.btnNew.UseVisualStyleBackColor = false;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.BackgroundColor = System.Drawing.Color.White;
            this.btnSave.BorderColor = System.Drawing.Color.Black;
            this.btnSave.BorderRadius = 15;
            this.btnSave.BorderSize = 2;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.Black;
            this.btnSave.Location = new System.Drawing.Point(414, 164);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 32);
            this.btnSave.TabIndex = 50;
            this.btnSave.Text = "SAVE";
            this.btnSave.TextColor = System.Drawing.Color.Black;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.White;
            this.btnUpdate.BackgroundColor = System.Drawing.Color.White;
            this.btnUpdate.BorderColor = System.Drawing.Color.Black;
            this.btnUpdate.BorderRadius = 15;
            this.btnUpdate.BorderSize = 2;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.Black;
            this.btnUpdate.Location = new System.Drawing.Point(510, 164);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 32);
            this.btnUpdate.TabIndex = 52;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.TextColor = System.Drawing.Color.Black;
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.BackgroundColor = System.Drawing.Color.White;
            this.btnDelete.BorderColor = System.Drawing.Color.Black;
            this.btnDelete.BorderRadius = 15;
            this.btnDelete.BorderSize = 2;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Location = new System.Drawing.Point(587, 164);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 32);
            this.btnDelete.TabIndex = 53;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.TextColor = System.Drawing.Color.Black;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSearchPlayer
            // 
            this.btnSearchPlayer.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchPlayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearchPlayer.FlatAppearance.BorderSize = 0;
            this.btnSearchPlayer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchPlayer.Location = new System.Drawing.Point(693, 169);
            this.btnSearchPlayer.Name = "btnSearchPlayer";
            this.btnSearchPlayer.Size = new System.Drawing.Size(75, 23);
            this.btnSearchPlayer.TabIndex = 59;
            this.btnSearchPlayer.UseVisualStyleBackColor = false;
            this.btnSearchPlayer.Visible = false;
            this.btnSearchPlayer.Click += new System.EventHandler(this.btnSearchPlayer_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FormVB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControlVolleyball);
            this.Name = "FormVB";
            this.Text = "FormVB";
            this.Load += new System.EventHandler(this.FormVB_Load);
            this.PanelCommands.ResumeLayout(false);
            this.PanelCommands.PerformLayout();
            this.panelTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControlVolleyball.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panelInfoTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panelInfoCommands.ResumeLayout(false);
            this.panelInfoCommands.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelCommands;
        private AthleteDataSystem.CustomTools.CurveTextbox txtDig;
        private AthleteDataSystem.CustomTools.CurveTextbox txtAce;
        private AthleteDataSystem.CustomTools.CurveTextbox txtBlockPerGame;
        private AthleteDataSystem.CustomTools.CurveTextbox txtPointsPerGame;
        private AthleteDataSystem.CustomTools.CurveTextbox txtAverageSet;
        private AthleteDataSystem.CustomTools.CurveTextbox txtSetsPlayed;
        private AthleteDataSystem.CustomTools.CurveTextbox txtTeam;
        private AthleteDataSystem.CustomTools.CurveTextbox txtName;
        private CustomTools.CurvedButton newBtn;
        private CustomTools.CurvedButton saveBtn;
        private CustomTools.CurvedButton updateBtn;
        private CustomTools.CurvedButton deleteBtn;
        private AthleteDataSystem.CustomTools.CurveTextbox txtReceive;
        private System.Windows.Forms.Panel panelTable;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelReceive;
        private System.Windows.Forms.Label labelTeam;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelAverageSet;
        private System.Windows.Forms.Label labelBlock;
        private System.Windows.Forms.Label labelPoints;
        private System.Windows.Forms.Label labelAce;
        private System.Windows.Forms.Label labelDig;
        private System.Windows.Forms.Label labelSetsPlayed;
        private AthleteDataSystem.CustomTools.CurveTextbox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TabControl tabControlVolleyball;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panelInfoCommands;
        private System.Windows.Forms.Label labelWeight;
        private AthleteDataSystem.CustomTools.CurveTextbox txtWeight;
        private System.Windows.Forms.Label labelHeight;
        private AthleteDataSystem.CustomTools.CurveTextbox txtHeight;
        private System.Windows.Forms.Label labelJerseyNumber;
        private AthleteDataSystem.CustomTools.CurveTextbox txtJerseyNumber;
        private System.Windows.Forms.Label labelPosition;
        private AthleteDataSystem.CustomTools.CurveTextbox txtPosition;
        private AthleteDataSystem.CustomTools.CurveTextbox txtAge;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelPlayerTeam;
        private System.Windows.Forms.Label labelBirthdate;
        private System.Windows.Forms.Label labelPlayerName;
        private CustomTools.CurvedButton btnBrowse;
        private System.Windows.Forms.PictureBox pictureBox1;
        private AthleteDataSystem.CustomTools.CurveTextbox txtSearchPlayer;
        private AthleteDataSystem.CustomTools.CurveTextbox txtPlayerTeam;
        private AthleteDataSystem.CustomTools.CurveTextbox txtBirthdate;
        private AthleteDataSystem.CustomTools.CurveTextbox txtPlayerName;
        private CustomTools.CurvedButton btnNew;
        private CustomTools.CurvedButton btnSave;
        private CustomTools.CurvedButton btnUpdate;
        private CustomTools.CurvedButton btnDelete;
        private System.Windows.Forms.Button btnSearchPlayer;
        private System.Windows.Forms.Panel panelInfoTable;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}