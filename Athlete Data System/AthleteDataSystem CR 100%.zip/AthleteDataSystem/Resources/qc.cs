﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AthleteDataSystem.Resources
{
    internal class qc
    {
        /* Connection
                public static OleDbConnection conn;
                public static string dbconnect = "Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " + Application.StartupPath + "\\ADS.accdb";

                public static void DB()
                {
                    try
                    {
                        conn = new OleDbConnection(dbconnect);
                        conn.Open();
                    }
                    catch (Exception ex)
                    {
                        conn.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
        */


        /* DBHelper
                public static string gen = "";
                public static OleDbCommand command;
                public static OleDbDataReader reader;

                public static void fill(string q, DataGridView dgv)
                {
                    try
                    {
                        Connection.Connection.DB();
                        DataTable dt = new DataTable();
                        OleDbDataAdapter data = null;
                        OleDbCommand command = new OleDbCommand(q,
                        Connection.Connection.conn);
                        data = new OleDbDataAdapter(command);
                        data.Fill(dt);
                        dgv.DataSource = dt;
                        Connection.Connection.conn.Close();
                    }
                    catch (Exception ex)
                    {
                        Connection.Connection.conn.Close();
                        MessageBox.Show(ex.Message);
                    }
                }

                public static void ModifyRecord(string query)
                {
                    try
                    {
                        Connection.Connection.DB();
                        OleDbCommand command = new OleDbCommand(query, Connection.Connection.conn);
                        command.ExecuteNonQuery();
                        Connection.Connection.conn.Close();
                    }
                    catch (Exception ex)
                    {
                        Connection.Connection.conn.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
         */

        /* Login
                private void loginBtn_Click(object sender, EventArgs e)
                {
                    try
                    {
                        Connection.Connection.DB();
                        DBHelper.DBHelper.gen = "Select * from accounts where [username] = '" + txtusername.Texts + "' and [password] = '" + txtpassword.Texts + "'";
                        DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                        DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                        if (DBHelper.DBHelper.reader.HasRows)
                        {
                            DBHelper.DBHelper.reader.Read();
                            userId = Convert.ToInt32(DBHelper.DBHelper.reader["ID"]);
                            username = DBHelper.DBHelper.reader["username"].ToString();
                            password = DBHelper.DBHelper.reader["password"].ToString();
                            fullname = DBHelper.DBHelper.reader["fullname"].ToString();
                            email = DBHelper.DBHelper.reader["email"].ToString();
                            imageBytes = (byte[])DBHelper.DBHelper.reader["ProfilePicture"];

                            Image playerImage = null;

                            if (imageBytes != null && imageBytes.Length > 0)
                            {
                                playerImage = ConvertToImage(imageBytes);
                            }

                            timer1.Enabled = true;
                            timer1.Interval = 5;
                            progressBar1.Maximum = 100;
                            progressBar1.Value = 0;
                            timer1.Start();
                        }
                        else
                        {
                            MessageBox.Show("Invalid Username and Password");
                        }

                        Connection.Connection.conn.Close();
                    }
                    catch (Exception ex)
                    {
                        Connection.Connection.conn.Close();
                        MessageBox.Show(ex.Message);
                    }
                }
        */


        /*
                Accounts sql
                string sql = "INSERT INTO accounts (username, [password], fullName, Email, ProfilePicture) VALUES ('" + txtUsername.Texts + "', '" + txtPassword.Texts + "', '" + txtFullName.Texts + "', '" + txtEmail.Texts + "', @ProfilePicture)";
                string sql = "UPDATE accounts SET username = '" + txtUsername.Texts + "', " + "[password] = '" + txtPassword.Texts + "', " + "fullName = '" + txtFullName.Texts + "', Email = '" + txtEmail.Texts + "', ProfilePicture = @ProfilePicture WHERE ID = " + selectedRow["ID"];
                
                BPS sql
                string sql = "INSERT INTO basketballPlayers (PlayerName, Team, GamesPlayed, Points, Rebounds, Assists, Steals, Blocks, FGA, FGM, FTA, FTM, Turnovers) " + "VALUES (" + "'" + txtName.Texts + "', " + "'" + txtTeam.Texts + "', " + int.Parse(txtGamesPlayed.Texts) + ", " + double.Parse(txtPoints.Texts) + ", " + double.Parse(txtRebounds.Texts) + ", " + double.Parse(txtAssist.Texts) + ", " + double.Parse(txtSteals.Texts) + "," + double.Parse(txtBlocks.Texts) + "," + double.Parse(txtFGA.Texts) + ", " + double.Parse(txtFGM.Texts) + ", " + double.Parse(txtFTA.Texts) + ", " + double.Parse(txtFTM.Texts) + ", " + double.Parse(txtTurnovers.Texts) +  ")";
                string sql = "UPDATE basketballPlayers SET " + "PlayerName = '" + txtName.Texts + "', " + "Team = '" + txtTeam.Texts + "', " + "GamesPlayed = " + int.Parse(txtGamesPlayed.Texts) + ", " + "Points = " + double.Parse(txtPoints.Texts) + ", " + "Rebounds = " + double.Parse(txtRebounds.Texts) + ", " + "Assists = " + double.Parse(txtAssist.Texts) + ", " + "Steals = " + double.Parse(txtSteals.Texts) + ", " + "Blocks = " + double.Parse(txtBlocks.Texts) + ", " + "FGA = " + double.Parse(txtFGA.Texts) + ", " + "FGM = " + double.Parse(txtFGM.Texts) + ", " + "FTA = " + double.Parse(txtFTA.Texts) + ", " + "FTM = " + double.Parse(txtFTM.Texts)  + ", " + "Turnovers = " + double.Parse(txtTurnovers.Texts) + " WHERE PlayerID = " + selectedRow["PlayerID"];
                
                BPI sql
                string sql = "INSERT INTO basketballPlayersInfo (PlayerName, Team, [Position], Birthdate, JerseyNumber, Age, Weight, Height, PlayerProfile) " + "VALUES ('" + txtPlayerName.Texts + "', '" + txtPlayerTeam.Texts + "', '" + txtPosition.Texts + "', '" + txtBirthdate.Texts + "', " + int.Parse(txtJerseyNumber.Texts) + ", " + int.Parse(txtAge.Texts) + ", " + int.Parse(txtWeight.Texts) + ", " + double.Parse(txtHeight.Texts) + ", @PlayerProfile)";
                string sql = "UPDATE basketballPlayersInfo SET PlayerName = '" + txtPlayerName.Texts + "', Team = '" + txtPlayerTeam.Texts + "', [Position] = '" + txtPosition.Texts + "', Birthdate = '" + txtBirthdate.Texts + "', JerseyNumber = " + int.Parse(txtJerseyNumber.Texts) + ", Age = " + int.Parse(txtAge.Texts) + ", Weight = " + int.Parse(txtWeight.Texts) + ", Height = " + double.Parse(txtHeight.Texts) + ", PlayerProfile = @PlayerProfile WHERE PlayerID = " + selectedRow["PlayerID"];
                
                Games sql
                string sql = "INSERT INTO games (TeamMatchup, Games, GameDateTime) " + "VALUES (" + "'" + txtTeamMatchup.Texts + "', " + "'" + txtGames.Texts + "', " + "'" + txtDate.Value.ToString("yyyy-MM-dd HH:mm:ss") + "'" + ")";
                string sql = "UPDATE games SET " + "TeamMatchup = '" + txtTeamMatchup.Texts + "', " + "Games = '" + txtGames.Texts + "', " + "GameDateTime = '" + txtDate.Value.ToString("yyyy-MM-dd HH:mm:ss") + "' " + "WHERE MatchID = " + selectedRow["MatchID"];
                
                VPS sql
                string sql = "INSERT INTO volleyballPlayers (PlayersName, Team, SetsPlayed, AverageSets, Points, Block, Ace, Dig, Receive) " + "VALUES (" + "'" + txtName.Texts + "', " + "'" + txtTeam.Texts + "', " + int.Parse(txtSetsPlayed.Texts) + ", " + double.Parse(txtAverageSet.Texts) + ", " + int.Parse(txtPointsPerGame.Texts) + ", " + int.Parse(txtBlockPerGame.Texts) + ", " + int.Parse(txtAce.Texts) + ", " + int.Parse(txtDig.Texts) + ", " + int.Parse(txtReceive.Texts) + ")";
                string sql = "UPDATE volleyballPlayers SET " + "PlayersName = '" + txtName.Texts + "', " + "Team = '" + txtTeam.Texts + "', " + "SetsPlayed = " + int.Parse(txtSetsPlayed.Texts) + ", " + "AverageSets = " + double.Parse(txtAverageSet.Texts) + ", " + "Points = " + int.Parse(txtPointsPerGame.Texts) + ", " + "Block = " + int.Parse(txtBlockPerGame.Texts) + ", " + "Ace = " + int.Parse(txtAce.Texts) + ", " + "Dig = " + int.Parse(txtDig.Texts) + ", " + "Receive = "+ int.Parse(txtReceive.Texts)  + " WHERE PlayerID = " + selectedRow["PlayerID"];
                
                VPI sql
                string sql = "INSERT INTO volleyballPlayersInfo (PlayerName, Team, [Position], Birthdate, JerseyNumber, Age, Weight, Height, PlayerProfile) " + "VALUES ('" + txtPlayerName.Texts + "', '" + txtPlayerTeam.Texts + "', '" + txtPosition.Texts + "', '" + txtBirthdate.Texts + "', " + int.Parse(txtJerseyNumber.Texts) + ", " + int.Parse(txtAge.Texts) + ", " + int.Parse(txtWeight.Texts) + ", " + double.Parse(txtHeight.Texts) + ", @PlayerProfile)";
                string sql = "UPDATE volleyballPlayersInfo SET PlayerName = '" + txtPlayerName.Texts + "', Team = '" + txtPlayerTeam.Texts + "', [Position] = '" + txtPosition.Texts + "', Birthdate = '" + txtBirthdate.Texts + "', JerseyNumber = " + int.Parse(txtJerseyNumber.Texts) + ", Age = " + int.Parse(txtAge.Texts) + ", Weight = " + int.Parse(txtWeight.Texts) + ", Height = " + double.Parse(txtHeight.Texts) + ", PlayerProfile = @PlayerProfile WHERE PlayerID = " + selectedRow["PlayerID"];
                
         */
    }
}
