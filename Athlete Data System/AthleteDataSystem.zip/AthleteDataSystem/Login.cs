﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.IO;
using AthleteDataSystem.DBHelper;

namespace AthleteDataSystem
{
    public partial class Login : Form
    {
        //Fields
        private int userId;
        private string username;
        private string password;
        private string fullname;
        private string email;
        private byte[] imageBytes;

        //Constructor
        public Login()
        {
            InitializeComponent();
            timer1.Tick += new EventHandler(timer1_Tick);
        }

        #region -> Buttons
        //Login Button
        private void loginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select * from accounts where [username] = '" + txtusername.Texts + "' and [password] = '" + txtpassword.Texts + "'";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                    userId = Convert.ToInt32(DBHelper.DBHelper.reader["ID"]);
                    username = DBHelper.DBHelper.reader["username"].ToString();
                    password = DBHelper.DBHelper.reader["password"].ToString();
                    fullname = DBHelper.DBHelper.reader["fullname"].ToString();
                    email = DBHelper.DBHelper.reader["email"].ToString();
                    imageBytes = (byte[])DBHelper.DBHelper.reader["ProfilePicture"];

                    Image playerImage = null;

                    if (imageBytes != null && imageBytes.Length > 0)
                    {
                        playerImage = ConvertToImage(imageBytes);
                    }

                    timer1.Enabled = true;
                    timer1.Interval = 5;
                    progressBar1.Maximum = 100;
                    progressBar1.Value = 0;
                    timer1.Start();
                }
                else
                {
                    MessageBox.Show("Invalid Username and Password");
                }

                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        //Create Account Button
        private void createAccountBtn_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the Players form
            CreateAccount createAccountForm = new CreateAccount();
            createAccountForm.Show();
        }

        //View Button
        private void btnViewPassword_Click(object sender, EventArgs e)
        {
            txtpassword.PasswordChar = !txtpassword.PasswordChar;
        }

        //Keydown
        private void txtpassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                loginBtn_Click(sender, e);
            }
        }
        #endregion

        // Timer Properties Method
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < progressBar1.Maximum)
            {
                progressBar1.Value ++;
            }
            else
            {
                timer1.Stop();
                progressBar1.Value = 0;

                if (username == "admin")
                {
                    // Redirect to adminDashboard
                    this.Hide();
                    adminDashboard adminForm = new adminDashboard();
                    adminForm.Show();
                }
                else
                {
                    // Redirect to userDashboard
                    this.Hide();
                    userDashboard userForm = new userDashboard(userId, username, password, fullname, email, imageBytes);
                    userForm.Show();
                }
            }
        }

        //Convert bytes to image
        private Image ConvertToImage(byte[] imageBytes)
        {
            using (MemoryStream ms = new MemoryStream(imageBytes))
            {
                return Image.FromStream(ms);
            }
        }

        //Close form
        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application
        }
    }
}

























































//DBHelper.DBHelper.gen = "Select * from accounts where [username] = '" + txtusername.Texts + "' and [password] = '" + txtpassword.Texts + "'";
