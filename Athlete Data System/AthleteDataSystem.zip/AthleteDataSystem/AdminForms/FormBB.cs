﻿using AthleteDataSystem.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormBB : Form
    {

        //Constructor
        public FormBB()
        {
            InitializeComponent();
            LoadBasketballPlayers();
            LoadBasketballPlayersInformation();
        }

        //Load Table
        private void LoadBasketballPlayers()
        {
            try
            {
                string query = "SELECT * FROM basketballPlayers";
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch
            { }
        }
        private void LoadBasketballPlayersInformation()
        {
            try
            {
                string query = "SELECT * FROM basketballPlayersInfo";
                DBHelper.DBHelper.fill(query, dataGridView2);
            }
            catch
            { }
        }

        //Clear Text Fields
        private void ClearFields()
        {
            //Table 1
            txtName.Texts = "";
            txtTeam.Texts = "";
            txtGamesPlayed.Texts = "";
            txtPoints.Texts = "";
            txtRebounds.Texts = "";
            txtAssist.Texts = "";
            txtSteals.Texts = "";
            txtBlocks.Texts = "";
            txtFGA.Texts = "";
            txtFGM.Texts = "";
            txtFTA.Texts = "";
            txtFTM.Texts = "";
            txtTurnovers.Texts = "";

            //Table 2
            txtPlayerName.Texts = "";
            txtPlayerTeam.Texts = "";
            txtPosition.Texts = "";
            txtBirthdate.Texts = "";
            txtJerseyNumber.Texts = "";
            txtAge.Texts = "";
            txtWeight.Texts = "";
            txtHeight.Texts = "";
            pictureBox1.Image = null;
        }

        #region -> Basketball Players Statistics
        //New Button
        private void newBtn_Click(object sender, EventArgs e) 
        {
            ClearFields();
        }

        //Save Button
        private void saveBtn_Click(object sender, EventArgs e) 
        {
            try
            {
                string sql = "INSERT INTO basketballPlayers (PlayerName, Team, GamesPlayed, Points, Rebounds, Assists, Steals, Blocks, FGA, FGM, FTA, FTM, Turnovers) " + "VALUES (" + "'" + txtName.Texts + "', " + "'" + txtTeam.Texts + "', " + int.Parse(txtGamesPlayed.Texts) + ", " + double.Parse(txtPoints.Texts) + ", " + double.Parse(txtRebounds.Texts) + ", " + double.Parse(txtAssist.Texts) + ", " + double.Parse(txtSteals.Texts) + "," + double.Parse(txtBlocks.Texts) + "," + double.Parse(txtFGA.Texts) + ", " + double.Parse(txtFGM.Texts) + ", " + double.Parse(txtFTA.Texts) + ", " + double.Parse(txtFTM.Texts) + ", " + double.Parse(txtTurnovers.Texts) +  ")";
                DBHelper.DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added successfully.");
                LoadBasketballPlayers(); // Refresh the data in the DataGridView
                ClearFields(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update Button
        private void updateBtn_Click(object sender, EventArgs e) 
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];

                if (selectedRow["PlayerID"] != DBNull.Value)
                {
                    string sql = "UPDATE basketballPlayers SET " + "PlayerName = '" + txtName.Texts + "', " + "Team = '" + txtTeam.Texts + "', " + "GamesPlayed = " + int.Parse(txtGamesPlayed.Texts) + ", " + "Points = " + double.Parse(txtPoints.Texts) + ", " + "Rebounds = " + double.Parse(txtRebounds.Texts) + ", " + "Assists = " + double.Parse(txtAssist.Texts) + ", " + "Steals = " + double.Parse(txtSteals.Texts) + ", " + "Blocks = " + double.Parse(txtBlocks.Texts) + ", " + "FGA = " + double.Parse(txtFGA.Texts) + ", " + "FGM = " + double.Parse(txtFGM.Texts) + ", " + "FTA = " + double.Parse(txtFTA.Texts) + ", " + "FTM = " + double.Parse(txtFTM.Texts)  + ", " + "Turnovers = " + double.Parse(txtTurnovers.Texts) + " WHERE PlayerID = " + selectedRow["PlayerID"];
                    DBHelper.DBHelper.ModifyRecord(sql);
                    MessageBox.Show("Data has been updated successfully.");
                    LoadBasketballPlayers(); // Refresh the data in the DataGridView
                }
                else
                {
                    MessageBox.Show("PlayerID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridView1.DataSource).Rows[selectedRowIndex];

                        if (selectedRow["PlayerID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM basketballPlayers WHERE PlayerID = " + selectedRow["PlayerID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.");
                            LoadBasketballPlayers(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("PlayerID cannot be null.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        //Search Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchedPlayerID = txtSearch.Texts.Trim();

            try
            {
                string query = "SELECT * from basketballPlayers where PlayerID like '" + searchedPlayerID + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("Player ID # " + searchedPlayerID + " does not exist.");
                }
                DBHelper.DBHelper.fill(query, dataGridView1);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter full name of the player.");
                txtSearch.Texts = "";
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Keydown
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }

        // Cellclick
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtName.Texts = dataGridView1[1, e.RowIndex].Value.ToString();
                txtTeam.Texts = dataGridView1[2, e.RowIndex].Value.ToString();
                txtGamesPlayed.Texts = dataGridView1[3, e.RowIndex].Value.ToString();
                txtPoints.Texts = dataGridView1[4, e.RowIndex].Value.ToString();
                txtRebounds.Texts = dataGridView1[5, e.RowIndex].Value.ToString();
                txtAssist.Texts = dataGridView1[6, e.RowIndex].Value.ToString();
                txtSteals.Texts = dataGridView1[7, e.RowIndex].Value.ToString();
                txtBlocks.Texts = dataGridView1[8, e.RowIndex].Value.ToString();
                txtFGA.Texts = dataGridView1[9, e.RowIndex].Value.ToString();
                txtFGM.Texts = dataGridView1[10, e.RowIndex].Value.ToString();
                txtFTA.Texts = dataGridView1[11, e.RowIndex].Value.ToString();
                txtFTM.Texts = dataGridView1[12, e.RowIndex].Value.ToString();
                txtTurnovers.Texts = dataGridView1[13, e.RowIndex].Value.ToString();
            }
            catch (Exception)
            { }
        }
        #endregion

        #region -> Basketball Players Information
        //New Button
        private void btnNew_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        //Save Button
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO basketballPlayersInfo (PlayerName, Team, [Position], Birthdate, JerseyNumber, Age, Weight, Height, PlayerProfile) " + "VALUES ('" + txtPlayerName.Texts + "', '" + txtPlayerTeam.Texts + "', '" + txtPosition.Texts + "', '" + txtBirthdate.Texts + "', " + int.Parse(txtJerseyNumber.Texts) + ", " + int.Parse(txtAge.Texts) + ", " + int.Parse(txtWeight.Texts) + ", " + double.Parse(txtHeight.Texts) + ", @PlayerProfile)";
                OleDbConnection connection = new OleDbConnection(Connection.Connection.dbconnect);
                OleDbCommand command = new OleDbCommand(sql, connection);

                if (pictureBox1.Image != null)
                {
                    MemoryStream ms = new MemoryStream();
                    pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                    command.Parameters.AddWithValue("@ProfilePicture", ms.ToArray());
                }
                else
                {
                    command.Parameters.AddWithValue("@ProfilePicture", DBNull.Value);
                }

                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("Player added successfully.");
                LoadBasketballPlayersInformation(); // Refresh the data in the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        //Update Button
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridView2.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridView2.DataSource).Rows[selectedRowIndex];

                if (selectedRow["PlayerID"] != DBNull.Value)
                {
                    try
                    {
                            string sql = "UPDATE basketballPlayersInfo SET PlayerName = '" + txtPlayerName.Texts + "', Team = '" + txtPlayerTeam.Texts + "', [Position] = '" + txtPosition.Texts + "', Birthdate = '" + txtBirthdate.Texts + "', JerseyNumber = " + int.Parse(txtJerseyNumber.Texts) + ", Age = " + int.Parse(txtAge.Texts) + ", Weight = " + int.Parse(txtWeight.Texts) + ", Height = " + double.Parse(txtHeight.Texts) + ", PlayerProfile = @PlayerProfile WHERE PlayerID = " + selectedRow["PlayerID"];
                            OleDbConnection connection = new OleDbConnection(Connection.Connection.dbconnect);
                            OleDbCommand command = new OleDbCommand(sql, connection);

                            if (pictureBox1.Image != null)
                            {
                                MemoryStream ms = new MemoryStream();
                                pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                                command.Parameters.AddWithValue("@PlayerProfile", ms.ToArray());
                            }
                            else
                            {
                                command.Parameters.AddWithValue("@PlayerProfile", DBNull.Value);
                            }

                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        MessageBox.Show("Player information updated successfully.");
                        LoadBasketballPlayersInformation(); // Refresh the data in the DataGridView
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("ID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        //Delete Button
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridView2.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridView2.DataSource).Rows[selectedRowIndex];


                        if (selectedRow["PlayerID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM basketballPlayersInfo WHERE PlayerID = " + selectedRow["PlayerID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.");
                            LoadBasketballPlayersInformation(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("PlayerID cannot be null.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        //Search Button
        private void btnSearchPlayer_Click(object sender, EventArgs e)
        {
            string searchedPlayer = txtSearchPlayer.Texts.Trim();

            try
            {
                string query = "SELECT * from basketballPlayersInfo where PlayerName like '" + searchedPlayer + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("Player " + searchedPlayer + " does not exist.");
                }
                DBHelper.DBHelper.fill(query, dataGridView2);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter full name of the player.");
                txtSearch.Texts = "";
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Key Down
        private void txtSearchPlayer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearchPlayer_Click(sender, e);
            }
        }

        //Browse Button
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }

        //Cell Click
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtPlayerName.Texts = dataGridView2[1, e.RowIndex].Value.ToString();
                txtPlayerTeam.Texts = dataGridView2[2, e.RowIndex].Value.ToString();
                txtPosition.Texts = dataGridView2[3, e.RowIndex].Value.ToString();
                txtBirthdate.Texts = dataGridView2[4, e.RowIndex].Value.ToString();
                txtJerseyNumber.Texts = dataGridView2[5, e.RowIndex].Value.ToString();
                txtAge.Texts = dataGridView2[6, e.RowIndex].Value.ToString();
                txtWeight.Texts = dataGridView2[7, e.RowIndex].Value.ToString();
                txtHeight.Texts = dataGridView2[8, e.RowIndex].Value.ToString();

                if (dataGridView2[9, e.RowIndex].Value != DBNull.Value)
                {
                    byte[] imageBytes = (byte[])dataGridView2[9, e.RowIndex].Value;
                    using (MemoryStream ms = new MemoryStream(imageBytes))
                    {
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    pictureBox1.Image = null;
                }
            }
            catch (Exception)
            { }
        }
        #endregion

        //Form Load
        private void FormBB_Load(object sender, EventArgs e)
        {
            //Data Gridview 2   
            dataGridView2.Columns["PlayerID"].Visible = false;
            dataGridView2.Columns["PlayerProfile"].Visible = false;
            dataGridView2.Sort(dataGridView2.Columns["PlayerID"], System.ComponentModel.ListSortDirection.Ascending);
        }
    }
}
