﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem
{
    public partial class userDashboard : Form
    {
        //Fields
        private Form activeForm;
        private int userId;
        private string username;
        private string password;
        private string fullname;
        private string email;
        private Image useProfile;

        //Constructor
        public userDashboard(int userId, string username, string password, string fullname, string email, byte[] imageBytes)
        {
            InitializeComponent();
            labelTitle.Text = "Welcome " + username + "!";
            btnBack.Visible = false; // Hide back button
            this.userId = userId;
            this.username = username;
            this.password = password;
            this.fullname = fullname;
            this.email = email;
            this.useProfile = ConvertToImage(imageBytes);
        }

        // Switching Forms
        private void SwitchForm(Form switchForm, object btnSender)
        {
            if (activeForm != null)
            activeForm.Close();
            activeForm = switchForm;
            switchForm.TopLevel = false;
            switchForm.FormBorderStyle = FormBorderStyle.None;
            switchForm.Dock = DockStyle.Fill;
            this.panelDesktopPane.Controls.Add(switchForm);
            this.panelDesktopPane.Tag = switchForm;
            switchForm.BringToFront();
            switchForm.Show();
            lblTitle.Text = switchForm.Text;
            btnBack.Visible = true;
        }

        //Reset to default form
        private void DefaultForm()
        {
            lblTitle.Text = "HOME";
            panelTitleBar.BackColor = Color.FromArgb(27, 27, 27);
            panelLogo.BackColor = Color.FromArgb(27, 27, 27);
            btnBack.Visible = false;
        }

        #region -> Buttons
        //Games Button
        private void btnGames_Click(object sender, EventArgs e) 
        {
            SwitchForm(new Forms.FormGames(), sender); 
        }

        //Profile Button
        private void btnProfile_Click(object sender, EventArgs e) 
        {
            SwitchForm(new Forms.FormProfile(userId, username, password, fullname, email, useProfile), sender);
        }

        //Basketball Button
        private void btnBasketball_Click(object sender, EventArgs e) 
        {
            SwitchForm(new Forms.FormBasketball(), sender); 
        }

        //Volleyball Button
        private void btnVolleyball_Click(object sender, EventArgs e) 
        {
            SwitchForm(new Forms.FormVolleyball(), sender); 
        }

        //Featured 1 Button
        private void btnFeatured1_Click(object sender, EventArgs e) 
        {
            SwitchForm(new Forms.FormFeatured1(), sender);
        }

        //Featured 2 Button
        private void btnFeatured2_Click(object sender, EventArgs e) 
        {
            SwitchForm(new Forms.FormFeatured2(), sender);
        }

        //Back Button
        private void btnBack_Click(object sender, EventArgs e) 
        {
            if (activeForm != null)
                activeForm.Close();
            DefaultForm();
        }

        //About Us Button
        private void btnAbout_Click(object sender, EventArgs e)
        {
            SwitchForm(new Forms.FormAboutUs(), sender);
        }

        //Logout Button
        private void btnLogout_Click(object sender, EventArgs e) //Logout
        {
            this.Hide(); // Hide the userDashboard form
            Login loginForm = new Login();
            loginForm.Show(); // Show the Login form 
        }
        #endregion

        //Convert bytes to image
        private Image ConvertToImage(byte[] imageBytes)
        {
            using (MemoryStream ms = new MemoryStream(imageBytes))
            {
                return Image.FromStream(ms);
            }
        }
        //Close form
        private void userDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application
        }
    }
}
