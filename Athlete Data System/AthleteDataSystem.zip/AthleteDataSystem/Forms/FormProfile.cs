﻿using System;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormProfile : Form
    {
        private int userId;

        public FormProfile(int userId, string username, string password, string fullname, string email, Image userPicture)
        {
            InitializeComponent();
            this.userId = userId;
            txtUsername.Texts = username;
            txtPassword.Texts = password;
            txtFullName.Texts = fullname;
            txtEmail.Texts = email;
            pictureBoxUser.Image = userPicture;
        }

        private void btnEditProfile_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBoxUser.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE accounts SET username = '" + txtUsername.Texts + "', " + "[password] = '" + txtPassword.Texts + "', " + "fullName = '" + txtFullName.Texts + "', Email = '" + txtEmail.Texts + "', ProfilePicture = @ProfilePicture WHERE ID = " + userId;

            OleDbConnection connection = new OleDbConnection(Connection.Connection.dbconnect);
            OleDbCommand command = new OleDbCommand(sql, connection);

            if (pictureBoxUser.Image != null)
            {
                MemoryStream ms = new MemoryStream();
                pictureBoxUser.Image.Save(ms, pictureBoxUser.Image.RawFormat);
                command.Parameters.AddWithValue("@ProfilePicture", ms.ToArray());
            }
            else
            {
                command.Parameters.AddWithValue("@ProfilePicture", DBNull.Value);
            }

            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("User updated successfully.", "Update Account", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnViewPassword_Click(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = !txtPassword.PasswordChar;

        }
    }
}