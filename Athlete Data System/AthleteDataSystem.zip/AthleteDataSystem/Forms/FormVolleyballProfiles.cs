﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormVolleyballProfiles : Form
    {
        public FormVolleyballProfiles(string playerName, string team, int jerseyNumber, string position, int points, int blocks, int ace, int dig, int receive, double height, int weight, int age, string birthday, Image playerImage)
        {
            InitializeComponent();
            lblPlayerName.Text = playerName;
            lblTeam.Text = team;
            lblJerseyNumber.Text = "#" + jerseyNumber.ToString();
            lblPosition.Text = position;
            lblPoints.Text = points.ToString();
            lblBlocks.Text = blocks.ToString();
            lblAce.Text = ace.ToString();
            lblDig.Text = dig.ToString();
            lblReceive.Text = receive.ToString();
            lblHeight.Text = height.ToString() + "m";
            lblWeight.Text = weight.ToString() + "kg";
            lblAge.Text = age.ToString() + " years";
            lblBirthday.Text = birthday;

            if (playerImage != null)
            {
                pictureBoxPlayer.Image = playerImage;
            }
            else
            {
                pictureBoxPlayer.Image = null;
            }
        }
    }
}
