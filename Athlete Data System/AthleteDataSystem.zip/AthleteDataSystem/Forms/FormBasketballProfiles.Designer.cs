﻿namespace AthleteDataSystem.Forms
{
    partial class FormBasketballProfiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBoxPlayer = new System.Windows.Forms.PictureBox();
            this.lblTeam = new System.Windows.Forms.Label();
            this.lblJerseyNumber = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.labelPPG = new System.Windows.Forms.Label();
            this.labelRPG = new System.Windows.Forms.Label();
            this.labelAPG = new System.Windows.Forms.Label();
            this.labelSPG = new System.Windows.Forms.Label();
            this.lblPoints = new System.Windows.Forms.Label();
            this.lblAssist = new System.Windows.Forms.Label();
            this.lblRebounds = new System.Windows.Forms.Label();
            this.lblSteals = new System.Windows.Forms.Label();
            this.labelWeight = new System.Windows.Forms.Label();
            this.labelHeight = new System.Windows.Forms.Label();
            this.labelAge = new System.Windows.Forms.Label();
            this.labelBirthday = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblBirthday = new System.Windows.Forms.Label();
            this.labelEfficiency = new System.Windows.Forms.Label();
            this.lblEfficiency = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBoxPlayer
            // 
            this.pictureBoxPlayer.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxPlayer.Location = new System.Drawing.Point(60, 99);
            this.pictureBoxPlayer.Name = "pictureBoxPlayer";
            this.pictureBoxPlayer.Size = new System.Drawing.Size(269, 254);
            this.pictureBoxPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPlayer.TabIndex = 0;
            this.pictureBoxPlayer.TabStop = false;
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam.ForeColor = System.Drawing.Color.White;
            this.lblTeam.Location = new System.Drawing.Point(365, 99);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(12, 20);
            this.lblTeam.TabIndex = 1;
            this.lblTeam.Text = ".";
            // 
            // lblJerseyNumber
            // 
            this.lblJerseyNumber.AutoSize = true;
            this.lblJerseyNumber.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJerseyNumber.ForeColor = System.Drawing.Color.White;
            this.lblJerseyNumber.Location = new System.Drawing.Point(583, 99);
            this.lblJerseyNumber.Name = "lblJerseyNumber";
            this.lblJerseyNumber.Size = new System.Drawing.Size(12, 20);
            this.lblJerseyNumber.TabIndex = 2;
            this.lblJerseyNumber.Text = ".";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosition.ForeColor = System.Drawing.Color.White;
            this.lblPosition.Location = new System.Drawing.Point(668, 99);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(12, 20);
            this.lblPosition.TabIndex = 3;
            this.lblPosition.Text = ".";
            // 
            // lblPlayerName
            // 
            this.lblPlayerName.AutoSize = true;
            this.lblPlayerName.Font = new System.Drawing.Font("Cambria", 21.75F);
            this.lblPlayerName.ForeColor = System.Drawing.Color.White;
            this.lblPlayerName.Location = new System.Drawing.Point(487, 162);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(21, 34);
            this.lblPlayerName.TabIndex = 4;
            this.lblPlayerName.Text = ".";
            // 
            // labelPPG
            // 
            this.labelPPG.AutoSize = true;
            this.labelPPG.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPPG.ForeColor = System.Drawing.Color.White;
            this.labelPPG.Location = new System.Drawing.Point(88, 378);
            this.labelPPG.Name = "labelPPG";
            this.labelPPG.Size = new System.Drawing.Size(39, 20);
            this.labelPPG.TabIndex = 5;
            this.labelPPG.Text = "PPG";
            // 
            // labelRPG
            // 
            this.labelRPG.AutoSize = true;
            this.labelRPG.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelRPG.ForeColor = System.Drawing.Color.White;
            this.labelRPG.Location = new System.Drawing.Point(303, 378);
            this.labelRPG.Name = "labelRPG";
            this.labelRPG.Size = new System.Drawing.Size(40, 20);
            this.labelRPG.TabIndex = 6;
            this.labelRPG.Text = "RPG";
            // 
            // labelAPG
            // 
            this.labelAPG.AutoSize = true;
            this.labelAPG.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelAPG.ForeColor = System.Drawing.Color.White;
            this.labelAPG.Location = new System.Drawing.Point(197, 378);
            this.labelAPG.Name = "labelAPG";
            this.labelAPG.Size = new System.Drawing.Size(40, 20);
            this.labelAPG.TabIndex = 7;
            this.labelAPG.Text = "APG";
            // 
            // labelSPG
            // 
            this.labelSPG.AutoSize = true;
            this.labelSPG.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelSPG.ForeColor = System.Drawing.Color.White;
            this.labelSPG.Location = new System.Drawing.Point(410, 378);
            this.labelSPG.Name = "labelSPG";
            this.labelSPG.Size = new System.Drawing.Size(37, 20);
            this.labelSPG.TabIndex = 8;
            this.labelSPG.Text = "SPG";
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblPoints.ForeColor = System.Drawing.Color.White;
            this.lblPoints.Location = new System.Drawing.Point(88, 431);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(12, 20);
            this.lblPoints.TabIndex = 9;
            this.lblPoints.Text = ".";
            // 
            // lblAssist
            // 
            this.lblAssist.AutoSize = true;
            this.lblAssist.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblAssist.ForeColor = System.Drawing.Color.White;
            this.lblAssist.Location = new System.Drawing.Point(199, 431);
            this.lblAssist.Name = "lblAssist";
            this.lblAssist.Size = new System.Drawing.Size(12, 20);
            this.lblAssist.TabIndex = 10;
            this.lblAssist.Text = ".";
            // 
            // lblRebounds
            // 
            this.lblRebounds.AutoSize = true;
            this.lblRebounds.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblRebounds.ForeColor = System.Drawing.Color.White;
            this.lblRebounds.Location = new System.Drawing.Point(303, 431);
            this.lblRebounds.Name = "lblRebounds";
            this.lblRebounds.Size = new System.Drawing.Size(12, 20);
            this.lblRebounds.TabIndex = 11;
            this.lblRebounds.Text = ".";
            // 
            // lblSteals
            // 
            this.lblSteals.AutoSize = true;
            this.lblSteals.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblSteals.ForeColor = System.Drawing.Color.White;
            this.lblSteals.Location = new System.Drawing.Point(410, 431);
            this.lblSteals.Name = "lblSteals";
            this.lblSteals.Size = new System.Drawing.Size(12, 20);
            this.lblSteals.TabIndex = 12;
            this.lblSteals.Text = ".";
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelWeight.ForeColor = System.Drawing.Color.White;
            this.labelWeight.Location = new System.Drawing.Point(794, 378);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(60, 20);
            this.labelWeight.TabIndex = 13;
            this.labelWeight.Text = "Weight";
            // 
            // labelHeight
            // 
            this.labelHeight.AutoSize = true;
            this.labelHeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelHeight.ForeColor = System.Drawing.Color.White;
            this.labelHeight.Location = new System.Drawing.Point(564, 378);
            this.labelHeight.Name = "labelHeight";
            this.labelHeight.Size = new System.Drawing.Size(57, 20);
            this.labelHeight.TabIndex = 14;
            this.labelHeight.Text = "Height";
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAge.ForeColor = System.Drawing.Color.White;
            this.labelAge.Location = new System.Drawing.Point(574, 445);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(45, 25);
            this.labelAge.TabIndex = 15;
            this.labelAge.Text = "Age";
            // 
            // labelBirthday
            // 
            this.labelBirthday.AutoSize = true;
            this.labelBirthday.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelBirthday.ForeColor = System.Drawing.Color.White;
            this.labelBirthday.Location = new System.Drawing.Point(787, 445);
            this.labelBirthday.Name = "labelBirthday";
            this.labelBirthday.Size = new System.Drawing.Size(72, 20);
            this.labelBirthday.TabIndex = 16;
            this.labelBirthday.Text = "Birthday";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblHeight.ForeColor = System.Drawing.Color.White;
            this.lblHeight.Location = new System.Drawing.Point(564, 404);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(12, 20);
            this.lblHeight.TabIndex = 17;
            this.lblHeight.Text = ".";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblAge.ForeColor = System.Drawing.Color.White;
            this.lblAge.Location = new System.Drawing.Point(552, 472);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(12, 20);
            this.lblAge.TabIndex = 18;
            this.lblAge.Text = ".";
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblWeight.ForeColor = System.Drawing.Color.White;
            this.lblWeight.Location = new System.Drawing.Point(796, 404);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(12, 20);
            this.lblWeight.TabIndex = 19;
            this.lblWeight.Text = ".";
            // 
            // lblBirthday
            // 
            this.lblBirthday.AutoSize = true;
            this.lblBirthday.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblBirthday.ForeColor = System.Drawing.Color.White;
            this.lblBirthday.Location = new System.Drawing.Point(745, 472);
            this.lblBirthday.Name = "lblBirthday";
            this.lblBirthday.Size = new System.Drawing.Size(12, 20);
            this.lblBirthday.TabIndex = 20;
            this.lblBirthday.Text = ".";
            // 
            // labelEfficiency
            // 
            this.labelEfficiency.AutoSize = true;
            this.labelEfficiency.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelEfficiency.ForeColor = System.Drawing.Color.White;
            this.labelEfficiency.Location = new System.Drawing.Point(536, 296);
            this.labelEfficiency.Name = "labelEfficiency";
            this.labelEfficiency.Size = new System.Drawing.Size(101, 20);
            this.labelEfficiency.TabIndex = 21;
            this.labelEfficiency.Text = "EFFICIENCY";
            // 
            // lblEfficiency
            // 
            this.lblEfficiency.AutoSize = true;
            this.lblEfficiency.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblEfficiency.ForeColor = System.Drawing.Color.White;
            this.lblEfficiency.Location = new System.Drawing.Point(558, 264);
            this.lblEfficiency.Name = "lblEfficiency";
            this.lblEfficiency.Size = new System.Drawing.Size(12, 20);
            this.lblEfficiency.TabIndex = 22;
            this.lblEfficiency.Text = ".";
            // 
            // FormBasketballProfiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.BackgroundImage = global::AthleteDataSystem.Properties.Resources.Player_Profile_Layout;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1004, 611);
            this.Controls.Add(this.lblEfficiency);
            this.Controls.Add(this.labelEfficiency);
            this.Controls.Add(this.lblBirthday);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.labelBirthday);
            this.Controls.Add(this.labelAge);
            this.Controls.Add(this.labelHeight);
            this.Controls.Add(this.labelWeight);
            this.Controls.Add(this.lblSteals);
            this.Controls.Add(this.lblRebounds);
            this.Controls.Add(this.lblAssist);
            this.Controls.Add(this.lblPoints);
            this.Controls.Add(this.labelSPG);
            this.Controls.Add(this.labelAPG);
            this.Controls.Add(this.labelRPG);
            this.Controls.Add(this.labelPPG);
            this.Controls.Add(this.lblPlayerName);
            this.Controls.Add(this.lblPosition);
            this.Controls.Add(this.lblJerseyNumber);
            this.Controls.Add(this.lblTeam);
            this.Controls.Add(this.pictureBoxPlayer);
            this.DoubleBuffered = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1020, 650);
            this.Name = "FormBasketballProfiles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxPlayer;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.Label lblJerseyNumber;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.Label labelPPG;
        private System.Windows.Forms.Label labelRPG;
        private System.Windows.Forms.Label labelAPG;
        private System.Windows.Forms.Label labelSPG;
        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.Label lblAssist;
        private System.Windows.Forms.Label lblRebounds;
        private System.Windows.Forms.Label lblSteals;
        private System.Windows.Forms.Label labelWeight;
        private System.Windows.Forms.Label labelHeight;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelBirthday;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblBirthday;
        private System.Windows.Forms.Label labelEfficiency;
        private System.Windows.Forms.Label lblEfficiency;
    }
}