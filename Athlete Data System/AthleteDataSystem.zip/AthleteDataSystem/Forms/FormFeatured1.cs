﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormFeatured1 : Form
    {
        public FormFeatured1()
        {
            InitializeComponent();
        }
    }
}
