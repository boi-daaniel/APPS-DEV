﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem
{
    public partial class adminDashboard : Form
    {
        private Form activeForm;

        //Constructor
        public adminDashboard()
        {
            InitializeComponent();
        }

        //Switching Forms Methods
        private void SwitchForm(Form switchForm, object btnSender)
        {
            if (activeForm != null)
            activeForm.Close();
            activeForm = switchForm;
            switchForm.TopLevel = false;
            switchForm.FormBorderStyle = FormBorderStyle.None;
            switchForm.Dock = DockStyle.Fill;
            this.panelDBTable.Controls.Add(switchForm);
            this.panelDBTable.Tag = switchForm;
            switchForm.BringToFront();
            switchForm.Show();
        }

        #region -> Buttons
        //Basketball
        private void btnBasketball_Click(object sender, EventArgs e)
        {
            SwitchForm(new AdminForms.FormBB(), sender);
        }

        //Volleyball
        private void btnVolleyball_Click(object sender, EventArgs e)
        {
            SwitchForm(new AdminForms.FormVB(), sender);
        }

        //Games Schedules
        private void btnGamesSchedules_Click(object sender, EventArgs e)
        {
            SwitchForm(new AdminForms.FormGS(), sender);
        }

        //Accounts
        private void btnAccounts_Click(object sender, EventArgs e) 
        {
            SwitchForm(new AdminForms.FormAccounts(), sender);
        }

        //Logout
        private void logoutBtn_Click_1(object sender, EventArgs e) 
        {
            this.Hide(); 
            Login loginForm = new Login();
            loginForm.Show(); 
        }
        #endregion

        //Close Form
        private void adminDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application
        }
    }
}
