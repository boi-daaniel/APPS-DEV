﻿namespace AthleteDataSystem
{
    partial class adminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelDash = new System.Windows.Forms.Panel();
            this.btnAccounts = new System.Windows.Forms.Button();
            this.btnGamesSchedules = new System.Windows.Forms.Button();
            this.btnVolleyball = new System.Windows.Forms.Button();
            this.btnBasketball = new System.Windows.Forms.Button();
            this.panelTitle = new System.Windows.Forms.Panel();
            this.labelGreetings = new System.Windows.Forms.Label();
            this.logoutBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.panelDBTable = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelDash.SuspendLayout();
            this.panelTitle.SuspendLayout();
            this.panelDBTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelDash
            // 
            this.panelDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panelDash.Controls.Add(this.btnAccounts);
            this.panelDash.Controls.Add(this.btnGamesSchedules);
            this.panelDash.Controls.Add(this.btnVolleyball);
            this.panelDash.Controls.Add(this.btnBasketball);
            this.panelDash.Controls.Add(this.panelTitle);
            this.panelDash.Controls.Add(this.logoutBtn);
            this.panelDash.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelDash.Location = new System.Drawing.Point(0, 0);
            this.panelDash.Name = "panelDash";
            this.panelDash.Size = new System.Drawing.Size(200, 611);
            this.panelDash.TabIndex = 55;
            // 
            // btnAccounts
            // 
            this.btnAccounts.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAccounts.FlatAppearance.BorderColor = System.Drawing.Color.DarkViolet;
            this.btnAccounts.FlatAppearance.BorderSize = 0;
            this.btnAccounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAccounts.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccounts.ForeColor = System.Drawing.Color.White;
            this.btnAccounts.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAccounts.Location = new System.Drawing.Point(0, 280);
            this.btnAccounts.Name = "btnAccounts";
            this.btnAccounts.Size = new System.Drawing.Size(200, 60);
            this.btnAccounts.TabIndex = 55;
            this.btnAccounts.Text = "Accounts";
            this.btnAccounts.UseVisualStyleBackColor = true;
            this.btnAccounts.Click += new System.EventHandler(this.btnAccounts_Click);
            // 
            // btnGamesSchedules
            // 
            this.btnGamesSchedules.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGamesSchedules.FlatAppearance.BorderColor = System.Drawing.Color.DarkViolet;
            this.btnGamesSchedules.FlatAppearance.BorderSize = 0;
            this.btnGamesSchedules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGamesSchedules.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGamesSchedules.ForeColor = System.Drawing.Color.White;
            this.btnGamesSchedules.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGamesSchedules.Location = new System.Drawing.Point(0, 220);
            this.btnGamesSchedules.Name = "btnGamesSchedules";
            this.btnGamesSchedules.Size = new System.Drawing.Size(200, 60);
            this.btnGamesSchedules.TabIndex = 54;
            this.btnGamesSchedules.Text = "Game Schedules";
            this.btnGamesSchedules.UseVisualStyleBackColor = true;
            this.btnGamesSchedules.Click += new System.EventHandler(this.btnGamesSchedules_Click);
            // 
            // btnVolleyball
            // 
            this.btnVolleyball.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnVolleyball.FlatAppearance.BorderColor = System.Drawing.Color.DarkViolet;
            this.btnVolleyball.FlatAppearance.BorderSize = 0;
            this.btnVolleyball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolleyball.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolleyball.ForeColor = System.Drawing.Color.White;
            this.btnVolleyball.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnVolleyball.Location = new System.Drawing.Point(0, 160);
            this.btnVolleyball.Name = "btnVolleyball";
            this.btnVolleyball.Size = new System.Drawing.Size(200, 60);
            this.btnVolleyball.TabIndex = 53;
            this.btnVolleyball.Text = "Volleyball";
            this.btnVolleyball.UseVisualStyleBackColor = true;
            this.btnVolleyball.Click += new System.EventHandler(this.btnVolleyball_Click);
            // 
            // btnBasketball
            // 
            this.btnBasketball.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBasketball.FlatAppearance.BorderColor = System.Drawing.Color.DarkViolet;
            this.btnBasketball.FlatAppearance.BorderSize = 0;
            this.btnBasketball.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBasketball.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBasketball.ForeColor = System.Drawing.Color.White;
            this.btnBasketball.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBasketball.Location = new System.Drawing.Point(0, 100);
            this.btnBasketball.Name = "btnBasketball";
            this.btnBasketball.Size = new System.Drawing.Size(200, 60);
            this.btnBasketball.TabIndex = 50;
            this.btnBasketball.Text = "Basketball";
            this.btnBasketball.UseVisualStyleBackColor = true;
            this.btnBasketball.Click += new System.EventHandler(this.btnBasketball_Click);
            // 
            // panelTitle
            // 
            this.panelTitle.Controls.Add(this.labelGreetings);
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(0, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(200, 100);
            this.panelTitle.TabIndex = 49;
            // 
            // labelGreetings
            // 
            this.labelGreetings.AutoSize = true;
            this.labelGreetings.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGreetings.Location = new System.Drawing.Point(18, 36);
            this.labelGreetings.Name = "labelGreetings";
            this.labelGreetings.Size = new System.Drawing.Size(164, 25);
            this.labelGreetings.TabIndex = 0;
            this.labelGreetings.Text = "Welcome Admin!";
            // 
            // logoutBtn
            // 
            this.logoutBtn.BackColor = System.Drawing.Color.White;
            this.logoutBtn.BackgroundColor = System.Drawing.Color.White;
            this.logoutBtn.BorderColor = System.Drawing.Color.Black;
            this.logoutBtn.BorderRadius = 20;
            this.logoutBtn.BorderSize = 2;
            this.logoutBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logoutBtn.FlatAppearance.BorderSize = 0;
            this.logoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutBtn.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutBtn.ForeColor = System.Drawing.Color.Black;
            this.logoutBtn.Location = new System.Drawing.Point(0, 571);
            this.logoutBtn.Margin = new System.Windows.Forms.Padding(2);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Size = new System.Drawing.Size(200, 40);
            this.logoutBtn.TabIndex = 48;
            this.logoutBtn.Text = "Log out";
            this.logoutBtn.TextColor = System.Drawing.Color.Black;
            this.logoutBtn.UseVisualStyleBackColor = false;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click_1);
            // 
            // panelDBTable
            // 
            this.panelDBTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.panelDBTable.Controls.Add(this.label3);
            this.panelDBTable.Controls.Add(this.label2);
            this.panelDBTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDBTable.ForeColor = System.Drawing.Color.White;
            this.panelDBTable.Location = new System.Drawing.Point(200, 0);
            this.panelDBTable.Name = "panelDBTable";
            this.panelDBTable.Size = new System.Drawing.Size(804, 611);
            this.panelDBTable.TabIndex = 56;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(58, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(295, 37);
            this.label3.TabIndex = 6;
            this.label3.Text = "Athlete Data System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(61, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Jose Danielle Inocentes.\r\n";
            // 
            // adminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1004, 611);
            this.Controls.Add(this.panelDBTable);
            this.Controls.Add(this.panelDash);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(1020, 650);
            this.Name = "adminDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Dashboard";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.adminDashboard_FormClosed);
            this.panelDash.ResumeLayout(false);
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            this.panelDBTable.ResumeLayout(false);
            this.panelDBTable.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private CustomTools.CurvedButton logoutBtn;
        private System.Windows.Forms.Panel panelDash;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.Label labelGreetings;
        private System.Windows.Forms.Panel panelDBTable;
        private System.Windows.Forms.Button btnBasketball;
        private System.Windows.Forms.Button btnVolleyball;
        private System.Windows.Forms.Button btnGamesSchedules;
        private System.Windows.Forms.Button btnAccounts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}