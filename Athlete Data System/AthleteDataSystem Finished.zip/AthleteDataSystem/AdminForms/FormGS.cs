﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace AthleteDataSystem.AdminForms
{
    public partial class FormGS : Form
    {
        //Constructor
        public FormGS()
        {
            InitializeComponent();
            LoadGamesSchedules();
        }

        #region -> Methods
        //Load Table
        private void LoadGamesSchedules()
        {
            try
            {
                string query = "SELECT * FROM games";
                DBHelper.DBHelper.fill(query, dataGridViewGames);
            }
            catch 
            { }
        }

        //Clear Text Fields
        private void ClearFields()
        {
            txtGames.Texts = "";
            txtTeamMatchup.Texts = "";
            txtDate.Value = DateTime.Now;
        }

        //Cell Click
        private void dataGridViewGames_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.RowIndex < dataGridViewGames.Rows.Count)
                {
                    txtTeamMatchup.Texts = dataGridViewGames[1, e.RowIndex].Value?.ToString();
                    txtGames.Texts = dataGridViewGames[2, e.RowIndex].Value?.ToString();
                    txtDate.Value = Convert.ToDateTime(dataGridViewGames[3, e.RowIndex].Value);
                }
            }
            catch 
            { }
        }

        #region -> Buttons
        //New Button
        private void newBtn_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        //Save Button
        private void saveBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "INSERT INTO games (TeamMatchup, Games, GameDateTime) " + "VALUES (" + "'" + txtTeamMatchup.Texts + "', " + "'" + txtGames.Texts + "', " + "'" + txtDate.Value.ToString("yyyy-MM-dd HH:mm:ss") + "'" + ")";
                DBHelper.DBHelper.ModifyRecord(sql);
                MessageBox.Show("Data has been added successfully.");
                LoadGamesSchedules(); // Refresh the data in the DataGridView
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Update Button
        private void updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridViewGames.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridViewGames.SelectedRows[0].Index;
                DataRow selectedRow = ((DataTable)dataGridViewGames.DataSource).Rows[selectedRowIndex];

                if (selectedRow["MatchID"] != DBNull.Value)
                {
                    string sql = "UPDATE games SET " + "TeamMatchup = '" + txtTeamMatchup.Texts + "', " + "Games = '" + txtGames.Texts + "', " + "GameDateTime = '" + txtDate.Value.ToString("yyyy-MM-dd HH:mm:ss") + "' " + "WHERE MatchID = " + selectedRow["MatchID"];
                    DBHelper.DBHelper.ModifyRecord(sql);
                    MessageBox.Show("Data has been updated successfully.");
                    LoadGamesSchedules(); // Refresh the data in the DataGridView
                }
                else
                {
                    MessageBox.Show("MatchID cannot be null.");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }

        //Delete Button
        private void deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridViewGames.SelectedRows.Count > 0)
            {
                var res = MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        int selectedRowIndex = dataGridViewGames.SelectedRows[0].Index;
                        DataRow selectedRow = ((DataTable)dataGridViewGames.DataSource).Rows[selectedRowIndex];

                        if (selectedRow["MatchID"] != DBNull.Value)
                        {
                            string sql = "DELETE FROM games WHERE MatchID = " + selectedRow["MatchID"];
                            DBHelper.DBHelper.ModifyRecord(sql);
                            MessageBox.Show("Record deleted successfully.");
                            LoadGamesSchedules(); // Refresh the data in the DataGridView
                        }
                        else
                        {
                            MessageBox.Show("MatchID cannot be null.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        //Search Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchedMatchID = txtSearch.Texts.Trim();

            try
            {
                string query = "SELECT * from games where MatchID like '" + searchedMatchID + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("Match ID " + searchedMatchID + " does not exist.");
                }
                DBHelper.DBHelper.fill(query, dataGridViewGames);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter a valid Match ID!");
                txtSearch.Texts = "";
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        //Keydown
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }
        #endregion

        #endregion

    }
}
