﻿namespace AthleteDataSystem.Forms
{
    partial class FormVolleyballProfiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblJerseyNumber = new System.Windows.Forms.Label();
            this.lblTeam = new System.Windows.Forms.Label();
            this.lblBirthday = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.labelBirthday = new System.Windows.Forms.Label();
            this.labelAge = new System.Windows.Forms.Label();
            this.labelHeight = new System.Windows.Forms.Label();
            this.labelWeight = new System.Windows.Forms.Label();
            this.pictureBoxPlayer = new System.Windows.Forms.PictureBox();
            this.lblDig = new System.Windows.Forms.Label();
            this.lblAce = new System.Windows.Forms.Label();
            this.lblBlocks = new System.Windows.Forms.Label();
            this.lblPoints = new System.Windows.Forms.Label();
            this.lblReceive = new System.Windows.Forms.Label();
            this.labelPoints = new System.Windows.Forms.Label();
            this.labelBlocks = new System.Windows.Forms.Label();
            this.labelAce = new System.Windows.Forms.Label();
            this.labelDig = new System.Windows.Forms.Label();
            this.labelReceive = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayer)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayerName
            // 
            this.lblPlayerName.AutoSize = true;
            this.lblPlayerName.Font = new System.Drawing.Font("Cambria", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPlayerName.ForeColor = System.Drawing.Color.White;
            this.lblPlayerName.Location = new System.Drawing.Point(507, 124);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(21, 34);
            this.lblPlayerName.TabIndex = 8;
            this.lblPlayerName.Text = ".";
            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosition.ForeColor = System.Drawing.Color.White;
            this.lblPosition.Location = new System.Drawing.Point(746, 67);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(12, 20);
            this.lblPosition.TabIndex = 7;
            this.lblPosition.Text = ".";
            // 
            // lblJerseyNumber
            // 
            this.lblJerseyNumber.AutoSize = true;
            this.lblJerseyNumber.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJerseyNumber.ForeColor = System.Drawing.Color.White;
            this.lblJerseyNumber.Location = new System.Drawing.Point(661, 67);
            this.lblJerseyNumber.Name = "lblJerseyNumber";
            this.lblJerseyNumber.Size = new System.Drawing.Size(12, 20);
            this.lblJerseyNumber.TabIndex = 6;
            this.lblJerseyNumber.Text = ".";
            // 
            // lblTeam
            // 
            this.lblTeam.AutoSize = true;
            this.lblTeam.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeam.ForeColor = System.Drawing.Color.White;
            this.lblTeam.Location = new System.Drawing.Point(443, 67);
            this.lblTeam.Name = "lblTeam";
            this.lblTeam.Size = new System.Drawing.Size(12, 20);
            this.lblTeam.TabIndex = 5;
            this.lblTeam.Text = ".";
            // 
            // lblBirthday
            // 
            this.lblBirthday.AutoSize = true;
            this.lblBirthday.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblBirthday.ForeColor = System.Drawing.Color.White;
            this.lblBirthday.Location = new System.Drawing.Point(672, 306);
            this.lblBirthday.Name = "lblBirthday";
            this.lblBirthday.Size = new System.Drawing.Size(12, 20);
            this.lblBirthday.TabIndex = 28;
            this.lblBirthday.Text = ".";
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblWeight.ForeColor = System.Drawing.Color.White;
            this.lblWeight.Location = new System.Drawing.Point(723, 238);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(12, 20);
            this.lblWeight.TabIndex = 27;
            this.lblWeight.Text = ".";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblAge.ForeColor = System.Drawing.Color.White;
            this.lblAge.Location = new System.Drawing.Point(479, 306);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(12, 20);
            this.lblAge.TabIndex = 26;
            this.lblAge.Text = ".";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblHeight.ForeColor = System.Drawing.Color.White;
            this.lblHeight.Location = new System.Drawing.Point(491, 238);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(12, 20);
            this.lblHeight.TabIndex = 25;
            this.lblHeight.Text = ".";
            // 
            // labelBirthday
            // 
            this.labelBirthday.AutoSize = true;
            this.labelBirthday.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelBirthday.ForeColor = System.Drawing.Color.White;
            this.labelBirthday.Location = new System.Drawing.Point(714, 279);
            this.labelBirthday.Name = "labelBirthday";
            this.labelBirthday.Size = new System.Drawing.Size(72, 20);
            this.labelBirthday.TabIndex = 24;
            this.labelBirthday.Text = "Birthday";
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAge.ForeColor = System.Drawing.Color.White;
            this.labelAge.Location = new System.Drawing.Point(501, 279);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(45, 25);
            this.labelAge.TabIndex = 23;
            this.labelAge.Text = "Age";
            // 
            // labelHeight
            // 
            this.labelHeight.AutoSize = true;
            this.labelHeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelHeight.ForeColor = System.Drawing.Color.White;
            this.labelHeight.Location = new System.Drawing.Point(491, 212);
            this.labelHeight.Name = "labelHeight";
            this.labelHeight.Size = new System.Drawing.Size(57, 20);
            this.labelHeight.TabIndex = 22;
            this.labelHeight.Text = "Height";
            // 
            // labelWeight
            // 
            this.labelWeight.AutoSize = true;
            this.labelWeight.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelWeight.ForeColor = System.Drawing.Color.White;
            this.labelWeight.Location = new System.Drawing.Point(721, 212);
            this.labelWeight.Name = "labelWeight";
            this.labelWeight.Size = new System.Drawing.Size(60, 20);
            this.labelWeight.TabIndex = 21;
            this.labelWeight.Text = "Weight";
            // 
            // pictureBoxPlayer
            // 
            this.pictureBoxPlayer.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxPlayer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxPlayer.Location = new System.Drawing.Point(40, 45);
            this.pictureBoxPlayer.Name = "pictureBoxPlayer";
            this.pictureBoxPlayer.Size = new System.Drawing.Size(269, 254);
            this.pictureBoxPlayer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPlayer.TabIndex = 29;
            this.pictureBoxPlayer.TabStop = false;
            // 
            // lblDig
            // 
            this.lblDig.AutoSize = true;
            this.lblDig.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblDig.ForeColor = System.Drawing.Color.White;
            this.lblDig.Location = new System.Drawing.Point(557, 452);
            this.lblDig.Name = "lblDig";
            this.lblDig.Size = new System.Drawing.Size(12, 20);
            this.lblDig.TabIndex = 33;
            this.lblDig.Text = ".";
            // 
            // lblAce
            // 
            this.lblAce.AutoSize = true;
            this.lblAce.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblAce.ForeColor = System.Drawing.Color.White;
            this.lblAce.Location = new System.Drawing.Point(450, 452);
            this.lblAce.Name = "lblAce";
            this.lblAce.Size = new System.Drawing.Size(12, 20);
            this.lblAce.TabIndex = 32;
            this.lblAce.Text = ".";
            // 
            // lblBlocks
            // 
            this.lblBlocks.AutoSize = true;
            this.lblBlocks.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblBlocks.ForeColor = System.Drawing.Color.White;
            this.lblBlocks.Location = new System.Drawing.Point(346, 452);
            this.lblBlocks.Name = "lblBlocks";
            this.lblBlocks.Size = new System.Drawing.Size(12, 20);
            this.lblBlocks.TabIndex = 31;
            this.lblBlocks.Text = ".";
            // 
            // lblPoints
            // 
            this.lblPoints.AutoSize = true;
            this.lblPoints.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblPoints.ForeColor = System.Drawing.Color.White;
            this.lblPoints.Location = new System.Drawing.Point(235, 452);
            this.lblPoints.Name = "lblPoints";
            this.lblPoints.Size = new System.Drawing.Size(12, 20);
            this.lblPoints.TabIndex = 30;
            this.lblPoints.Text = ".";
            // 
            // lblReceive
            // 
            this.lblReceive.AutoSize = true;
            this.lblReceive.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.lblReceive.ForeColor = System.Drawing.Color.White;
            this.lblReceive.Location = new System.Drawing.Point(643, 452);
            this.lblReceive.Name = "lblReceive";
            this.lblReceive.Size = new System.Drawing.Size(12, 20);
            this.lblReceive.TabIndex = 34;
            this.lblReceive.Text = ".";
            // 
            // labelPoints
            // 
            this.labelPoints.AutoSize = true;
            this.labelPoints.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelPoints.ForeColor = System.Drawing.Color.White;
            this.labelPoints.Location = new System.Drawing.Point(214, 417);
            this.labelPoints.Name = "labelPoints";
            this.labelPoints.Size = new System.Drawing.Size(55, 20);
            this.labelPoints.TabIndex = 35;
            this.labelPoints.Text = "Points";
            // 
            // labelBlocks
            // 
            this.labelBlocks.AutoSize = true;
            this.labelBlocks.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelBlocks.ForeColor = System.Drawing.Color.White;
            this.labelBlocks.Location = new System.Drawing.Point(324, 417);
            this.labelBlocks.Name = "labelBlocks";
            this.labelBlocks.Size = new System.Drawing.Size(57, 20);
            this.labelBlocks.TabIndex = 36;
            this.labelBlocks.Text = "Blocks";
            // 
            // labelAce
            // 
            this.labelAce.AutoSize = true;
            this.labelAce.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelAce.ForeColor = System.Drawing.Color.White;
            this.labelAce.Location = new System.Drawing.Point(428, 417);
            this.labelAce.Name = "labelAce";
            this.labelAce.Size = new System.Drawing.Size(36, 20);
            this.labelAce.TabIndex = 37;
            this.labelAce.Text = "Ace";
            // 
            // labelDig
            // 
            this.labelDig.AutoSize = true;
            this.labelDig.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelDig.ForeColor = System.Drawing.Color.White;
            this.labelDig.Location = new System.Drawing.Point(545, 417);
            this.labelDig.Name = "labelDig";
            this.labelDig.Size = new System.Drawing.Size(33, 20);
            this.labelDig.TabIndex = 38;
            this.labelDig.Text = "Dig";
            // 
            // labelReceive
            // 
            this.labelReceive.AutoSize = true;
            this.labelReceive.Font = new System.Drawing.Font("Cambria", 12.75F);
            this.labelReceive.ForeColor = System.Drawing.Color.White;
            this.labelReceive.Location = new System.Drawing.Point(618, 417);
            this.labelReceive.Name = "labelReceive";
            this.labelReceive.Size = new System.Drawing.Size(66, 20);
            this.labelReceive.TabIndex = 39;
            this.labelReceive.Text = "Receive";
            // 
            // FormVolleyballProfiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.ClientSize = new System.Drawing.Size(1004, 611);
            this.Controls.Add(this.labelReceive);
            this.Controls.Add(this.labelDig);
            this.Controls.Add(this.labelAce);
            this.Controls.Add(this.labelBlocks);
            this.Controls.Add(this.labelPoints);
            this.Controls.Add(this.lblReceive);
            this.Controls.Add(this.lblDig);
            this.Controls.Add(this.lblAce);
            this.Controls.Add(this.lblBlocks);
            this.Controls.Add(this.lblPoints);
            this.Controls.Add(this.pictureBoxPlayer);
            this.Controls.Add(this.lblBirthday);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.labelBirthday);
            this.Controls.Add(this.labelAge);
            this.Controls.Add(this.labelHeight);
            this.Controls.Add(this.labelWeight);
            this.Controls.Add(this.lblPlayerName);
            this.Controls.Add(this.lblPosition);
            this.Controls.Add(this.lblJerseyNumber);
            this.Controls.Add(this.lblTeam);
            this.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximumSize = new System.Drawing.Size(1020, 650);
            this.MinimumSize = new System.Drawing.Size(1020, 650);
            this.Name = "FormVolleyballProfiles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormVolleyballProfiles";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlayer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblJerseyNumber;
        private System.Windows.Forms.Label lblTeam;
        private System.Windows.Forms.Label lblBirthday;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label labelBirthday;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelHeight;
        private System.Windows.Forms.Label labelWeight;
        private System.Windows.Forms.PictureBox pictureBoxPlayer;
        private System.Windows.Forms.Label lblDig;
        private System.Windows.Forms.Label lblAce;
        private System.Windows.Forms.Label lblBlocks;
        private System.Windows.Forms.Label lblPoints;
        private System.Windows.Forms.Label lblReceive;
        private System.Windows.Forms.Label labelPoints;
        private System.Windows.Forms.Label labelBlocks;
        private System.Windows.Forms.Label labelAce;
        private System.Windows.Forms.Label labelDig;
        private System.Windows.Forms.Label labelReceive;
    }
}