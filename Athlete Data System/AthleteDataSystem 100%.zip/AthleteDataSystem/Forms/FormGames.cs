﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormGames : Form
    {
        public FormGames()
        {
            InitializeComponent();
            LoadGamesTable();
        }

        private void LoadGamesTable()
        {
            try
            {
                string query = "SELECT * FROM games";
                DBHelper.DBHelper.fill(query, dataGridViewGames);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchedMatchID = txtSearch.Texts.Trim();

            try
            {
                string query = "SELECT * from games where MatchID like '" + searchedMatchID + "'";
                Connection.Connection.DB();
                DBHelper.DBHelper.command = new OleDbCommand(query, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                }
                else
                {
                    MessageBox.Show("Match ID " + searchedMatchID + " does not exist.");
                }
                DBHelper.DBHelper.fill(query, dataGridViewGames);
            }
            catch (Exception)
            {
                MessageBox.Show("Enter a valid Match ID!");
                txtSearch.Texts = "";
                Connection.Connection.conn.Close();
            }
            finally
            {
                Connection.Connection.conn.Close();
            }
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch_Click(sender, e);
            }
        }
    }
}
