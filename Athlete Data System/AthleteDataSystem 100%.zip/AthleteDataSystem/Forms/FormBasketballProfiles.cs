﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormBasketballProfiles : Form
    {
        //Constructor
        public FormBasketballProfiles(string playerName, string team, int jerseyNumber, string position, double points, double assists, double rebounds, double steals, double height, int weight, int age, string birthday, double efficiency, Image playerImage)
        {
            InitializeComponent();
            lblPlayerName.Text = playerName;
            lblTeam.Text = team;
            lblJerseyNumber.Text = "#" + jerseyNumber.ToString();
            lblPosition.Text = position;
            lblPoints.Text = points.ToString();
            lblAssist.Text = assists.ToString();
            lblRebounds.Text = rebounds.ToString();
            lblSteals.Text = steals.ToString();
            lblHeight.Text = height.ToString() + "m";
            lblWeight.Text = weight.ToString() + "kg";
            lblAge.Text = age.ToString() + " years";
            lblBirthday.Text = birthday;
            lblEfficiency.Text = "+" + efficiency.ToString();

            if (playerImage != null)
            {
                pictureBoxPlayer.Image = playerImage;
            }
            else
            {
                pictureBoxPlayer.Image = null;
            }
        }
       
    }
}
