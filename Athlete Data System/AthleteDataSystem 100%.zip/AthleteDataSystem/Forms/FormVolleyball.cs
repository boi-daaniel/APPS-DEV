﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AthleteDataSystem.Forms
{
    public partial class FormVolleyball : Form
    {
        public FormVolleyball()
        {
            InitializeComponent();
            LoadVolleyballPlayersHome();
            LoadVolleyballPlayersStats();
        }
        private void FormVolleyball_Load(object sender, EventArgs e)
        {
            dataGridViewVBPlayersHome.Columns["PlayerID"].Visible = false;
            dataGridViewVBPlayersHome.Columns["PlayerProfile"].Visible = false;
            dataGridViewVBPlayersStats.Columns["PlayerID"].Visible = false;
        }

        //Load Table
        private void LoadVolleyballPlayersHome()
        {
            try
            {
                string query = "SELECT * FROM volleyballPlayersInfo";
                DBHelper.DBHelper.fill(query, dataGridViewVBPlayersHome);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void LoadVolleyballPlayersStats()
        {
            try
            {
                string query = "SELECT * FROM volleyballPlayers";
                DBHelper.DBHelper.fill(query, dataGridViewVBPlayersStats);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dataGridViewVBPlayersHome_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int playerProfileColumnIndex = 0; // Index of the image column

            if (e.ColumnIndex == playerProfileColumnIndex && e.RowIndex >= 0)
            {
                string playerName = dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["PlayerName"].Value.ToString();
                string team = dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["Team"].Value.ToString();
                int jerseyNumber = Convert.ToInt32(dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["JerseyNumber"].Value);
                string position = dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["Position"].Value.ToString();
                int points = Convert.ToInt32(dataGridViewVBPlayersStats.Rows[e.RowIndex].Cells["Points"].Value);
                int blocks = Convert.ToInt32(dataGridViewVBPlayersStats.Rows[e.RowIndex].Cells["Block"].Value);
                int ace = Convert.ToInt32(dataGridViewVBPlayersStats.Rows[e.RowIndex].Cells["Ace"].Value);
                int dig = Convert.ToInt32(dataGridViewVBPlayersStats.Rows[e.RowIndex].Cells["Dig"].Value);
                int receive = Convert.ToInt32(dataGridViewVBPlayersStats.Rows[e.RowIndex].Cells["Receive"].Value);
                double height = Convert.ToDouble(dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["Height"].Value);
                int weight = Convert.ToInt32(dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["Weight"].Value);
                int age = Convert.ToInt32(dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["Age"].Value);
                string birthday = dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["Birthdate"].Value.ToString();
                byte[] imageBytes = dataGridViewVBPlayersHome.Rows[e.RowIndex].Cells["PlayerProfile"].Value as byte[];
                Image playerImage = null;

                if (imageBytes != null && imageBytes.Length > 0)
                {
                    playerImage = ConvertToImage(imageBytes);
                }

                FormVolleyballProfiles openProfile = new FormVolleyballProfiles(playerName, team, jerseyNumber, position, points, blocks, ace, dig,receive, height, weight, age, birthday, playerImage);
                openProfile.Show();
            }
        }

        private Image ConvertToImage(byte[] imageBytes)
        {
            using (MemoryStream ms = new MemoryStream(imageBytes))
            {
                return Image.FromStream(ms);
            }
        }
    }
}
