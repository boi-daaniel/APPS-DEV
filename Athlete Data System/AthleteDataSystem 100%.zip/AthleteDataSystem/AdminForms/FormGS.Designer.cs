﻿namespace AthleteDataSystem.AdminForms
{
    partial class FormGS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PanelCommands = new System.Windows.Forms.Panel();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtDate = new System.Windows.Forms.DateTimePicker();
            this.txtGames = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.txtTeamMatchup = new AthleteDataSystem.CustomTools.CurveTextbox();
            this.newBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.saveBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.updateBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.deleteBtn = new AthleteDataSystem.CustomTools.CurvedButton();
            this.labelDate = new System.Windows.Forms.Label();
            this.panelTable = new System.Windows.Forms.Panel();
            this.dataGridViewGames = new System.Windows.Forms.DataGridView();
            this.PanelCommands.SuspendLayout();
            this.panelTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGames)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelCommands
            // 
            this.PanelCommands.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.PanelCommands.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PanelCommands.Controls.Add(this.btnSearch);
            this.PanelCommands.Controls.Add(this.txtSearch);
            this.PanelCommands.Controls.Add(this.txtDate);
            this.PanelCommands.Controls.Add(this.txtGames);
            this.PanelCommands.Controls.Add(this.txtTeamMatchup);
            this.PanelCommands.Controls.Add(this.newBtn);
            this.PanelCommands.Controls.Add(this.saveBtn);
            this.PanelCommands.Controls.Add(this.updateBtn);
            this.PanelCommands.Controls.Add(this.deleteBtn);
            this.PanelCommands.Controls.Add(this.labelDate);
            this.PanelCommands.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelCommands.Location = new System.Drawing.Point(0, 0);
            this.PanelCommands.Name = "PanelCommands";
            this.PanelCommands.Size = new System.Drawing.Size(800, 170);
            this.PanelCommands.TabIndex = 56;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Location = new System.Drawing.Point(712, 99);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 64;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Visible = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearch.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txtSearch.BorderFocusColor = System.Drawing.SystemColors.Highlight;
            this.txtSearch.BorderRadius = 15;
            this.txtSearch.BorderSize = 2;
            this.txtSearch.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtSearch.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearch.Location = new System.Drawing.Point(0, 138);
            this.txtSearch.Multiline = false;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtSearch.PasswordChar = false;
            this.txtSearch.PlaceholderColor = System.Drawing.Color.Black;
            this.txtSearch.PlaceholderText = "Search MatchID";
            this.txtSearch.Size = new System.Drawing.Size(798, 30);
            this.txtSearch.TabIndex = 63;
            this.txtSearch.Texts = "";
            this.txtSearch.UnderlinedStyle = false;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(302, 56);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(200, 20);
            this.txtDate.TabIndex = 58;
            // 
            // txtGames
            // 
            this.txtGames.BackColor = System.Drawing.SystemColors.Window;
            this.txtGames.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtGames.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtGames.BorderRadius = 0;
            this.txtGames.BorderSize = 2;
            this.txtGames.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGames.ForeColor = System.Drawing.Color.DimGray;
            this.txtGames.Location = new System.Drawing.Point(403, 17);
            this.txtGames.Multiline = false;
            this.txtGames.Name = "txtGames";
            this.txtGames.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtGames.PasswordChar = false;
            this.txtGames.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtGames.PlaceholderText = "Games";
            this.txtGames.Size = new System.Drawing.Size(120, 30);
            this.txtGames.TabIndex = 56;
            this.txtGames.Texts = "";
            this.txtGames.UnderlinedStyle = false;
            // 
            // txtTeamMatchup
            // 
            this.txtTeamMatchup.BackColor = System.Drawing.SystemColors.Window;
            this.txtTeamMatchup.BorderColor = System.Drawing.Color.DarkViolet;
            this.txtTeamMatchup.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txtTeamMatchup.BorderRadius = 0;
            this.txtTeamMatchup.BorderSize = 2;
            this.txtTeamMatchup.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTeamMatchup.ForeColor = System.Drawing.Color.DimGray;
            this.txtTeamMatchup.Location = new System.Drawing.Point(277, 17);
            this.txtTeamMatchup.Multiline = false;
            this.txtTeamMatchup.Name = "txtTeamMatchup";
            this.txtTeamMatchup.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtTeamMatchup.PasswordChar = false;
            this.txtTeamMatchup.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txtTeamMatchup.PlaceholderText = "Team Matchup";
            this.txtTeamMatchup.Size = new System.Drawing.Size(120, 30);
            this.txtTeamMatchup.TabIndex = 54;
            this.txtTeamMatchup.Texts = "";
            this.txtTeamMatchup.UnderlinedStyle = false;
            // 
            // newBtn
            // 
            this.newBtn.BackColor = System.Drawing.Color.White;
            this.newBtn.BackgroundColor = System.Drawing.Color.White;
            this.newBtn.BorderColor = System.Drawing.Color.Black;
            this.newBtn.BorderRadius = 15;
            this.newBtn.BorderSize = 2;
            this.newBtn.FlatAppearance.BorderSize = 0;
            this.newBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newBtn.ForeColor = System.Drawing.Color.Black;
            this.newBtn.Location = new System.Drawing.Point(243, 99);
            this.newBtn.Margin = new System.Windows.Forms.Padding(2);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(75, 32);
            this.newBtn.TabIndex = 49;
            this.newBtn.Text = "NEW";
            this.newBtn.TextColor = System.Drawing.Color.Black;
            this.newBtn.UseVisualStyleBackColor = false;
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.White;
            this.saveBtn.BackgroundColor = System.Drawing.Color.White;
            this.saveBtn.BorderColor = System.Drawing.Color.Black;
            this.saveBtn.BorderRadius = 15;
            this.saveBtn.BorderSize = 2;
            this.saveBtn.FlatAppearance.BorderSize = 0;
            this.saveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.ForeColor = System.Drawing.Color.Black;
            this.saveBtn.Location = new System.Drawing.Point(322, 99);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(2);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(75, 32);
            this.saveBtn.TabIndex = 50;
            this.saveBtn.Text = "SAVE";
            this.saveBtn.TextColor = System.Drawing.Color.Black;
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.BackColor = System.Drawing.Color.White;
            this.updateBtn.BackgroundColor = System.Drawing.Color.White;
            this.updateBtn.BorderColor = System.Drawing.Color.Black;
            this.updateBtn.BorderRadius = 15;
            this.updateBtn.BorderSize = 2;
            this.updateBtn.FlatAppearance.BorderSize = 0;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.ForeColor = System.Drawing.Color.Black;
            this.updateBtn.Location = new System.Drawing.Point(401, 99);
            this.updateBtn.Margin = new System.Windows.Forms.Padding(2);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(75, 32);
            this.updateBtn.TabIndex = 52;
            this.updateBtn.Text = "UPDATE";
            this.updateBtn.TextColor = System.Drawing.Color.Black;
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.White;
            this.deleteBtn.BackgroundColor = System.Drawing.Color.White;
            this.deleteBtn.BorderColor = System.Drawing.Color.Black;
            this.deleteBtn.BorderRadius = 15;
            this.deleteBtn.BorderSize = 2;
            this.deleteBtn.FlatAppearance.BorderSize = 0;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteBtn.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.Black;
            this.deleteBtn.Location = new System.Drawing.Point(480, 99);
            this.deleteBtn.Margin = new System.Windows.Forms.Padding(2);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(75, 32);
            this.deleteBtn.TabIndex = 53;
            this.deleteBtn.Text = "DELETE";
            this.deleteBtn.TextColor = System.Drawing.Color.Black;
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.BackColor = System.Drawing.Color.Transparent;
            this.labelDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelDate.Font = new System.Drawing.Font("Cambria", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDate.ForeColor = System.Drawing.Color.White;
            this.labelDate.Location = new System.Drawing.Point(251, 56);
            this.labelDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(46, 20);
            this.labelDate.TabIndex = 35;
            this.labelDate.Text = "Date:";
            // 
            // panelTable
            // 
            this.panelTable.Controls.Add(this.dataGridViewGames);
            this.panelTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTable.ForeColor = System.Drawing.Color.White;
            this.panelTable.Location = new System.Drawing.Point(0, 170);
            this.panelTable.Name = "panelTable";
            this.panelTable.Size = new System.Drawing.Size(800, 280);
            this.panelTable.TabIndex = 62;
            // 
            // dataGridViewGames
            // 
            this.dataGridViewGames.AllowUserToResizeColumns = false;
            this.dataGridViewGames.AllowUserToResizeRows = false;
            this.dataGridViewGames.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            this.dataGridViewGames.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewGames.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dataGridViewGames.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewGames.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewGames.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGames.Cursor = System.Windows.Forms.Cursors.Arrow;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewGames.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewGames.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewGames.EnableHeadersVisualStyles = false;
            this.dataGridViewGames.GridColor = System.Drawing.Color.White;
            this.dataGridViewGames.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewGames.Name = "dataGridViewGames";
            this.dataGridViewGames.ReadOnly = true;
            this.dataGridViewGames.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(53)))), ((int)(((byte)(57)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewGames.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewGames.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewGames.Size = new System.Drawing.Size(800, 280);
            this.dataGridViewGames.TabIndex = 0;
            this.dataGridViewGames.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewGames_CellClick);
            // 
            // FormGS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelTable);
            this.Controls.Add(this.PanelCommands);
            this.Name = "FormGS";
            this.Text = "FormGS";
            this.PanelCommands.ResumeLayout(false);
            this.PanelCommands.PerformLayout();
            this.panelTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGames)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PanelCommands;
        private AthleteDataSystem.CustomTools.CurveTextbox txtGames;
        private AthleteDataSystem.CustomTools.CurveTextbox txtTeamMatchup;
        private CustomTools.CurvedButton newBtn;
        private CustomTools.CurvedButton saveBtn;
        private CustomTools.CurvedButton updateBtn;
        private CustomTools.CurvedButton deleteBtn;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Panel panelTable;
        private System.Windows.Forms.DataGridView dataGridViewGames;
        private System.Windows.Forms.DateTimePicker txtDate;
        private AthleteDataSystem.CustomTools.CurveTextbox txtSearch;
        private System.Windows.Forms.Button btnSearch;
    }
}